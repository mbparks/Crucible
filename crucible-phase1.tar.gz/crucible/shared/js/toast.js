// toast.js. ephemeral status messages.

let region = null;
function getRegion() {
  if (!region) region = document.querySelector("[data-toast-region]");
  return region;
}

export function toast(message, opts = {}) {
  const r = getRegion();
  if (!r) return;
  const node = document.createElement("div");
  node.className = "toast";
  node.textContent = message;
  r.appendChild(node);
  const ttl = opts.ttl || 2400;
  setTimeout(() => {
    node.style.transition = "opacity 200ms";
    node.style.opacity = "0";
    setTimeout(() => node.remove(), 220);
  }, ttl);
}
