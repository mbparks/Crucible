// app.js. CRUCIBLE entry point. Wires together every shared module.

import { initTheme } from "./theme.js";
import * as vitrine from "./vitrine.js";
import * as search from "./search.js";
import * as router from "./router.js";
import { toast } from "./toast.js";

function ready(fn) {
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", fn, { once: true });
  } else fn();
}

ready(() => {
  initTheme();
  vitrine.init();
  search.init();
  router.init();

  // Chrome buttons
  document.addEventListener("click", (ev) => {
    const t = ev.target.closest("[data-action]");
    if (!t) return;
    const a = t.dataset.action;
    if (a === "open-search") { ev.preventDefault(); search.open(); }
    else if (a === "open-vitrine") { ev.preventDefault(); openVitrine(); }
    else if (a === "close-overlay") { ev.preventDefault(); closeAllOverlays(); }
    else if (a === "vitrine-share") { ev.preventDefault(); shareVitrine(); }
    else if (a === "vitrine-print") { ev.preventDefault(); closeAllOverlays(); location.hash = "#/print"; }
    else if (a === "vitrine-clear") { ev.preventDefault(); if (confirm("Clear the vitrine?")) { vitrine.clear(); vitrine.renderOverlay(); toast("Vitrine cleared"); } }
  });

  // Global key shortcuts
  window.addEventListener("keydown", (ev) => {
    const tag = (ev.target.tagName || "").toLowerCase();
    const isTyping = tag === "input" || tag === "textarea" || ev.target.isContentEditable;

    if (ev.key === "/" && !isTyping && !search.isOpen()) {
      ev.preventDefault();
      search.open();
    } else if (ev.key === "Escape") {
      closeAllOverlays();
    }
  });

  // Click outside overlay card to close
  document.addEventListener("click", (ev) => {
    const overlay = ev.target.closest(".overlay");
    if (overlay && ev.target === overlay) closeAllOverlays();
  });

  // Route triggered vitrine overlay (e.g., #/vitrine)
  window.addEventListener("crucible:open-vitrine", openVitrine);
});

async function openVitrine() {
  const overlay = document.querySelector("[data-overlay=\"vitrine\"]");
  if (!overlay) return;
  overlay.hidden = false;
  await vitrine.renderOverlay();
}

function closeAllOverlays() {
  for (const o of document.querySelectorAll(".overlay")) o.hidden = true;
}

async function shareVitrine() {
  const link = vitrine.shareLink();
  if (!link) { toast("Add specimens first"); return; }
  try {
    await navigator.clipboard.writeText(link);
    toast("Share link copied to clipboard");
  } catch (e) {
    // Fallback: show the link inline
    const dialog = document.querySelector("[data-overlay=\"vitrine\"] .vitrine-status");
    if (dialog) dialog.textContent = link;
    toast("Copy this link to share");
  }
}

// Remove boot shim once first view paints
const obs = new MutationObserver(() => {
  const shim = document.querySelector("[data-boot-shim]");
  if (shim) shim.remove();
});
obs.observe(document.getElementById("view-root"), { childList: true, subtree: false });
