// data.js. loads manifest, sources, search index, and module entries.
// All data lives in static JSON files, fetched on demand.

const cache = {
  manifest: null,
  sources: null,
  searchIndex: null,
  entries: new Map(), // id -> entry object
};

async function loadJSON(path) {
  const res = await fetch(path);
  if (!res.ok) throw new Error(`Failed to load ${path}: ${res.status}`);
  return res.json();
}

export async function loadManifest() {
  if (!cache.manifest) {
    cache.manifest = await loadJSON("shared/data/manifest.json");
  }
  return cache.manifest;
}

export async function loadSources() {
  if (!cache.sources) {
    cache.sources = await loadJSON("shared/data/sources.json");
  }
  return cache.sources;
}

export async function loadSearchIndex() {
  if (!cache.searchIndex) {
    cache.searchIndex = await loadJSON("shared/data/search-index.json");
  }
  return cache.searchIndex;
}

/**
 * Resolve a global id like "element:fe" to its filesystem path.
 * Convention: module folder + data/<kind>-<slug>.json or just <slug>.json
 * Phase 1 simplification: every entry lives at modules/<module>/data/<filename>.json
 * where filename is derived from the manifest.
 */
function resolveEntryPath(manifest, id) {
  // id format: "<kind>:<slug>"
  const parts = id.split(":");
  if (parts.length !== 2) return null;
  const [kind, slug] = parts;

  // Find which module declares this entry id
  for (const mod of manifest.modules) {
    if (mod.entries && mod.entries.includes(slug)) {
      return `modules/${mod.slug}/data/${slug}.json`;
    }
  }
  return null;
}

export async function loadEntry(id) {
  if (cache.entries.has(id)) return cache.entries.get(id);

  const manifest = await loadManifest();
  const path = resolveEntryPath(manifest, id);
  if (!path) throw new Error(`Unknown entry id: ${id}`);

  const entry = await loadJSON(path);
  cache.entries.set(id, entry);
  return entry;
}

export async function loadEntriesForModule(slug) {
  const manifest = await loadManifest();
  const mod = manifest.modules.find(m => m.slug === slug);
  if (!mod || !mod.entries) return [];

  const entries = await Promise.all(
    mod.entries.map(async entrySlug => {
      const path = `modules/${slug}/data/${entrySlug}.json`;
      try {
        const entry = await loadJSON(path);
        cache.entries.set(entry.id, entry);
        return entry;
      } catch (err) {
        console.warn(`Could not load ${path}:`, err);
        return null;
      }
    })
  );
  return entries.filter(Boolean);
}

export function getCachedEntry(id) {
  return cache.entries.get(id) || null;
}
