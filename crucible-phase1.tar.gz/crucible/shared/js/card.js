// card.js. renders specimen cards from sample tag entries.
// Output is theme-agnostic; CSS variables provide the look.

import { loadSources } from "./data.js";

let sourcesCache = null;
async function getSources() {
  if (!sourcesCache) {
    const data = await loadSources();
    sourcesCache = data.sources;
  }
  return sourcesCache;
}

function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") node.className = v;
    else if (k === "dataset") {
      for (const [dk, dv] of Object.entries(v)) node.dataset[dk] = dv;
    } else if (k.startsWith("on") && typeof v === "function") {
      node.addEventListener(k.slice(2).toLowerCase(), v);
    } else if (v !== null && v !== undefined && v !== false) {
      node.setAttribute(k, v === true ? "" : v);
    }
  }
  for (const child of children) {
    if (child === null || child === undefined || child === false) continue;
    if (typeof child === "string") node.appendChild(document.createTextNode(child));
    else node.appendChild(child);
  }
  return node;
}

function fmtValue(stat) {
  const v = stat.value;
  if (typeof v === "number") {
    // Choose precision: round to 4 significant digits, drop trailing zeros
    return Number(v.toPrecision(4)).toString();
  }
  return String(v);
}

function topStats(entry, n = 5) {
  return (entry.stats || []).slice(0, n);
}

function renderTags(entry) {
  const tags = entry.tags || [];
  const hazards = entry.hazards || [];
  if (tags.length === 0 && hazards.length === 0) return null;
  return el("div", { class: "card-tags" },
    ...tags.map(t => el("span", { class: "card-tag" }, t)),
    ...hazards.map(h => el("span", { class: "card-tag", dataset: { kind: "hazard" } }, h))
  );
}

function renderStatList(stats) {
  if (!stats || stats.length === 0) return null;
  const dl = el("dl", { class: "card-stats" });
  for (const s of stats) {
    dl.appendChild(el("dt", {}, s.label));
    const dd = el("dd", {}, fmtValue(s));
    if (s.unit) dd.appendChild(el("span", { class: "card-stat-unit" }, ` ${s.unit}`));
    dl.appendChild(dd);
  }
  return dl;
}

async function renderCitations(entry) {
  const sources = await getSources();
  const list = (entry.sources || []).map(key => sources[key]?.short || key).join(" · ");
  return el("p", { class: "card-citations" },
    el("strong", {}, "Sources: "),
    list || "unattributed"
  );
}

/**
 * Render a card front, optionally with extra classes (e.g., "print-card" for print sheets).
 */
export function renderFront(entry, opts = {}) {
  const extraClass = opts.extraClass || "";
  return el("article", { class: `card card-front ${extraClass}`.trim(), dataset: { id: entry.id, kind: entry.kind } },
    el("div", { class: "card-id" },
      el("span", {}, entry.id),
      el("span", {}, (entry.module || "").toUpperCase())
    ),
    el("div", { class: "card-title-row" },
      el("h3", { class: "card-title" }, entry.title),
      entry.symbol ? el("span", { class: "card-symbol" }, entry.symbol) : null
    ),
    entry.subtitle ? el("p", { class: "card-subtitle" }, entry.subtitle) : null,
    renderTags(entry),
    renderStatList(topStats(entry, opts.statLimit || 5)),
    el("div", { class: "card-foot" },
      el("span", {}, "Crucible"),
      el("span", {}, entry.kind || "")
    )
  );
}

/**
 * Render a card back. extended detail, body text, related links, citations.
 */
export async function renderBack(entry, opts = {}) {
  const extraClass = opts.extraClass || "";
  const citations = await renderCitations(entry);

  // Body: simple markdown-ish (paragraphs split on \n\n, bold via **...**)
  const bodyEl = el("div", { class: "card-body" });
  if (entry.body) {
    const paras = entry.body.split(/\n\n+/);
    for (const p of paras) {
      const html = p
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
        .replace(/\n/g, "<br>");
      const para = document.createElement("p");
      para.innerHTML = html;
      bodyEl.appendChild(para);
    }
  }

  // Related cross-links
  let relatedEl = null;
  if (entry.related && entry.related.length > 0) {
    relatedEl = el("div", { class: "card-related" },
      el("span", { class: "card-related-label" }, "See also"),
      ...entry.related.map(rid => {
        const [, slug] = rid.split(":");
        const a = el("a", { class: "card-related-link", href: `#/card/${encodeURIComponent(rid)}` }, slug);
        return a;
      })
    );
  }

  // For the back we show more stats if present
  const stats = (entry.stats || []).slice(0, 14);

  return el("article", { class: `card card-back ${extraClass}`.trim(), dataset: { id: entry.id, kind: entry.kind } },
    el("span", { class: "card-side-label" }, "verso"),
    el("div", { class: "card-title-row" },
      el("h3", { class: "card-title" }, entry.title),
      entry.symbol ? el("span", { class: "card-symbol" }, entry.symbol) : null
    ),
    entry.subtitle ? el("p", { class: "card-subtitle" }, entry.subtitle) : null,
    renderStatList(stats),
    bodyEl,
    relatedEl,
    citations
  );
}

/**
 * Render a small "thumbnail" used in the vitrine grid.
 */
export function renderThumb(entry, onRemove) {
  return el("article", { class: "vitrine-cell", dataset: { id: entry.id }, draggable: "true" },
    entry.symbol ? el("div", { class: "vitrine-cell-symbol" }, entry.symbol) : null,
    el("div", { class: "vitrine-cell-title" }, entry.title),
    el("div", { class: "vitrine-cell-subtitle" }, entry.subtitle || ""),
    el("button", { type: "button", class: "vitrine-cell-remove", "aria-label": "Remove from vitrine", onClick: () => onRemove(entry.id) }, "✕")
  );
}
