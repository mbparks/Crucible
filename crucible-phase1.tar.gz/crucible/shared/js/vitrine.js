// vitrine.js. collection of card ids the user wants to print or share.

import { renderThumb } from "./card.js";
import { loadEntry } from "./data.js";
import { toast } from "./toast.js";

const KEY = "crucible.vitrine";
let state = []; // ordered list of card ids
const listeners = new Set();

function persist() {
  try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) { /* ignore */ }
}

function notify() {
  for (const fn of listeners) fn(state.slice());
}

export function init() {
  // First check for a shared vitrine in the URL hash (#/v/<base64>)
  if (location.hash.startsWith("#/v/")) {
    const payload = location.hash.slice(4);
    const loaded = decodePayload(payload);
    if (loaded) {
      state = loaded;
      persist();
      // Replace hash with vitrine view so back button works
      history.replaceState(null, "", "#/vitrine");
      toast(`Loaded ${loaded.length} specimen${loaded.length === 1 ? "" : "s"} from shared link`);
    }
  } else {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) state = JSON.parse(raw);
    } catch (e) { state = []; }
  }
  if (!Array.isArray(state)) state = [];
  updateCountBadge();
}

export function get() { return state.slice(); }
export function size() { return state.length; }
export function has(id) { return state.includes(id); }

export function add(id) {
  if (state.includes(id)) return false;
  state.push(id);
  persist();
  updateCountBadge();
  notify();
  return true;
}

export function remove(id) {
  const i = state.indexOf(id);
  if (i < 0) return false;
  state.splice(i, 1);
  persist();
  updateCountBadge();
  notify();
  return true;
}

export function move(id, toIndex) {
  const from = state.indexOf(id);
  if (from < 0) return;
  state.splice(from, 1);
  state.splice(toIndex, 0, id);
  persist();
  notify();
}

export function clear() {
  state = [];
  persist();
  updateCountBadge();
  notify();
}

export function subscribe(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

function updateCountBadge() {
  const badge = document.querySelector("[data-vitrine-count]");
  if (!badge) return;
  badge.textContent = String(state.length);
  badge.setAttribute("data-empty", state.length === 0 ? "true" : "false");
}

/* ---- share payload ---- */

function encodePayload(ids) {
  const json = JSON.stringify(ids);
  // base64url
  return btoa(unescape(encodeURIComponent(json)))
    .replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function decodePayload(s) {
  try {
    const b64 = s.replace(/-/g, "+").replace(/_/g, "/");
    const json = decodeURIComponent(escape(atob(b64)));
    const arr = JSON.parse(json);
    if (Array.isArray(arr) && arr.every(x => typeof x === "string")) return arr;
  } catch (e) { /* malformed */ }
  return null;
}

export function shareLink() {
  if (state.length === 0) return null;
  const payload = encodePayload(state);
  const base = location.origin + location.pathname;
  return `${base}#/v/${payload}`;
}

/* ---- overlay rendering ---- */

let dragSrc = null;

export async function renderOverlay() {
  const grid = document.querySelector("[data-vitrine-grid]");
  const empty = document.querySelector("[data-vitrine-empty]");
  const status = document.querySelector("[data-vitrine-status]");
  if (!grid || !empty || !status) return;

  grid.innerHTML = "";

  if (state.length === 0) {
    empty.hidden = false;
    status.textContent = "";
    return;
  }
  empty.hidden = true;
  status.textContent = `${state.length} specimen${state.length === 1 ? "" : "s"} · ${Math.ceil(state.length / 9)} print sheet${Math.ceil(state.length / 9) === 1 ? "" : "s"}`;

  for (const id of state) {
    let entry;
    try { entry = await loadEntry(id); }
    catch (e) {
      const ghost = document.createElement("div");
      ghost.className = "vitrine-cell";
      ghost.innerHTML = `<div class="vitrine-cell-title">${id}</div><div class="vitrine-cell-subtitle">unresolved</div>`;
      grid.appendChild(ghost);
      continue;
    }
    const thumb = renderThumb(entry, removeId => { remove(removeId); renderOverlay(); });
    // Drag and drop reordering
    thumb.addEventListener("dragstart", (ev) => {
      dragSrc = entry.id;
      thumb.dataset.dragging = "true";
      ev.dataTransfer.effectAllowed = "move";
    });
    thumb.addEventListener("dragend", () => { thumb.dataset.dragging = "false"; dragSrc = null; });
    thumb.addEventListener("dragover", (ev) => { ev.preventDefault(); ev.dataTransfer.dropEffect = "move"; });
    thumb.addEventListener("drop", (ev) => {
      ev.preventDefault();
      if (!dragSrc || dragSrc === entry.id) return;
      const targetIdx = state.indexOf(entry.id);
      move(dragSrc, targetIdx);
      renderOverlay();
    });
    grid.appendChild(thumb);
  }
}
