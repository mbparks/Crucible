// search.js. global search overlay.

import { loadSearchIndex } from "./data.js";

let index = null;
let results = [];
let selectedIndex = 0;

function score(entry, q) {
  const Q = q.toLowerCase().trim();
  if (!Q) return 0;
  let s = 0;
  if (entry.title.toLowerCase() === Q) s += 100;
  if (entry.title.toLowerCase().startsWith(Q)) s += 50;
  if (entry.title.toLowerCase().includes(Q)) s += 20;
  if (entry.symbol && entry.symbol.toLowerCase() === Q) s += 60;
  if (entry.symbol && entry.symbol.toLowerCase().includes(Q)) s += 15;
  if (entry.subtitle && entry.subtitle.toLowerCase().includes(Q)) s += 8;
  if (entry.tags) {
    for (const t of entry.tags) {
      if (t.toLowerCase() === Q) s += 30;
      else if (t.toLowerCase().includes(Q)) s += 5;
    }
  }
  if (entry.excerpt && entry.excerpt.toLowerCase().includes(Q)) s += 3;
  return s;
}

function runQuery(q) {
  if (!index) return [];
  if (!q || !q.trim()) {
    // Show first 12 as browse-mode hits
    return index.entries.slice(0, 12).map(e => ({ entry: e, score: 0 }));
  }
  return index.entries
    .map(e => ({ entry: e, score: score(e, q) }))
    .filter(r => r.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 20);
}

function moduleGlyph(slug) {
  const m = {
    assay: "☉", alloy: "⚒", temper: "♨", phase: "◐",
    hardness: "◆", solder: "≈", reagent: "⚖", buffer: "≷",
    etch: "✱", electro: "⚡", darkroom: "◓", hazard: "⚠",
  };
  return m[slug] || "·";
}

function renderResults() {
  const container = document.querySelector("[data-search-results]");
  if (!container) return;
  container.innerHTML = "";

  if (results.length === 0) {
    const empty = document.createElement("p");
    empty.className = "search-empty";
    empty.textContent = "No matches. Try fewer letters, or a different word.";
    container.appendChild(empty);
    return;
  }

  results.forEach((r, i) => {
    const e = r.entry;
    const a = document.createElement("a");
    a.className = "search-result";
    a.href = `#/card/${encodeURIComponent(e.id)}`;
    a.setAttribute("role", "option");
    a.setAttribute("data-index", String(i));
    if (i === selectedIndex) a.setAttribute("aria-selected", "true");

    a.innerHTML = `
      <span class="search-result-glyph">${moduleGlyph(e.module)}</span>
      <span>
        <span class="search-result-title">${escapeHTML(e.title)}</span>
        <br>
        <span class="search-result-subtitle">${escapeHTML(e.subtitle || "")}</span>
      </span>
      <span class="search-result-chip">${escapeHTML(e.module)}</span>
    `;
    a.addEventListener("click", () => close());
    container.appendChild(a);
  });
}

function escapeHTML(s) {
  return String(s).replace(/[&<>"']/g, c => ({"&": "&amp;","<": "&lt;",">": "&gt;","\"": "&quot;","'":"&#39;"}[c]));
}

export async function open() {
  if (!index) {
    try { index = await loadSearchIndex(); }
    catch (e) { console.error("Search index failed to load:", e); return; }
  }
  const overlay = document.querySelector("[data-overlay=\"search\"]");
  const input = document.querySelector("[data-search-input]");
  if (!overlay || !input) return;
  overlay.hidden = false;
  input.value = "";
  selectedIndex = 0;
  results = runQuery("");
  renderResults();
  setTimeout(() => input.focus(), 10);
}

export function close() {
  const overlay = document.querySelector("[data-overlay=\"search\"]");
  if (overlay) overlay.hidden = true;
}

export function isOpen() {
  const overlay = document.querySelector("[data-overlay=\"search\"]");
  return overlay && !overlay.hidden;
}

export function init() {
  const input = document.querySelector("[data-search-input]");
  if (!input) return;

  input.addEventListener("input", (ev) => {
    selectedIndex = 0;
    results = runQuery(ev.target.value);
    renderResults();
  });

  input.addEventListener("keydown", (ev) => {
    if (ev.key === "ArrowDown") {
      ev.preventDefault();
      selectedIndex = Math.min(selectedIndex + 1, results.length - 1);
      renderResults();
    } else if (ev.key === "ArrowUp") {
      ev.preventDefault();
      selectedIndex = Math.max(selectedIndex - 1, 0);
      renderResults();
    } else if (ev.key === "Enter") {
      ev.preventDefault();
      const r = results[selectedIndex];
      if (r) {
        location.hash = `#/card/${encodeURIComponent(r.entry.id)}`;
        close();
      }
    } else if (ev.key === "Escape") {
      ev.preventDefault();
      close();
    }
  });
}
