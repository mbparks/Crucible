// theme.js. theme selection and persistence.

const KEY = "crucible.theme";
const DEFAULT = "alchemy";
const VALID = new Set(["alchemy", "assay"]);

export function getTheme() {
  try {
    const stored = localStorage.getItem(KEY);
    if (stored && VALID.has(stored)) return stored;
  } catch (e) {
    // localStorage may be unavailable (privacy mode); fall through to default
  }
  return DEFAULT;
}

export function setTheme(name) {
  if (!VALID.has(name)) return;
  document.documentElement.dataset.theme = name;
  try { localStorage.setItem(KEY, name); } catch (e) { /* ignore */ }
  for (const btn of document.querySelectorAll("[data-theme-set]")) {
    btn.setAttribute("aria-pressed", btn.dataset.themeSet === name ? "true" : "false");
  }
}

export function initTheme() {
  setTheme(getTheme());
  for (const btn of document.querySelectorAll("[data-theme-set]")) {
    btn.addEventListener("click", () => setTheme(btn.dataset.themeSet));
  }
}
