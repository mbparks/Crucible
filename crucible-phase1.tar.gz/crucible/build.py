#!/usr/bin/env python3
"""
CRUCIBLE build script.

Walks modules/*/data/*.json and produces shared/data/search-index.json.
Phase 1 leaves search-index.json hand-written; this script will replace it
in Phase 2 when ASSAY ships with its 118 element cards.

Usage:
    python3 build.py
    python3 build.py --check     # verify all entries resolve correctly
    python3 build.py --bundle    # produce a single-file deployable (Phase 6)
"""

import json
import sys
from pathlib import Path

ROOT = Path(__file__).parent
MODULES = ROOT / "modules"
SHARED_DATA = ROOT / "shared" / "data"


def collect_entries():
    entries = []
    for module_dir in sorted(MODULES.iterdir()):
        if not module_dir.is_dir():
            continue
        data_dir = module_dir / "data"
        if not data_dir.exists():
            continue
        for f in sorted(data_dir.glob("*.json")):
            try:
                doc = json.loads(f.read_text(encoding="utf-8"))
            except Exception as exc:
                print(f"  ! skip {f.relative_to(ROOT)}: {exc}", file=sys.stderr)
                continue
            entries.append(doc)
    return entries


def build_search_index(entries):
    out = {
        "version": 1,
        "built": "build.py",
        "entries": [],
    }
    for e in entries:
        if not e.get("id"):
            continue
        excerpt = (e.get("body") or "").split("\n\n", 1)[0]
        excerpt = excerpt.replace("**", "")[:200]
        out["entries"].append({
            "id": e["id"],
            "module": e.get("module", ""),
            "kind": e.get("kind", ""),
            "title": e.get("title", ""),
            "symbol": e.get("symbol", ""),
            "subtitle": e.get("subtitle", ""),
            "tags": e.get("tags", []),
            "excerpt": excerpt,
        })
    return out


def check(entries):
    """Verify integrity: ids are unique, related links resolve, sources are known."""
    sources = json.loads((SHARED_DATA / "sources.json").read_text())["sources"]
    manifest = json.loads((SHARED_DATA / "manifest.json").read_text())
    declared_module_entries = {
        m["slug"]: set(m.get("entries", [])) for m in manifest["modules"]
    }

    ids = set()
    problems = []
    for e in entries:
        eid = e.get("id")
        if not eid:
            problems.append(f"entry without id in {e.get('module')}")
            continue
        if eid in ids:
            problems.append(f"duplicate id {eid}")
        ids.add(eid)
        for src in e.get("sources", []):
            if src not in sources:
                problems.append(f"{eid} cites unknown source {src}")
    # related links
    for e in entries:
        for rid in e.get("related", []):
            if rid not in ids:
                problems.append(f"{e['id']} → unknown related {rid}")
    # manifest declares matching entries
    for e in entries:
        slug = e["id"].split(":", 1)[1]
        declared = declared_module_entries.get(e.get("module"), set())
        if slug not in declared:
            problems.append(f"{e['id']} not declared in manifest under {e.get('module')}")

    if problems:
        print(f"\n{len(problems)} problem(s):", file=sys.stderr)
        for p in problems:
            print(f"  ! {p}", file=sys.stderr)
        return 1
    print(f"OK · {len(ids)} entries, all references resolve.")
    return 0


def main(argv):
    do_check = "--check" in argv
    do_bundle = "--bundle" in argv

    entries = collect_entries()
    print(f"Collected {len(entries)} entries across {len(list(MODULES.iterdir()))} module folders.")

    if do_check:
        return check(entries)

    if do_bundle:
        print("Single-file bundle not implemented yet (Phase 6).", file=sys.stderr)
        return 1

    index = build_search_index(entries)
    out_path = SHARED_DATA / "search-index.json"
    out_path.write_text(json.dumps(index, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {out_path.relative_to(ROOT)} ({len(index['entries'])} indexed).")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
