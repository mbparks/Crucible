// assay/module.js. Periodic table renderer with engineering overlays.
//
// Exports render(rootElement, ctx) per the custom-view contract.
// ctx provides: manifest, loadEntry, loadEntriesForModule.
//
// Layout: 18 column CSS grid, 9 rows. Lanthanides occupy row 8, actinides row 9.
// La (Z=57) sits in group 3 of row 6, Ac (Z=89) in group 3 of row 7.

import { loadEntriesForModule } from "../../shared/js/data.js";

// Overlay definitions. Each picks a stat key and presents a value range with units.
const OVERLAYS = [
  { id: "category",   label: "Category",        stat: null,                  scale: "category" },
  { id: "density",    label: "Density",         stat: "density",             unit: "g/cm³",  scale: "linear" },
  { id: "mp",         label: "Melting point",   stat: "meltingPoint",        unit: "°C",     scale: "linear" },
  { id: "bp",         label: "Boiling point",   stat: "boilingPoint",        unit: "°C",     scale: "linear" },
  { id: "modulus",    label: "Young's modulus", stat: "youngsModulus",       unit: "GPa",    scale: "linear" },
  { id: "thermal",    label: "Thermal cond.",   stat: "thermalConductivity", unit: "W/m·K",  scale: "log" },
  { id: "eneg",       label: "Electronegativity", stat: "electronegativity", unit: "Pauling", scale: "linear" },
  { id: "mohs",       label: "Mohs hardness",   stat: "mohs",                unit: "",       scale: "linear" },
];

// Element categories listed in legend order. Color is a CSS variable resolved from theme.
const CATEGORIES = [
  { id: "alkali-metal",      label: "Alkali metal" },
  { id: "alkaline-earth",    label: "Alkaline earth" },
  { id: "transition-metal",  label: "Transition metal" },
  { id: "post-transition",   label: "Post-transition" },
  { id: "metalloid",         label: "Metalloid" },
  { id: "reactive-nonmetal", label: "Reactive nonmetal" },
  { id: "halogen",           label: "Halogen" },
  { id: "noble-gas",         label: "Noble gas" },
  { id: "lanthanide",        label: "Lanthanide" },
  { id: "actinide",          label: "Actinide" },
  { id: "unknown",           label: "Uncharacterized" },
];

function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") node.className = v;
    else if (k === "dataset") for (const [dk, dv] of Object.entries(v)) node.dataset[dk] = dv;
    else if (k === "style") node.style.cssText = v;
    else if (k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (v !== null && v !== undefined && v !== false) node.setAttribute(k, v === true ? "" : v);
  }
  for (const c of children) {
    if (c === null || c === undefined || c === false) continue;
    node.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
  }
  return node;
}

function statValue(entry, key) {
  if (!entry || !entry.stats) return null;
  const s = entry.stats.find(x => x.key === key);
  if (!s) return null;
  const v = s.value;
  return (typeof v === "number") ? v : null;
}

function getPosition(entry) {
  // Compute (col, row) from Z. The seeder uses the same logic; keep this in sync.
  const Z = entry.Z;
  if (Z === 1)  return [1, 1];
  if (Z === 2)  return [18, 1];
  if (Z >= 3 && Z <= 4)   return [Z - 2, 2];
  if (Z >= 5 && Z <= 10)  return [Z + 8, 2];
  if (Z >= 11 && Z <= 12) return [Z - 10, 3];
  if (Z >= 13 && Z <= 18) return [Z, 3];
  if (Z >= 19 && Z <= 20) return [Z - 18, 4];
  if (Z >= 21 && Z <= 30) return [Z - 18, 4];
  if (Z >= 31 && Z <= 36) return [Z - 18, 4];
  if (Z >= 37 && Z <= 38) return [Z - 36, 5];
  if (Z >= 39 && Z <= 48) return [Z - 36, 5];
  if (Z >= 49 && Z <= 54) return [Z - 36, 5];
  if (Z === 55) return [1, 6];
  if (Z === 56) return [2, 6];
  if (Z === 57) return [3, 6];                  // La in group 3
  if (Z >= 58 && Z <= 71) return [Z - 55, 8];   // Lanthanides Ce..Lu in row 8 cols 3..16
  if (Z >= 72 && Z <= 80) return [Z - 68, 6];   // Hf..Hg in cols 4..12
  if (Z >= 81 && Z <= 86) return [Z - 68, 6];   // Tl..Rn cols 13..18
  if (Z === 87) return [1, 7];
  if (Z === 88) return [2, 7];
  if (Z === 89) return [3, 7];                  // Ac in group 3
  if (Z >= 90 && Z <= 103) return [Z - 87, 9];  // Actinides row 9 cols 3..16
  if (Z >= 104 && Z <= 112) return [Z - 100, 7]; // Rf..Cn cols 4..12
  if (Z >= 113 && Z <= 118) return [Z - 100, 7]; // Nh..Og cols 13..18
  return [1, 1];
}

function computeOverlayRange(entries, overlay) {
  if (!overlay.stat) return null;
  const values = entries
    .map(e => statValue(e, overlay.stat))
    .filter(v => v !== null && Number.isFinite(v));
  if (values.length === 0) return null;
  if (overlay.scale === "log") {
    const positive = values.filter(v => v > 0);
    return { min: Math.log10(Math.min(...positive)), max: Math.log10(Math.max(...positive)) };
  }
  return { min: Math.min(...values), max: Math.max(...values) };
}

function mapValueToRamp(v, range, overlay) {
  if (v === null || !Number.isFinite(v) || !range) return null;
  const x = overlay.scale === "log" ? Math.log10(v) : v;
  const t = (x - range.min) / (range.max - range.min || 1);
  return Math.max(0, Math.min(1, t));
}

function renderCell(entry, overlay, range) {
  const [col, row] = getPosition(entry);
  const v = overlay.stat ? statValue(entry, overlay.stat) : null;
  const t = mapValueToRamp(v, range, overlay);
  const noData = overlay.stat && t === null;

  const cell = el("a", {
    class: "pt-cell",
    href: `#/card/${encodeURIComponent(entry.id)}`,
    style: `grid-column:${col};grid-row:${row};`,
    dataset: {
      z: String(entry.Z),
      sym: entry.symbol,
      category: entry.category,
      block: entry.block,
      nodata: noData ? "true" : "false",
      fblock: row >= 8 ? "true" : "false",
    },
    title: `${entry.title} (${entry.symbol}) Z=${entry.Z}${v !== null && v !== undefined ? ` · ${overlay.label}: ${v} ${overlay.unit || ""}`.trim() : ""}`,
  });

  if (overlay.id === "category") {
    cell.style.setProperty("--cell-tint", `var(--cat-${entry.category})`);
    cell.dataset.tintMode = "category";
  } else if (t !== null) {
    cell.style.setProperty("--cell-tint-alpha", String(0.08 + 0.72 * t));
    cell.dataset.tintMode = "overlay";
  }

  cell.appendChild(el("span", { class: "pt-z" }, String(entry.Z)));
  cell.appendChild(el("span", { class: "pt-sym" }, entry.symbol));
  cell.appendChild(el("span", { class: "pt-name" }, entry.title));
  if (overlay.id === "category") {
    // Show atomic mass when no overlay value is being highlighted.
    const m = statValue(entry, "atomicMass");
    if (m !== null) cell.appendChild(el("span", { class: "pt-overlay-val" }, m.toFixed(2)));
  } else if (v !== null && Number.isFinite(v)) {
    // Show selected overlay value compactly.
    let display;
    if (Math.abs(v) >= 1000) display = v.toPrecision(3);
    else if (Math.abs(v) >= 1) display = Number(v.toFixed(2)).toString();
    else display = Number(v.toPrecision(2)).toString();
    cell.appendChild(el("span", { class: "pt-overlay-val" }, display));
  } else {
    cell.appendChild(el("span", { class: "pt-overlay-val pt-overlay-nodata" }, "·"));
  }

  return cell;
}

function renderLegend(overlay, range) {
  const legend = el("div", { class: "pt-legend" });

  if (overlay.id === "category") {
    legend.appendChild(el("span", { class: "pt-legend-label" }, "Categories"));
    const swatches = el("div", { class: "pt-legend-swatches" });
    for (const c of CATEGORIES) {
      const sw = el("span", { class: "pt-legend-swatch" },
        el("span", { class: "pt-legend-chip", style: `background:var(--cat-${c.id});` }),
        el("span", {}, c.label)
      );
      swatches.appendChild(sw);
    }
    legend.appendChild(swatches);
  } else if (range) {
    const minLabel = overlay.scale === "log" ? Math.pow(10, range.min) : range.min;
    const maxLabel = overlay.scale === "log" ? Math.pow(10, range.max) : range.max;
    legend.appendChild(el("span", { class: "pt-legend-label" }, `${overlay.label}${overlay.unit ? ` (${overlay.unit})` : ""}${overlay.scale === "log" ? ", log scale" : ""}`));
    legend.appendChild(el("div", { class: "pt-legend-ramp" },
      el("span", { class: "pt-legend-tick" }, formatRangeLabel(minLabel)),
      el("span", { class: "pt-legend-bar" }),
      el("span", { class: "pt-legend-tick" }, formatRangeLabel(maxLabel))
    ));
  } else {
    legend.appendChild(el("span", { class: "pt-legend-label" }, `${overlay.label}: no data`));
  }
  return legend;
}

function formatRangeLabel(v) {
  if (!Number.isFinite(v)) return "?";
  if (Math.abs(v) >= 1000) return v.toPrecision(3);
  if (Math.abs(v) >= 1) return Number(v.toFixed(2)).toString();
  return Number(v.toPrecision(2)).toString();
}

function renderOverlayBar(currentId) {
  const bar = el("div", { class: "pt-overlay-bar", role: "tablist", "aria-label": "Periodic table overlays" });
  for (const o of OVERLAYS) {
    bar.appendChild(el("button", {
      type: "button",
      class: "pt-overlay-btn",
      role: "tab",
      "aria-selected": o.id === currentId ? "true" : "false",
      dataset: { overlayId: o.id },
    }, o.label));
  }
  return bar;
}

export async function render(root, ctx) {
  root.innerHTML = "";

  // Header
  root.appendChild(el("a", { class: "detail-back-link", href: "#/" }, "← bench"));
  root.appendChild(el("p", { class: "section-eyebrow", style: "margin-top:1rem;" }, "Materials"));
  root.appendChild(el("h1", { class: "section-title" }, "ASSAY"));
  root.appendChild(el("p", { class: "section-lede" },
    "Periodic table with engineering overlays. Click any element for its specimen card; pick an overlay to color the table by density, melting point, modulus, conductivity, electronegativity, or hardness."
  ));

  // Load all elements
  const entries = await loadEntriesForModule("assay");
  if (entries.length === 0) {
    root.appendChild(el("p", { class: "boot-note" }, "No element data found."));
    return;
  }

  // State (per render call)
  let currentOverlayId = "category";

  // Overlay bar
  const overlayBarHost = el("div");
  root.appendChild(overlayBarHost);

  // Legend
  const legendHost = el("div");
  root.appendChild(legendHost);

  // Table
  const table = el("div", { class: "pt-table" });
  root.appendChild(table);

  // F-block label rows (small "Lanthanides" and "Actinides" markers)
  const fLabel1 = el("div", { class: "pt-f-marker", style: "grid-column:3;grid-row:6;" }, "*");
  const fLabel2 = el("div", { class: "pt-f-marker", style: "grid-column:3;grid-row:7;" }, "**");

  function redraw() {
    const overlay = OVERLAYS.find(o => o.id === currentOverlayId) || OVERLAYS[0];
    const range = computeOverlayRange(entries, overlay);

    overlayBarHost.innerHTML = "";
    const bar = renderOverlayBar(currentOverlayId);
    bar.addEventListener("click", (ev) => {
      const t = ev.target.closest("[data-overlay-id]");
      if (!t) return;
      currentOverlayId = t.dataset.overlayId;
      redraw();
    });
    overlayBarHost.appendChild(bar);

    legendHost.innerHTML = "";
    legendHost.appendChild(renderLegend(overlay, range));

    table.innerHTML = "";
    // Note: La (57) and Ac (89) cells are overridden by markers; we still render them.
    for (const entry of entries) {
      const cell = renderCell(entry, overlay, range);
      // Override Z=57 and Z=89 cells: their natural position is shown in row 6/7 col 3
      // but visually we want them in their group-3 slot which is what getPosition returns.
      table.appendChild(cell);
    }
    // F-block series indicators in their group-3 slots (visual cue that the row continues below)
    // Actually La/Ac already render there with full data, so no extra indicator needed.
  }

  redraw();
}
