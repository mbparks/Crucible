// router.js. hash-based view dispatch.

import { loadManifest, loadEntry, loadEntriesForModule } from "./data.js";
import { renderFront, renderBack } from "./card.js";
import * as vitrine from "./vitrine.js";
import { toast } from "./toast.js";

const root = () => document.getElementById("view-root");

function clear() { const r = root(); if (r) r.innerHTML = ""; }

function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") node.className = v;
    else if (k === "dataset") for (const [dk, dv] of Object.entries(v)) node.dataset[dk] = dv;
    else if (v !== null && v !== undefined && v !== false) node.setAttribute(k, v === true ? "" : v);
  }
  for (const c of children) {
    if (c === null || c === undefined || c === false) continue;
    if (typeof c === "string") node.appendChild(document.createTextNode(c));
    else node.appendChild(c);
  }
  return node;
}

/* ---------- views ---------- */

async function viewLanding() {
  const manifest = await loadManifest();
  clear();
  const r = root();

  r.appendChild(el("p", { class: "section-eyebrow" }, "Field Instrument · CRUCIBLE"));
  r.appendChild(el("h1", { class: "section-title" }, "Chemistry and materials bench"));
  r.appendChild(el("p", { class: "section-lede" },
    "Twelve modules across two tracks. Engineering data from the ASM Handbook series, chemistry from the CRC Handbook. Click any tile to open a module. Press the slash key to search."
  ));

  const materials = manifest.modules.filter(m => m.track === "materials");
  const chemistry = manifest.modules.filter(m => m.track === "chemistry");

  const sections = [
    { label: "Materials", mods: materials },
    { label: "Chemistry", mods: chemistry },
  ];

  for (const sec of sections) {
    r.appendChild(el("h2", { class: "section-eyebrow", style: "margin-top:2rem;" }, sec.label));
    const grid = el("div", { class: "module-grid" });
    for (const m of sec.mods) {
      const isStub = m.status === "stub";
      const hasEntries = m.entries && m.entries.length > 0;

      const tile = isStub && !hasEntries
        ? el("div", { class: "module-tile", dataset: { status: "stub" } })
        : el("a", { class: "module-tile", href: `#/${m.slug}`, dataset: { status: hasEntries ? "active" : "stub" } });

      tile.appendChild(el("div", { class: "module-tile-head" },
        el("span", { class: "module-tile-glyph" }, m.glyph || "·"),
        el("span", { class: "module-tile-track" }, sec.label)
      ));
      tile.appendChild(el("h3", { class: "module-tile-name" }, m.name));
      tile.appendChild(el("p", { class: "module-tile-blurb" }, m.blurb));
      tile.appendChild(el("div", { class: "module-tile-foot" },
        el("span", {}, `Phase ${m.phase}`),
        el("span", { class: "module-tile-status", dataset: { status: hasEntries ? "active" : "stub" } },
          hasEntries ? `${m.entries.length} card${m.entries.length === 1 ? "" : "s"}` : "soon"
        )
      ));
      grid.appendChild(tile);
    }
    r.appendChild(grid);
  }
}

/* ---------- custom view loading ---------- */

const loadedModuleCSS = new Set();
const loadedModuleJS = new Map();

function ensureModuleCSS(slug) {
  if (loadedModuleCSS.has(slug)) return;
  const link = document.createElement("link");
  link.rel = "stylesheet";
  link.href = `modules/${slug}/module.css`;
  link.dataset.moduleCss = slug;
  document.head.appendChild(link);
  loadedModuleCSS.add(slug);
}

async function loadModuleScript(slug) {
  if (loadedModuleJS.has(slug)) return loadedModuleJS.get(slug);
  const mod = await import(`../../modules/${slug}/module.js`);
  loadedModuleJS.set(slug, mod);
  return mod;
}

async function viewModule(slug) {
  const manifest = await loadManifest();
  const mod = manifest.modules.find(m => m.slug === slug);
  if (!mod) return viewNotFound(`module ${slug}`);

  // Custom view path: module declares its own renderer.
  if (mod.customView === true) {
    clear();
    ensureModuleCSS(slug);
    try {
      const moduleScript = await loadModuleScript(slug);
      if (typeof moduleScript.render === "function") {
        await moduleScript.render(root(), { manifest, loadEntry, loadEntriesForModule });
        return;
      }
    } catch (err) {
      console.error(`Failed to load custom view for ${slug}:`, err);
      // Fall through to default rendering as a graceful degradation.
    }
  }

  // Default view: card grid of entries.
  clear();
  const r = root();

  r.appendChild(el("a", { class: "detail-back-link", href: "#/" }, "← bench"));
  r.appendChild(el("p", { class: "section-eyebrow", style: "margin-top:1rem;" },
    mod.track === "materials" ? "Materials" : "Chemistry"
  ));
  r.appendChild(el("h1", { class: "section-title" }, mod.name));
  r.appendChild(el("p", { class: "section-lede" }, mod.blurb));

  const entries = await loadEntriesForModule(slug);
  if (entries.length === 0) {
    r.appendChild(el("p", { class: "boot-note" },
      `${mod.name} arrives in Phase ${mod.phase}. Phase 1 has placeholder data only.`
    ));
    return;
  }

  const grid = el("div", { class: "card-grid" });
  for (const entry of entries) {
    const front = renderFront(entry);
    const link = el("a", { href: `#/card/${encodeURIComponent(entry.id)}`, style: "text-decoration:none;color:inherit;" });
    link.appendChild(front);
    grid.appendChild(link);
  }
  r.appendChild(grid);
}

async function viewCard(id) {
  let entry;
  try { entry = await loadEntry(id); }
  catch (e) { return viewNotFound(`card ${id}`); }

  clear();
  const r = root();

  const isInVitrine = vitrine.has(id);

  r.appendChild(el("div", { class: "detail-head" },
    el("a", { class: "detail-back-link", href: `#/${entry.module}` }, `← ${entry.module}`),
    el("div", { class: "detail-actions" },
      el("button", {
        type: "button",
        class: "detail-action",
        dataset: { state: isInVitrine ? "added" : "" },
        "data-card-id": id,
      }, isInVitrine ? "✓ in vitrine" : "+ add to vitrine"),
      el("button", { type: "button", class: "detail-action", "data-print-card": id }, "print this card")
    )
  ));

  const cards = el("div", { class: "detail-cards" });
  cards.appendChild(renderFront(entry, { statLimit: 8 }));
  cards.appendChild(await renderBack(entry));
  r.appendChild(cards);

  // Wire add-to-vitrine
  const addBtn = r.querySelector("[data-card-id]");
  if (addBtn) addBtn.addEventListener("click", () => {
    if (vitrine.has(id)) {
      vitrine.remove(id);
      addBtn.dataset.state = "";
      addBtn.textContent = "+ add to vitrine";
      toast("Removed from vitrine");
    } else {
      vitrine.add(id);
      addBtn.dataset.state = "added";
      addBtn.textContent = "✓ in vitrine";
      toast(`Added: ${entry.title}`);
    }
  });

  // Wire print this card (single-card sheet)
  const printBtn = r.querySelector("[data-print-card]");
  if (printBtn) printBtn.addEventListener("click", () => {
    location.hash = `#/print/${encodeURIComponent(id)}`;
  });
}

async function viewPrint(ids) {
  if (ids.length === 0) {
    clear();
    root().appendChild(el("p", { class: "boot-note" }, "Nothing to print. Add specimens to the vitrine first."));
    return;
  }

  const entries = [];
  for (const id of ids) {
    try { entries.push(await loadEntry(id)); } catch (e) { /* skip */ }
  }

  clear();
  const r = root();
  r.appendChild(el("div", { class: "detail-head" },
    el("a", { class: "detail-back-link", href: "#/" }, "← bench"),
    el("div", { class: "detail-actions" },
      el("button", { type: "button", class: "detail-action", onClick: () => window.print() }, "open print dialog")
    )
  ));

  r.appendChild(el("p", { class: "section-eyebrow" }, `${entries.length} specimen${entries.length === 1 ? "" : "s"} · ${Math.ceil(entries.length / 9)} sheet${Math.ceil(entries.length / 9) === 1 ? "" : "s"}`));

  // Build sheets of 9 fronts (front side), then 9 backs in mirrored order (back side)
  const wrap = el("div", { class: "print-preview" });
  let i = 0;
  while (i < entries.length) {
    const slice = entries.slice(i, i + 9);
    // Front sheet
    const frontSheet = el("div", { class: "print-sheet" });
    for (const e of slice) {
      const f = renderFront(e, { extraClass: "print-card", statLimit: 6 });
      // Add hairline vertical rules for crop guides
      f.appendChild(el("span", { class: "card-rule-v card-rule-v-l" }));
      f.appendChild(el("span", { class: "card-rule-v card-rule-v-r" }));
      frontSheet.appendChild(f);
    }
    // Pad to 9 cells so grid stays aligned
    for (let k = slice.length; k < 9; k++) frontSheet.appendChild(el("div", { class: "print-card", style: "border:1px dashed #ddd;" }));
    wrap.appendChild(frontSheet);

    // Back sheet. mirrored row order so duplex long-edge alignment works
    const backSheet = el("div", { class: "print-sheet" });
    const rows = [slice.slice(0,3), slice.slice(3,6), slice.slice(6,9)];
    for (const row of rows) {
      const mirrored = row.slice().reverse();
      for (let k = mirrored.length; k < 3; k++) mirrored.push(null);
      for (const e of mirrored) {
        if (!e) { backSheet.appendChild(el("div", { class: "print-card", style: "border:1px dashed #ddd;" })); continue; }
        const b = await renderBack(e, { extraClass: "print-card" });
        b.appendChild(el("span", { class: "card-rule-v card-rule-v-l" }));
        b.appendChild(el("span", { class: "card-rule-v card-rule-v-r" }));
        backSheet.appendChild(b);
      }
    }
    wrap.appendChild(backSheet);

    i += 9;
  }
  r.appendChild(wrap);
}

function viewNotFound(what) {
  clear();
  const r = root();
  r.appendChild(el("h1", { class: "section-title" }, "Not found"));
  r.appendChild(el("p", { class: "section-lede" }, `Could not find ${what}. Try the bench landing.`));
  r.appendChild(el("p", {}, el("a", { href: "#/" }, "← back to bench")));
}

/* ---------- dispatch ---------- */

async function dispatch() {
  const hash = location.hash.replace(/^#\/?/, "");
  const parts = hash.split("/").map(decodeURIComponent);

  if (!hash || hash === "/" || parts[0] === "") return viewLanding();

  if (parts[0] === "vitrine") {
    await viewLanding();
    // Open vitrine overlay
    const ev = new CustomEvent("crucible:open-vitrine");
    window.dispatchEvent(ev);
    return;
  }

  if (parts[0] === "card" && parts[1]) return viewCard(parts[1]);

  if (parts[0] === "print") {
    if (parts[1]) return viewPrint([parts[1]]);
    return viewPrint(vitrine.get());
  }

  // Module route: #/<module-slug>
  if (parts[0]) return viewModule(parts[0]);

  return viewLanding();
}

export function init() {
  window.addEventListener("hashchange", dispatch);
  dispatch();
}
