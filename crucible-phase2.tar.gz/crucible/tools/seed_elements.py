#!/usr/bin/env python3
"""
CRUCIBLE element seeder.

Generates modules/assay/data/<sym>.json for every element. Data sourced from
CRC Handbook of Chemistry and Physics values that are facts of nature
(densities, melting points, etc.) and engineering reference values from the
ASM Handbook where applicable.

This script is idempotent: rerun any time the schema changes. Hand edits to
generated files will be overwritten, so any per-element refinement should
go back into the ELEMENTS table here, not into the JSON.

Usage:
    python3 tools/seed_elements.py                    # write all element files
    python3 tools/seed_elements.py --dry-run          # show what would change
    python3 tools/seed_elements.py --keep Fe          # skip Fe, preserve hand edits
"""

import json
import sys
import argparse
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ASSAY_DATA = ROOT / "modules" / "assay" / "data"
MANIFEST = ROOT / "shared" / "data" / "manifest.json"


# -----------------------------------------------------------------------------
# Periodic table layout. (col, row) on an 18 by 9 grid where rows 8 and 9 hold
# the lanthanide and actinide series. La (57) and Ac (89) sit in group 3 of
# their natural periods; the f-block extends below.
# -----------------------------------------------------------------------------

POSITIONS = {}

# Period 1
POSITIONS[1]  = (1, 1, "s")
POSITIONS[2]  = (18, 1, "s")
# Period 2
for i, z in enumerate([3, 4]): POSITIONS[z] = (i + 1, 2, "s")
for i, z in enumerate([5, 6, 7, 8, 9, 10]): POSITIONS[z] = (i + 13, 2, "p")
# Period 3
for i, z in enumerate([11, 12]): POSITIONS[z] = (i + 1, 3, "s")
for i, z in enumerate([13, 14, 15, 16, 17, 18]): POSITIONS[z] = (i + 13, 3, "p")
# Period 4
for i, z in enumerate([19, 20]): POSITIONS[z] = (i + 1, 4, "s")
for i, z in enumerate(range(21, 31)): POSITIONS[z] = (i + 3, 4, "d")
for i, z in enumerate([31, 32, 33, 34, 35, 36]): POSITIONS[z] = (i + 13, 4, "p")
# Period 5
for i, z in enumerate([37, 38]): POSITIONS[z] = (i + 1, 5, "s")
for i, z in enumerate(range(39, 49)): POSITIONS[z] = (i + 3, 5, "d")
for i, z in enumerate([49, 50, 51, 52, 53, 54]): POSITIONS[z] = (i + 13, 5, "p")
# Period 6
POSITIONS[55] = (1, 6, "s")
POSITIONS[56] = (2, 6, "s")
POSITIONS[57] = (3, 6, "d")  # La sits in group 3; series shown below
for i, z in enumerate(range(72, 81)): POSITIONS[z] = (i + 4, 6, "d")
for i, z in enumerate([81, 82, 83, 84, 85, 86]): POSITIONS[z] = (i + 13, 6, "p")
# Lanthanides Ce..Lu in row 8, cols 3..16
for i, z in enumerate(range(58, 72)): POSITIONS[z] = (i + 3, 8, "f")
# Period 7
POSITIONS[87] = (1, 7, "s")
POSITIONS[88] = (2, 7, "s")
POSITIONS[89] = (3, 7, "d")
for i, z in enumerate(range(104, 113)): POSITIONS[z] = (i + 4, 7, "d")
for i, z in enumerate([113, 114, 115, 116, 117, 118]): POSITIONS[z] = (i + 13, 7, "p")
# Actinides Th..Lr in row 9, cols 3..16
for i, z in enumerate(range(90, 104)): POSITIONS[z] = (i + 3, 9, "f")


def derive_group(z):
    col, row, _ = POSITIONS[z]
    if row in (8, 9):
        return None  # f-block has no formal IUPAC group
    return col


# -----------------------------------------------------------------------------
# Category tags applied to each element. Multi-tag elements are noted.
# -----------------------------------------------------------------------------

CATEGORY_TAGS = {
    "alkali-metal":       ["alkali metal", "s-block", "reactive"],
    "alkaline-earth":     ["alkaline earth", "s-block"],
    "transition-metal":   ["transition metal", "d-block"],
    "post-transition":    ["post-transition metal", "p-block"],
    "metalloid":          ["metalloid", "p-block"],
    "reactive-nonmetal":  ["nonmetal", "reactive"],
    "halogen":            ["halogen", "nonmetal"],
    "noble-gas":          ["noble gas", "inert"],
    "lanthanide":         ["lanthanide", "f-block", "rare earth"],
    "actinide":           ["actinide", "f-block", "radioactive"],
    "unknown":            ["uncharacterized", "superheavy"],
}


# -----------------------------------------------------------------------------
# Element data.
#
# Field reference:
#   Z          atomic number
#   sym        chemical symbol
#   name       full name
#   mass       standard atomic weight (u)
#   category   one of CATEGORY_TAGS keys
#   density    g/cm³ at STP (gases as gas, solids/liquids as condensed)
#   mp         melting point in °C
#   bp         boiling point in °C
#   eneg       Pauling electronegativity (None if no commonly cited value)
#   thermal    thermal conductivity at 300 K, W/m·K
#   resist     electrical resistivity at 20 °C, nΩ·m  (metals only)
#   modulus    Young's modulus, GPa (metals/metalloids only)
#   mohs       Mohs hardness
#   crystal    short crystal structure descriptor
#   config     electron configuration (display string)
#   tags       extra tags beyond the category tags
#   body       prose body for the card back. Empty string keeps a stub.
#   sources    source keys; default ["crc-104"] if omitted
# -----------------------------------------------------------------------------

ELEMENTS = [
    # ---------- Period 1 ----------
    {"Z": 1, "sym": "H", "name": "Hydrogen", "mass": 1.008, "category": "reactive-nonmetal",
     "density": 0.00008988, "mp": -259.16, "bp": -252.879, "eneg": 2.20,
     "thermal": 0.1805, "config": "1s¹",
     "tags": ["diatomic", "fuel", "lightest", "fusion"],
     "body": "Most abundant element in the universe by atom count, the original light-element fuel of stars. On Earth almost all of it is locked up in water and hydrocarbons; molecular H₂ has to be liberated by electrolysis, steam reforming, or partial oxidation.\n\nIndustrially used as a reductant (ore refining, hydrogenation of fats and oils), as a feedstock (ammonia synthesis dominates global demand), and as a cryogen. Storage is the hard problem: low volumetric density and embrittlement of carbon steels and high-strength alloys."},

    {"Z": 2, "sym": "He", "name": "Helium", "mass": 4.0026, "category": "noble-gas",
     "density": 0.0001785, "mp": None, "bp": -268.928, "eneg": None,
     "thermal": 0.1513, "config": "1s²",
     "tags": ["cryogen", "lifting gas", "leak detection"],
     "body": "Does not freeze at atmospheric pressure even at absolute zero. Liquid helium-4 is the working cryogen behind superconducting magnets (MRI, NMR, particle accelerators).\n\nThe Earth's supply is generated by alpha decay of uranium and thorium, captured in natural gas fields, and irrecoverably lost once vented to atmosphere. Conservation matters."},

    # ---------- Period 2 ----------
    {"Z": 3, "sym": "Li", "name": "Lithium", "mass": 6.94, "category": "alkali-metal",
     "density": 0.534, "mp": 180.50, "bp": 1342, "eneg": 0.98,
     "thermal": 84.8, "resist": 92.8, "modulus": 4.9, "mohs": 0.6,
     "crystal": "BCC", "config": "[He] 2s¹",
     "tags": ["battery", "reactive", "lightest metal", "flux"],
     "body": "Lightest metal and lowest-density solid element at room temperature. Stored under mineral oil because it tarnishes and burns in air with a crimson flame.\n\nIndustrially dominated by lithium-ion battery cathodes and electrolytes. Also used as a flux in glass and ceramics, and as a moderator and tritium-breeder in some reactor designs."},

    {"Z": 4, "sym": "Be", "name": "Beryllium", "mass": 9.0122, "category": "alkaline-earth",
     "density": 1.85, "mp": 1287, "bp": 2469, "eneg": 1.57,
     "thermal": 200, "resist": 36, "modulus": 287, "mohs": 5.5,
     "crystal": "HCP", "config": "[He] 2s²",
     "tags": ["aerospace", "stiff", "toxic dust", "x-ray window"],
     "body": "Extreme stiffness-to-weight ratio. Higher specific stiffness than steel, aluminum, or titanium, which is why it lives in satellite mirrors, gyroscope housings, and aerospace structural inserts.\n\n**Beryllium dust and fumes are highly toxic.** Chronic beryllium disease (berylliosis) is a sensitization-driven lung disease with no known cure. Any machining requires HEPA capture and respiratory protection."},

    {"Z": 5, "sym": "B", "name": "Boron", "mass": 10.81, "category": "metalloid",
     "density": 2.34, "mp": 2076, "bp": 3927, "eneg": 2.04,
     "thermal": 27.4, "modulus": 320, "mohs": 9.3,
     "crystal": "rhombohedral", "config": "[He] 2s² 2p¹",
     "tags": ["semiconductor dopant", "neutron absorber", "borosilicate"],
     "body": "Hard, brittle, and an effective neutron absorber (B-10 isotope). Industrial uses split between borosilicate glass (Pyrex), neutron-shielding compounds, and trace doping of silicon for p-type semiconductors.\n\nBoron carbide (B₄C) is one of the hardest known materials and shows up in body armor and abrasive blast nozzles."},

    {"Z": 6, "sym": "C", "name": "Carbon", "mass": 12.011, "category": "reactive-nonmetal",
     "density": 2.267, "mp": 3550, "bp": 4827, "eneg": 2.55,
     "thermal": 119, "mohs": 0.5, "modulus": 1050,
     "crystal": "hexagonal (graphite) / FCC (diamond)", "config": "[He] 2s² 2p²",
     "tags": ["diamond", "graphite", "fullerene", "graphene", "structural"],
     "body": "Backbone of all known life and of most engineering polymers. Three industrially important allotropes: graphite (soft, conductive, lubricant), diamond (hardest natural material, abrasive and optical), and the engineered carbons (CNT, graphene, fullerene) where the same hexagonal lattice is rolled or stacked into nanoscale forms.\n\nIn ferrous metallurgy, carbon is the alloying element. Less than 0.02% C is pure iron; 0.02 to 2.1% C is steel; above 2.1% C the metal is cast iron. Carbon controls hardenability and is the lever every blacksmith and heat-treater pulls."},

    {"Z": 7, "sym": "N", "name": "Nitrogen", "mass": 14.007, "category": "reactive-nonmetal",
     "density": 0.0012506, "mp": -210.0, "bp": -195.795, "eneg": 3.04,
     "thermal": 0.02583, "config": "[He] 2s² 2p³",
     "tags": ["diatomic", "atmospheric", "inert blanket", "fertilizer"],
     "body": "78% of the atmosphere by volume, and bound up in nearly all biology via the amino group. The N₂ triple bond is among the strongest in chemistry, which is why the Haber-Bosch process took most of human history to develop and now accounts for 1 to 2% of global energy consumption.\n\nLiquid nitrogen is the workhorse industrial cryogen for shrink-fitting interference assemblies, food preservation, and IC test chambers."},

    {"Z": 8, "sym": "O", "name": "Oxygen", "mass": 15.999, "category": "reactive-nonmetal",
     "density": 0.001429, "mp": -218.79, "bp": -182.962, "eneg": 3.44,
     "thermal": 0.02658, "config": "[He] 2s² 2p⁴",
     "tags": ["diatomic", "oxidizer", "combustion", "respiration"],
     "body": "The default oxidizer that everything else weighs in against. Steelmaking (basic oxygen furnace), welding (oxy-fuel), and life support all consume bulk gaseous oxygen. Liquid oxygen (LOX) is a rocket propellant oxidizer.\n\nAt the materials level, oxygen is what makes corrosion happen. Almost everything in **ETCH** and most of what's interesting in **ELECTRO** is fundamentally about controlling where and how oxidation occurs."},

    {"Z": 9, "sym": "F", "name": "Fluorine", "mass": 18.998, "category": "halogen",
     "density": 0.001696, "mp": -219.67, "bp": -188.11, "eneg": 3.98,
     "thermal": 0.0277, "config": "[He] 2s² 2p⁵",
     "tags": ["diatomic", "most electronegative", "etchant", "PTFE"],
     "body": "Most electronegative element. Reacts with nearly everything except a few noble gases and saturated fluorocarbons. Industrially handled as HF (etchant for glass and silicon) or as SF₆ (gaseous dielectric) or bound into PTFE (Teflon)."},

    {"Z": 10, "sym": "Ne", "name": "Neon", "mass": 20.180, "category": "noble-gas",
     "density": 0.0008999, "mp": -248.59, "bp": -246.05, "eneg": None,
     "thermal": 0.0491, "config": "[He] 2s² 2p⁶",
     "tags": ["noble gas", "signage", "laser gas"],
     "body": "Inert and characteristically orange-red when excited. Used in display signage, HeNe lasers, and high-voltage indicators."},

    # ---------- Period 3 ----------
    {"Z": 11, "sym": "Na", "name": "Sodium", "mass": 22.990, "category": "alkali-metal",
     "density": 0.968, "mp": 97.794, "bp": 882.940, "eneg": 0.93,
     "thermal": 142, "resist": 47.7, "modulus": 10, "mohs": 0.5,
     "crystal": "BCC", "config": "[Ne] 3s¹",
     "tags": ["reactive", "vapor lamp", "sodium chloride", "coolant"],
     "body": "Soft, silver-white, cuts with a knife and tarnishes in seconds in air. Stored under kerosene. Used as a high-temperature liquid coolant in fast breeder reactors and in some specialty heat-treating bath chemistries.\n\nSodium-vapor lamps are the source of that monochromatic orange streetlight at 589 nm, which is why color-rendering under them is terrible."},

    {"Z": 12, "sym": "Mg", "name": "Magnesium", "mass": 24.305, "category": "alkaline-earth",
     "density": 1.738, "mp": 650, "bp": 1090, "eneg": 1.31,
     "thermal": 156, "resist": 43.9, "modulus": 45, "mohs": 2.5,
     "crystal": "HCP", "config": "[Ne] 3s²",
     "tags": ["lightweight structural", "die casting", "flammable", "aerospace"],
     "body": "Lightest structural metal (around 1.74 g/cm³, two-thirds the density of aluminum). Stiffness is modest but the specific stiffness makes it competitive for housings and brackets in aerospace and electronics.\n\n**Fire behavior is the hazard.** Magnesium dust and fines ignite readily and burn at 3,100 °C; water makes it worse. Use Class D extinguishers (graphite, sodium chloride). Bulk parts and chips are far safer than dust."},

    {"Z": 13, "sym": "Al", "name": "Aluminum", "mass": 26.982, "category": "post-transition",
     "density": 2.70, "mp": 660.32, "bp": 2470, "eneg": 1.61,
     "thermal": 237, "resist": 26.5, "modulus": 70, "mohs": 2.75,
     "crystal": "FCC", "config": "[Ne] 3s² 3p¹",
     "tags": ["structural", "corrosion resistant", "recyclable", "extrusion", "anodize"],
     "body": "Second most-used structural metal after steel. Forms a tenacious oxide film that resists most environmental corrosion, the same oxide that **ELECTRO** plays with in anodizing to grow thicker, dyeable, and harder.\n\nThe 6000 series (Al-Mg-Si) is the default extrudable architectural/automotive alloy; the 7000 series (Al-Zn) is the aerospace high-strength choice; cast 356 (Al-Si-Mg) handles most of the wheel and housing castings. Welds well with TIG/MIG in argon, joins poorly to steel by fusion (use rivets, friction-stir, or adhesive)."},

    {"Z": 14, "sym": "Si", "name": "Silicon", "mass": 28.085, "category": "metalloid",
     "density": 2.3290, "mp": 1414, "bp": 3265, "eneg": 1.90,
     "thermal": 149, "modulus": 170, "mohs": 6.5,
     "crystal": "diamond cubic", "config": "[Ne] 3s² 3p²",
     "tags": ["semiconductor", "wafer", "glass", "alloy", "abundant"],
     "body": "Second most abundant element in the Earth's crust. The semiconductor industry runs on float-zone and Czochralski monocrystalline silicon doped with B (p-type) or P/As (n-type).\n\nIn metallurgy, silicon is a key alloying element in cast aluminum (improves fluidity) and in silicon steel (the laminations of every electrical machine, where Si raises resistivity to cut eddy-current losses)."},

    {"Z": 15, "sym": "P", "name": "Phosphorus", "mass": 30.974, "category": "reactive-nonmetal",
     "density": 1.82, "mp": 44.15, "bp": 280.5, "eneg": 2.19,
     "thermal": 0.236, "config": "[Ne] 3s² 3p³",
     "tags": ["fertilizer", "match", "alloying", "phosphor"],
     "body": "Three primary allotropes: white (pyrophoric, glow-in-dark, highly toxic), red (match-strike, stable in air), and black (least reactive, semiconducting). Industrially most P moves through phosphate rock for fertilizer.\n\nAlloying use in metallurgy is small and usually a contaminant; in steels above ~0.05% P, cold shortness sets in. In bronze, intentional P additions (phosphor bronze) act as a deoxidizer and improve spring properties."},

    {"Z": 16, "sym": "S", "name": "Sulfur", "mass": 32.06, "category": "reactive-nonmetal",
     "density": 2.067, "mp": 115.21, "bp": 444.61, "eneg": 2.58,
     "thermal": 0.205, "mohs": 2.0,
     "crystal": "orthorhombic", "config": "[Ne] 3s² 3p⁴",
     "tags": ["vulcanization", "sulfuric acid", "machinability", "machining steels"],
     "body": "Yellow brittle crystals; basis of sulfuric acid (the highest-volume industrial chemical by mass). Vulcanization of rubber is essentially sulfur-crosslinking polyisoprene.\n\nIn steels, sulfur is normally a contaminant that causes hot shortness, but in **free-machining grades** (12L14, 1215, etc.) it is added intentionally to break up chips and lubricate the cut. Trade-off: weldability and ductility are reduced."},

    {"Z": 17, "sym": "Cl", "name": "Chlorine", "mass": 35.45, "category": "halogen",
     "density": 0.003214, "mp": -101.5, "bp": -34.04, "eneg": 3.16,
     "thermal": 0.0089, "config": "[Ne] 3s² 3p⁵",
     "tags": ["halogen", "disinfectant", "PVC", "ferric chloride"],
     "body": "Greenish-yellow gas, choking smell. Industrially the feedstock for PVC, chlorinated solvents, and water disinfection. In **ETCH**, ferric chloride solutions are the standard PCB etchant and a useful copper and brass etchant."},

    {"Z": 18, "sym": "Ar", "name": "Argon", "mass": 39.948, "category": "noble-gas",
     "density": 0.0017837, "mp": -189.34, "bp": -185.848, "eneg": None,
     "thermal": 0.01772, "config": "[Ne] 3s² 3p⁶",
     "tags": ["noble gas", "shielding gas", "inert atmosphere", "TIG"],
     "body": "Inexpensive inert gas, makes up about 0.93% of the atmosphere. The default TIG and MIG shielding gas for steel, aluminum, and titanium welding. Also used in industrial heat-treat atmospheres where nitrogen would react (e.g., titanium parts)."},

    # ---------- Period 4 ----------
    {"Z": 19, "sym": "K", "name": "Potassium", "mass": 39.098, "category": "alkali-metal",
     "density": 0.862, "mp": 63.5, "bp": 759, "eneg": 0.82,
     "thermal": 102.5, "resist": 72.0, "modulus": 3.5, "mohs": 0.4,
     "crystal": "BCC", "config": "[Ar] 4s¹",
     "tags": ["reactive", "fertilizer", "biological"],
     "body": "Softer and more reactive than sodium. Reacts violently with water, ignites hydrogen on contact. Industrially mostly moves through potash for fertilizer."},

    {"Z": 20, "sym": "Ca", "name": "Calcium", "mass": 40.078, "category": "alkaline-earth",
     "density": 1.55, "mp": 842, "bp": 1484, "eneg": 1.00,
     "thermal": 201, "resist": 33.6, "modulus": 20, "mohs": 1.75,
     "crystal": "FCC", "config": "[Ar] 4s²",
     "tags": ["biological", "cement", "deoxidizer", "abundant"],
     "body": "Fifth most abundant element in the crust by mass; abundant in limestone, gypsum, and bone. Calcium oxide (lime) is the binder behind every Portland cement structure. Calcium is also used as a deoxidizer and desulfurizer in steel and as a reductant for producing other reactive metals (Cr, Zr, U)."},

    {"Z": 21, "sym": "Sc", "name": "Scandium", "mass": 44.956, "category": "transition-metal",
     "density": 2.985, "mp": 1541, "bp": 2836, "eneg": 1.36,
     "thermal": 15.8, "resist": 562, "modulus": 74, "mohs": None,
     "crystal": "HCP", "config": "[Ar] 3d¹ 4s²",
     "tags": ["rare", "aerospace alloy", "Al-Sc"],
     "body": "Trace additions to aluminum produce Al-Sc alloys with exceptional weldability and fine grain. Used in high-end aerospace (some Russian fighter components) and in premium cycling and sporting goods."},

    {"Z": 22, "sym": "Ti", "name": "Titanium", "mass": 47.867, "category": "transition-metal",
     "density": 4.506, "mp": 1668, "bp": 3287, "eneg": 1.54,
     "thermal": 21.9, "resist": 420, "modulus": 116, "mohs": 6.0,
     "crystal": "HCP (α) / BCC (β)", "config": "[Ar] 3d² 4s²",
     "tags": ["structural", "corrosion resistant", "biomedical", "aerospace"],
     "body": "Strength comparable to medium-carbon steel at 60% of the density. Forms a passivating TiO₂ layer that survives seawater, chlorides, and most biological environments, which is why it owns medical implants and chemical-process piping.\n\n**Grade 2** is the unalloyed commercially pure workhorse. **Grade 5 (Ti-6Al-4V)** is the structural alloy: solution-treat above the beta transus (about 995 °C), quench, age at 480 to 595 °C. Machine slow with sharp tools and copious coolant; titanium work-hardens fast and ignites in chip form."},

    {"Z": 23, "sym": "V", "name": "Vanadium", "mass": 50.942, "category": "transition-metal",
     "density": 6.0, "mp": 1910, "bp": 3407, "eneg": 1.63,
     "thermal": 30.7, "resist": 197, "modulus": 128, "mohs": 6.7,
     "crystal": "BCC", "config": "[Ar] 3d³ 4s²",
     "tags": ["alloying", "tool steel", "catalyst"],
     "body": "Almost never used as a pure metal. Strong carbide former in tool steels (M2, M4, T15), where vanadium carbides provide the bulk of the wear resistance that lets the tool keep an edge."},

    {"Z": 24, "sym": "Cr", "name": "Chromium", "mass": 51.996, "category": "transition-metal",
     "density": 7.19, "mp": 1907, "bp": 2671, "eneg": 1.66,
     "thermal": 93.9, "resist": 125, "modulus": 279, "mohs": 8.5,
     "crystal": "BCC", "config": "[Ar] 3d⁵ 4s¹",
     "tags": ["stainless", "plating", "hard chrome", "passivation"],
     "body": "The metal that makes stainless stainless. Above about 10.5% Cr in iron, a self-healing chromium-rich oxide forms that passivates the surface against most aqueous corrosion.\n\nHard chrome plating (decorative chrome is something else, much thinner) gives a surface of 850 to 1050 HV used on hydraulic rods, mold cavities, and bearing journals. The plating chemistry uses hexavalent chromium, which is highly carcinogenic; trivalent processes are replacing it where they perform adequately."},

    {"Z": 25, "sym": "Mn", "name": "Manganese", "mass": 54.938, "category": "transition-metal",
     "density": 7.21, "mp": 1246, "bp": 2061, "eneg": 1.55,
     "thermal": 7.81, "resist": 1440, "modulus": 198, "mohs": 6.0,
     "crystal": "cubic (complex)", "config": "[Ar] 3d⁵ 4s²",
     "tags": ["alloying", "deoxidizer", "hadfield steel"],
     "body": "Universal steel alloying element. Acts as a deoxidizer and desulfurizer (forms MnS instead of FeS, which is hot-short), and at 0.5 to 2% Mn raises hardenability and tensile strength noticeably.\n\n**Hadfield steel** (around 12 to 14% Mn) work-hardens dramatically on impact, which is why it appears in railway crossings, rock crusher liners, and military tank tracks."},

    # Z=26 (Fe) is handled separately, kept verbatim from the existing fe.json hand edit.

    {"Z": 27, "sym": "Co", "name": "Cobalt", "mass": 58.933, "category": "transition-metal",
     "density": 8.90, "mp": 1495, "bp": 2927, "eneg": 1.88,
     "thermal": 100, "resist": 62.4, "modulus": 209, "mohs": 5.0,
     "crystal": "HCP (α) / FCC (β)", "config": "[Ar] 3d⁷ 4s²",
     "tags": ["superalloy", "magnet", "carbide binder", "battery"],
     "body": "Critical alloying element in nickel-based superalloys (Inconel, Waspaloy) and the binder phase in tungsten carbide cutting tools (typically 6 to 12% Co). Also the magnet metal for Alnico and rare-earth Sm-Co magnets, which keep their magnetism at temperatures NdFeB cannot."},

    {"Z": 28, "sym": "Ni", "name": "Nickel", "mass": 58.693, "category": "transition-metal",
     "density": 8.908, "mp": 1455, "bp": 2913, "eneg": 1.91,
     "thermal": 90.9, "resist": 69.3, "modulus": 200, "mohs": 4.0,
     "crystal": "FCC", "config": "[Ar] 3d⁸ 4s²",
     "tags": ["stainless", "superalloy", "plating", "battery"],
     "body": "Stabilizes the austenitic (FCC) phase in stainless steels, which is why 18-8 (304-series) stainless contains 8% Ni: the result is non-magnetic, tough at cryogenic temperatures, and excellent for food and chemical service.\n\nPure Ni and Ni-Cu (Monel) handle reducing acid environments and seawater that defeat stainless. The Ni-Cr-Fe and Ni-Cr-Mo superalloys (Inconel 600, 625, 718, Hastelloy) extend that into high-temperature service up to 1100 °C."},

    {"Z": 29, "sym": "Cu", "name": "Copper", "mass": 63.546, "category": "transition-metal",
     "density": 8.96, "mp": 1084.62, "bp": 2562, "eneg": 1.90,
     "thermal": 401, "resist": 16.78, "modulus": 110, "mohs": 3.0,
     "crystal": "FCC", "config": "[Ar] 3d¹⁰ 4s¹",
     "tags": ["conductor", "antimicrobial", "brass", "bronze", "plumbing"],
     "body": "Second-best electrical conductor by volume after silver, and the only one industry can afford to wire a planet with. Excellent thermal conductor (heat sinks, cookware, brewery vessels), inherently antimicrobial (medical touch surfaces), and the base metal of brass (Cu-Zn) and bronze (Cu-Sn).\n\nWork-hardens significantly; annealing schedule for soft pulls is 425 to 650 °C with rapid cool. For electrical service, **C11000 (ETP)** is the volume grade and **C10100 (OFHC)** is the oxygen-free choice for hydrogen-bearing or vacuum service."},

    {"Z": 30, "sym": "Zn", "name": "Zinc", "mass": 65.38, "category": "post-transition",
     "density": 7.14, "mp": 419.527, "bp": 907, "eneg": 1.65,
     "thermal": 116, "resist": 59.0, "modulus": 108, "mohs": 2.5,
     "crystal": "HCP", "config": "[Ar] 3d¹⁰ 4s²",
     "tags": ["galvanize", "die casting", "brass", "sacrificial anode"],
     "body": "Two dominant uses: galvanizing (hot-dip or electroplated onto steel as a sacrificial anode) and as the second component of brass (typically 5 to 40% Zn in copper).\n\n**Zamak die-casting alloys** (Zn-Al-Cu-Mg) are the default for high-volume cast hardware: hose fittings, lock bodies, automotive trim. Zinc melts at 419 °C, which makes its die-casting tooling cheap and long-lived relative to aluminum or magnesium."},

    {"Z": 31, "sym": "Ga", "name": "Gallium", "mass": 69.723, "category": "post-transition",
     "density": 5.91, "mp": 29.76, "bp": 2204, "eneg": 1.81,
     "thermal": 40.6, "resist": 270, "modulus": 9.8, "mohs": 1.5,
     "crystal": "orthorhombic", "config": "[Ar] 3d¹⁰ 4s² 4p¹",
     "tags": ["semiconductor", "GaAs", "low melting"],
     "body": "Melts in your hand (29.76 °C). Used in LEDs (GaN, GaAs), photovoltaics, and as a substitute for mercury in some thermometers. Liquid Ga embrittles aluminum and many other metals; keep it off tooling."},

    {"Z": 32, "sym": "Ge", "name": "Germanium", "mass": 72.630, "category": "metalloid",
     "density": 5.323, "mp": 938.25, "bp": 2833, "eneg": 2.01,
     "thermal": 60.2, "modulus": 103, "mohs": 6.0,
     "crystal": "diamond cubic", "config": "[Ar] 3d¹⁰ 4s² 4p²",
     "tags": ["semiconductor", "infrared optics", "fiber"],
     "body": "Original transistor material before silicon dominated. Now appears in infrared optics (Ge is transparent in the 2 to 14 μm IR window) and as a dopant in optical fiber cores to raise the refractive index."},

    {"Z": 33, "sym": "As", "name": "Arsenic", "mass": 74.922, "category": "metalloid",
     "density": 5.727, "mp": 817, "bp": 614, "eneg": 2.18,
     "thermal": 50.2, "modulus": 8, "mohs": 3.5,
     "crystal": "rhombohedral", "config": "[Ar] 3d¹⁰ 4s² 4p³",
     "tags": ["semiconductor dopant", "GaAs", "toxic"],
     "body": "Sublimes at 615 °C (no liquid phase at atmospheric pressure). Industrial use is dominated by gallium arsenide for high-frequency electronics and LEDs, and as an n-type dopant in silicon. **Highly toxic, carcinogenic; OSHA PEL is very low.**"},

    {"Z": 34, "sym": "Se", "name": "Selenium", "mass": 78.971, "category": "reactive-nonmetal",
     "density": 4.81, "mp": 220.8, "bp": 685, "eneg": 2.55,
     "thermal": 0.519, "mohs": 2.0,
     "crystal": "hexagonal", "config": "[Ar] 3d¹⁰ 4s² 4p⁴",
     "tags": ["photoconductor", "free-machining"],
     "body": "Photoconductor (resistance drops in light), historically central to xerographic copiers and selenium rectifiers. Added in small amounts to free-machining stainless (303-Se) and brass to improve machinability."},

    {"Z": 35, "sym": "Br", "name": "Bromine", "mass": 79.904, "category": "halogen",
     "density": 3.1028, "mp": -7.2, "bp": 58.8, "eneg": 2.96,
     "thermal": 0.122, "config": "[Ar] 3d¹⁰ 4s² 4p⁵",
     "tags": ["halogen", "flame retardant", "fumigant"],
     "body": "Only liquid nonmetal at room temperature, deep red-brown with corrosive fumes. Used in flame retardants (now largely being phased out for environmental reasons), photographic emulsions, and brine drilling fluids."},

    {"Z": 36, "sym": "Kr", "name": "Krypton", "mass": 83.798, "category": "noble-gas",
     "density": 0.003733, "mp": -157.37, "bp": -153.415, "eneg": 3.00,
     "thermal": 0.00943, "config": "[Ar] 3d¹⁰ 4s² 4p⁶",
     "tags": ["noble gas", "lighting", "laser"],
     "body": "Used in some specialty lighting (krypton arc lamps, flash tubes) and excimer lasers (KrF for deep UV photolithography)."},

    # ---------- Period 5 ----------
    {"Z": 37, "sym": "Rb", "name": "Rubidium", "mass": 85.468, "category": "alkali-metal",
     "density": 1.532, "mp": 39.31, "bp": 688, "eneg": 0.82,
     "thermal": 58.2, "resist": 128, "modulus": 2.4, "mohs": 0.3,
     "crystal": "BCC", "config": "[Kr] 5s¹",
     "tags": ["reactive", "atomic clock"],
     "body": "Rb-87 hyperfine transition is the basis of compact atomic clocks (GPS satellites, telecom timing). Otherwise mostly a research curiosity."},

    {"Z": 38, "sym": "Sr", "name": "Strontium", "mass": 87.62, "category": "alkaline-earth",
     "density": 2.64, "mp": 777, "bp": 1377, "eneg": 0.95,
     "thermal": 35.4, "modulus": None, "mohs": 1.5,
     "crystal": "FCC", "config": "[Kr] 5s²",
     "tags": ["pyrotechnic", "ferrite magnet"],
     "body": "Burns crimson, which is why every red firework or marine flare contains a strontium salt. Industrially, strontium ferrite is the most common ceramic magnet material (refrigerator magnets, low-cost motor magnets)."},

    {"Z": 39, "sym": "Y", "name": "Yttrium", "mass": 88.906, "category": "transition-metal",
     "density": 4.472, "mp": 1522, "bp": 3345, "eneg": 1.22,
     "thermal": 17.2, "resist": 596, "modulus": 64, "mohs": None,
     "crystal": "HCP", "config": "[Kr] 4d¹ 5s²",
     "tags": ["YAG laser", "phosphor", "YBCO superconductor"],
     "body": "Host crystal in YAG (yttrium aluminum garnet) laser gain media, dopant in red phosphors, and the Y in YBCO high-temperature superconductors (Tc around 92 K, well above liquid-nitrogen temperature)."},

    {"Z": 40, "sym": "Zr", "name": "Zirconium", "mass": 91.224, "category": "transition-metal",
     "density": 6.52, "mp": 1855, "bp": 4377, "eneg": 1.33,
     "thermal": 22.7, "resist": 421, "modulus": 88, "mohs": 5.0,
     "crystal": "HCP (α) / BCC (β)", "config": "[Kr] 4d² 5s²",
     "tags": ["nuclear", "corrosion resistant", "ceramic", "implant"],
     "body": "Very low neutron-absorption cross section makes Zircaloy (Zr with traces of Sn, Fe, Cr) the standard cladding for uranium oxide fuel rods in light-water reactors. Also used for chemical-process equipment that handles hot acids that defeat stainless and titanium.\n\nZirconia (ZrO₂), the ceramic, is the workhorse dental crown material and a structural ceramic for engine components."},

    {"Z": 41, "sym": "Nb", "name": "Niobium", "mass": 92.906, "category": "transition-metal",
     "density": 8.57, "mp": 2477, "bp": 4744, "eneg": 1.6,
     "thermal": 53.7, "resist": 152, "modulus": 105, "mohs": 6.0,
     "crystal": "BCC", "config": "[Kr] 4d⁴ 5s¹",
     "tags": ["superconductor", "HSLA", "superalloy"],
     "body": "Nb-Ti and Nb-Sn are the workhorse superconductors for MRI and high-energy physics magnets (Tc 9 to 18 K). Small additions to steel (HSLA grades, around 0.1% Nb) refine grain and roughly double yield strength without compromising weldability."},

    {"Z": 42, "sym": "Mo", "name": "Molybdenum", "mass": 95.95, "category": "transition-metal",
     "density": 10.28, "mp": 2623, "bp": 4639, "eneg": 2.16,
     "thermal": 138, "resist": 53.4, "modulus": 329, "mohs": 5.5,
     "crystal": "BCC", "config": "[Kr] 4d⁵ 5s¹",
     "tags": ["alloying", "high temperature", "stainless", "tool steel"],
     "body": "High-temperature structural metal (melts at 2623 °C, second only to W and Re among engineering metals). Furnace heating elements, glass-melting electrodes, and the high-temperature parts of vacuum furnaces.\n\nIn steels, Mo additions of 0.2 to 5% dramatically improve hardenability, high-temperature creep, and pitting resistance. **4140** is Cr-Mo, **316 stainless** uses Mo for chloride pitting resistance, and most tool steels carry several percent."},

    {"Z": 43, "sym": "Tc", "name": "Technetium", "mass": 98, "category": "transition-metal",
     "density": 11, "mp": 2157, "bp": 4265, "eneg": 1.9,
     "thermal": 50.6, "resist": None, "modulus": None, "mohs": None,
     "crystal": "HCP", "config": "[Kr] 4d⁵ 5s²",
     "tags": ["radioactive", "medical imaging"],
     "body": "First synthetically produced element; all isotopes are radioactive. Tc-99m is the most widely used medical imaging radionuclide (SPECT)."},

    {"Z": 44, "sym": "Ru", "name": "Ruthenium", "mass": 101.07, "category": "transition-metal",
     "density": 12.45, "mp": 2334, "bp": 4150, "eneg": 2.2,
     "thermal": 117, "resist": 71, "modulus": 447, "mohs": 6.5,
     "crystal": "HCP", "config": "[Kr] 4d⁷ 5s¹",
     "tags": ["catalyst", "platinum group", "fountain pen"],
     "body": "Platinum-group metal. Used in chemistry catalysts, in hard-drive recording media (Ru thin films), and historically as an additive to fountain pen nib tips."},

    {"Z": 45, "sym": "Rh", "name": "Rhodium", "mass": 102.91, "category": "transition-metal",
     "density": 12.41, "mp": 1964, "bp": 3695, "eneg": 2.28,
     "thermal": 150, "resist": 43.3, "modulus": 380, "mohs": 6.0,
     "crystal": "FCC", "config": "[Kr] 4d⁸ 5s¹",
     "tags": ["catalyst", "platinum group", "jewelry plating"],
     "body": "One of the rarest and most expensive metals on Earth ($10k+/oz at peak). The active component in three-way catalytic converters that reduce NOx. Also the bright reflective plating on white-gold jewelry."},

    {"Z": 46, "sym": "Pd", "name": "Palladium", "mass": 106.42, "category": "transition-metal",
     "density": 12.02, "mp": 1554.9, "bp": 2963, "eneg": 2.20,
     "thermal": 71.8, "resist": 105.4, "modulus": 121, "mohs": 4.75,
     "crystal": "FCC", "config": "[Kr] 4d¹⁰",
     "tags": ["catalyst", "platinum group", "hydrogen", "dental"],
     "body": "Platinum-group metal with a remarkable ability to absorb hydrogen (up to 900 times its volume), the basis of palladium hydrogen filters. Catalytic converter element and a common dental-alloy component."},

    {"Z": 47, "sym": "Ag", "name": "Silver", "mass": 107.87, "category": "transition-metal",
     "density": 10.49, "mp": 961.78, "bp": 2162, "eneg": 1.93,
     "thermal": 429, "resist": 15.87, "modulus": 83, "mohs": 2.5,
     "crystal": "FCC", "config": "[Kr] 4d¹⁰ 5s¹",
     "tags": ["conductor", "antimicrobial", "photographic", "brazing"],
     "body": "Best electrical and thermal conductor of any element. The catch is cost and the soft sulfide tarnish (Ag₂S, the gray film) that does not protect against further attack but interferes with optical reflectivity and contact resistance.\n\nKey roles: silver brazing alloys (BAg series, 30 to 70% Ag, melting 600 to 800 °C), photographic silver halides (still the basis of all conventional film, see **DARKROOM**), high-end electrical contacts, and antimicrobial wound dressings."},

    {"Z": 48, "sym": "Cd", "name": "Cadmium", "mass": 112.41, "category": "post-transition",
     "density": 8.65, "mp": 321.07, "bp": 767, "eneg": 1.69,
     "thermal": 96.6, "resist": 72.7, "modulus": 50, "mohs": 2.0,
     "crystal": "HCP", "config": "[Kr] 4d¹⁰ 5s²",
     "tags": ["plating", "battery", "toxic", "aerospace fastener"],
     "body": "Used historically for corrosion-resistant plating on aerospace fasteners and in Ni-Cd rechargeable batteries. **Highly toxic** (renal and bone toxicity, carcinogen); plating is being phased out in favor of zinc-nickel and aluminum coatings. NiCd batteries largely replaced by NiMH and Li-ion."},

    {"Z": 49, "sym": "In", "name": "Indium", "mass": 114.82, "category": "post-transition",
     "density": 7.31, "mp": 156.6, "bp": 2072, "eneg": 1.78,
     "thermal": 81.8, "resist": 83.7, "modulus": 11, "mohs": 1.2,
     "crystal": "tetragonal", "config": "[Kr] 4d¹⁰ 5s² 5p¹",
     "tags": ["touchscreen", "low melting", "bearing", "ITO"],
     "body": "ITO (indium tin oxide) is the transparent conductor that makes every smartphone touchscreen work. Indium also serves as a very soft, sticky gasket material for cryogenic and ultra-high-vacuum seals, and as a low-melting bearing alloy component."},

    {"Z": 50, "sym": "Sn", "name": "Tin", "mass": 118.71, "category": "post-transition",
     "density": 7.265, "mp": 231.93, "bp": 2602, "eneg": 1.96,
     "thermal": 66.8, "resist": 115, "modulus": 50, "mohs": 1.5,
     "crystal": "tetragonal (β white) / diamond cubic (α gray)", "config": "[Kr] 4d¹⁰ 5s² 5p²",
     "tags": ["solder", "bronze", "plating", "low melting"],
     "body": "Foundation of nearly all electronics solders (Sn-Pb historically, Sn-Ag-Cu since the RoHS transition), the second metal in bronze (Cu-Sn), and the corrosion-resistant plating on tin cans (steel underneath, very thin Sn on top).\n\n**Tin pest:** below 13.2 °C, white β-tin transforms to gray α-tin, which is brittle and crumbles. Rare in practice but a known failure mode for unalloyed tin in cold environments."},

    {"Z": 51, "sym": "Sb", "name": "Antimony", "mass": 121.76, "category": "metalloid",
     "density": 6.685, "mp": 630.63, "bp": 1587, "eneg": 2.05,
     "thermal": 24.4, "resist": 417, "modulus": 55, "mohs": 3.0,
     "crystal": "rhombohedral", "config": "[Kr] 4d¹⁰ 5s² 5p³",
     "tags": ["alloying", "lead-acid", "flame retardant", "type metal"],
     "body": "Hardens lead alloys. Lead-acid battery grid (4 to 12% Sb in Pb), babbitt bearing alloys, and historical type metal for Linotype printing all rely on antimony's contribution to hardness and dimensional stability of cast lead."},

    {"Z": 52, "sym": "Te", "name": "Tellurium", "mass": 127.60, "category": "metalloid",
     "density": 6.232, "mp": 449.51, "bp": 988, "eneg": 2.1,
     "thermal": 2.35, "resist": 100000, "modulus": 43, "mohs": 2.25,
     "crystal": "trigonal", "config": "[Kr] 4d¹⁰ 5s² 5p⁴",
     "tags": ["free-machining", "thermoelectric", "solar"],
     "body": "CdTe is a thin-film photovoltaic absorber (alternative to silicon). Bi₂Te₃ is the standard thermoelectric material for Peltier coolers and waste-heat harvesters. Added to copper and lead alloys to improve machinability."},

    {"Z": 53, "sym": "I", "name": "Iodine", "mass": 126.90, "category": "halogen",
     "density": 4.933, "mp": 113.7, "bp": 184.3, "eneg": 2.66,
     "thermal": 0.449, "mohs": None,
     "crystal": "orthorhombic", "config": "[Kr] 4d¹⁰ 5s² 5p⁵",
     "tags": ["halogen", "biological", "photographic", "antiseptic"],
     "body": "Sublimes from violet solid to violet vapor. Biologically essential (thyroid hormones). Antiseptic, contrast agent, photographic emulsion, and a chemical intermediate."},

    {"Z": 54, "sym": "Xe", "name": "Xenon", "mass": 131.29, "category": "noble-gas",
     "density": 0.005887, "mp": -111.75, "bp": -108.099, "eneg": 2.60,
     "thermal": 0.00565, "config": "[Kr] 4d¹⁰ 5s² 5p⁶",
     "tags": ["noble gas", "flash lamp", "ion propulsion"],
     "body": "Xenon arc flash lamps are the camera flash and stadium-lighting source of choice for very bright, short pulses. Xenon-ion engines provide low-thrust, high-specific-impulse propulsion for deep-space probes and station-keeping."},

    # ---------- Period 6 ----------
    {"Z": 55, "sym": "Cs", "name": "Caesium", "mass": 132.91, "category": "alkali-metal",
     "density": 1.93, "mp": 28.5, "bp": 671, "eneg": 0.79,
     "thermal": 35.9, "resist": 205, "modulus": 1.7, "mohs": 0.2,
     "crystal": "BCC", "config": "[Xe] 6s¹",
     "tags": ["reactive", "atomic clock", "drilling fluid"],
     "body": "The most electropositive stable element. Cs-133 hyperfine transition at 9,192,631,770 Hz **defines the SI second**. The primary frequency standards in every national metrology lab are cesium fountain clocks."},

    {"Z": 56, "sym": "Ba", "name": "Barium", "mass": 137.33, "category": "alkaline-earth",
     "density": 3.62, "mp": 727, "bp": 1845, "eneg": 0.89,
     "thermal": 18.4, "resist": 332, "modulus": 13, "mohs": 1.25,
     "crystal": "BCC", "config": "[Xe] 6s²",
     "tags": ["drilling mud", "contrast", "pyrotechnic"],
     "body": "Barium sulfate is the radio-contrast agent for GI imaging (insoluble, hence safe to swallow) and the weighting agent in drilling muds. Barium nitrate is the green color in pyrotechnics."},

    {"Z": 57, "sym": "La", "name": "Lanthanum", "mass": 138.91, "category": "lanthanide",
     "density": 6.15, "mp": 920, "bp": 3464, "eneg": 1.10,
     "thermal": 13.4, "resist": 615, "modulus": 37, "mohs": 2.5,
     "crystal": "hexagonal", "config": "[Xe] 5d¹ 6s²",
     "tags": ["lanthanide", "catalysis", "mischmetal", "Ni-MH battery"],
     "body": "Mischmetal (a roughly natural ratio mix of light lanthanides, mostly Ce and La) is the cheap form sold for spark-igniter flints and pyrophoric alloys. Pure La appears in nickel-metal hydride battery anodes and as a fluid-catalytic-cracking catalyst in refineries."},

    {"Z": 58, "sym": "Ce", "name": "Cerium", "mass": 140.12, "category": "lanthanide",
     "density": 6.770, "mp": 795, "bp": 3443, "eneg": 1.12,
     "thermal": 11.3, "resist": 828, "modulus": 34, "mohs": 2.5,
     "crystal": "FCC", "config": "[Xe] 4f¹ 5d¹ 6s²",
     "tags": ["lanthanide", "polishing", "catalysis", "spark flint"],
     "body": "Most abundant of the rare-earth elements. Cerium oxide is the optical polishing compound for glass and the oxygen storage component in three-way automotive catalysts."},

    {"Z": 59, "sym": "Pr", "name": "Praseodymium", "mass": 140.91, "category": "lanthanide",
     "density": 6.77, "mp": 935, "bp": 3520, "eneg": 1.13,
     "thermal": 12.5, "resist": 700, "modulus": 37, "mohs": None,
     "crystal": "hexagonal", "config": "[Xe] 4f³ 6s²",
     "tags": ["lanthanide", "magnet", "welding goggles"],
     "body": "Used in didymium glass for welding and glassblowing goggles (cuts the bright yellow sodium D line). Also a constituent of high-performance NdFeB magnets along with neodymium."},

    {"Z": 60, "sym": "Nd", "name": "Neodymium", "mass": 144.24, "category": "lanthanide",
     "density": 7.01, "mp": 1024, "bp": 3074, "eneg": 1.14,
     "thermal": 16.5, "resist": 643, "modulus": 41, "mohs": None,
     "crystal": "hexagonal", "config": "[Xe] 4f⁴ 6s²",
     "tags": ["lanthanide", "magnet", "laser"],
     "body": "Nd₂Fe₁₄B (neodymium iron boron) is the strongest commercial permanent magnet, the magnet in nearly every hard drive, headphone driver, BLDC motor, and wind turbine generator. Nd:YAG lasers (1064 nm) dominate industrial cutting, marking, and ranging."},

    {"Z": 61, "sym": "Pm", "name": "Promethium", "mass": 145, "category": "lanthanide",
     "density": 7.26, "mp": 1100, "bp": 3000, "eneg": 1.13,
     "thermal": 17.9, "config": "[Xe] 4f⁵ 6s²",
     "tags": ["lanthanide", "radioactive"],
     "body": "Only radioactive lanthanide. Used in some specialty thickness gauges and luminous paints."},

    {"Z": 62, "sym": "Sm", "name": "Samarium", "mass": 150.36, "category": "lanthanide",
     "density": 7.52, "mp": 1072, "bp": 1794, "eneg": 1.17,
     "thermal": 13.3, "resist": 940, "modulus": 50, "mohs": None,
     "crystal": "rhombohedral", "config": "[Xe] 4f⁶ 6s²",
     "tags": ["lanthanide", "magnet", "neutron absorber"],
     "body": "Sm-Co magnets keep their magnetism well above 300 °C, far better than NdFeB. They are the magnet of choice for aerospace, military, and high-temperature applications."},

    {"Z": 63, "sym": "Eu", "name": "Europium", "mass": 151.96, "category": "lanthanide",
     "density": 5.244, "mp": 822, "bp": 1529, "eneg": 1.20,
     "thermal": 13.9, "modulus": 18, "mohs": None,
     "crystal": "BCC", "config": "[Xe] 4f⁷ 6s²",
     "tags": ["lanthanide", "phosphor", "anti-counterfeit"],
     "body": "Red and blue phosphor in cathode-ray tubes, fluorescent lamps, and LED-backlit displays. Also embedded in euro banknotes as an anti-counterfeiting marker (visible only under UV)."},

    {"Z": 64, "sym": "Gd", "name": "Gadolinium", "mass": 157.25, "category": "lanthanide",
     "density": 7.90, "mp": 1313, "bp": 3273, "eneg": 1.20,
     "thermal": 10.6, "resist": 1310, "modulus": 55, "mohs": None,
     "crystal": "HCP", "config": "[Xe] 4f⁷ 5d¹ 6s²",
     "tags": ["lanthanide", "MRI contrast", "neutron absorber"],
     "body": "Highest neutron capture cross section of any stable nuclide. Gadolinium chelates are the standard intravenous MRI contrast agents."},

    {"Z": 65, "sym": "Tb", "name": "Terbium", "mass": 158.93, "category": "lanthanide",
     "density": 8.23, "mp": 1356, "bp": 3230, "eneg": 1.20,
     "thermal": 11.1, "resist": 1150, "modulus": 56, "mohs": None,
     "crystal": "HCP", "config": "[Xe] 4f⁹ 6s²",
     "tags": ["lanthanide", "phosphor", "magnetostrictive"],
     "body": "Green phosphor in fluorescent lamps and trichromatic LED displays. Terfenol-D (Tb-Dy-Fe) is the workhorse magnetostrictive alloy used in precision actuators and sonar transducers."},

    {"Z": 66, "sym": "Dy", "name": "Dysprosium", "mass": 162.50, "category": "lanthanide",
     "density": 8.55, "mp": 1412, "bp": 2567, "eneg": 1.22,
     "thermal": 10.7, "resist": 926, "modulus": 61, "mohs": None,
     "crystal": "HCP", "config": "[Xe] 4f¹⁰ 6s²",
     "tags": ["lanthanide", "magnet additive", "high temp"],
     "body": "Added to NdFeB magnets (typically a few percent) to raise the coercivity and operating temperature, critical for electric-vehicle traction motors and wind-turbine generators. The high-temperature secret ingredient of the magnet industry."},

    {"Z": 67, "sym": "Ho", "name": "Holmium", "mass": 164.93, "category": "lanthanide",
     "density": 8.80, "mp": 1474, "bp": 2700, "eneg": 1.23,
     "thermal": 16.2, "resist": 814, "modulus": 65, "mohs": None,
     "crystal": "HCP", "config": "[Xe] 4f¹¹ 6s²",
     "tags": ["lanthanide", "laser", "magnetic"],
     "body": "Highest magnetic moment of any naturally occurring element. Ho:YAG lasers (2.1 μm) are used in surgery for tissue ablation."},

    {"Z": 68, "sym": "Er", "name": "Erbium", "mass": 167.26, "category": "lanthanide",
     "density": 9.07, "mp": 1529, "bp": 2868, "eneg": 1.24,
     "thermal": 14.5, "resist": 860, "modulus": 70, "mohs": None,
     "crystal": "HCP", "config": "[Xe] 4f¹² 6s²",
     "tags": ["lanthanide", "fiber optic", "laser"],
     "body": "EDFA (erbium-doped fiber amplifier) is the optical amplifier that made long-haul fiber-optic telecommunications practical, working at the 1550 nm telecom window."},

    {"Z": 69, "sym": "Tm", "name": "Thulium", "mass": 168.93, "category": "lanthanide",
     "density": 9.32, "mp": 1545, "bp": 1950, "eneg": 1.25,
     "thermal": 16.9, "resist": 676, "modulus": 75, "mohs": None,
     "crystal": "HCP", "config": "[Xe] 4f¹³ 6s²",
     "tags": ["lanthanide", "portable X-ray", "laser"],
     "body": "Rarest of the stable lanthanides. Tm-170 is used as a portable X-ray source in industrial radiography and brachytherapy."},

    {"Z": 70, "sym": "Yb", "name": "Ytterbium", "mass": 173.05, "category": "lanthanide",
     "density": 6.90, "mp": 819, "bp": 1196, "eneg": 1.10,
     "thermal": 38.5, "resist": 250, "modulus": 24, "mohs": None,
     "crystal": "FCC", "config": "[Xe] 4f¹⁴ 6s²",
     "tags": ["lanthanide", "laser", "atomic clock"],
     "body": "Yb-doped fiber lasers (1064 nm) dominate the industrial fiber laser market for cutting, welding, and marking. Yb optical lattice clocks rival cesium fountains in precision."},

    {"Z": 71, "sym": "Lu", "name": "Lutetium", "mass": 174.97, "category": "lanthanide",
     "density": 9.84, "mp": 1663, "bp": 3402, "eneg": 1.27,
     "thermal": 16.4, "resist": 582, "modulus": 69, "mohs": None,
     "crystal": "HCP", "config": "[Xe] 4f¹⁴ 5d¹ 6s²",
     "tags": ["lanthanide", "PET scanner", "catalyst"],
     "body": "Lutetium oxyorthosilicate (LSO) and lutetium yttrium oxyorthosilicate (LYSO) are the scintillator crystals in modern PET scanners."},

    {"Z": 72, "sym": "Hf", "name": "Hafnium", "mass": 178.49, "category": "transition-metal",
     "density": 13.31, "mp": 2233, "bp": 4603, "eneg": 1.3,
     "thermal": 23.0, "resist": 331, "modulus": 78, "mohs": 5.5,
     "crystal": "HCP", "config": "[Xe] 4f¹⁴ 5d² 6s²",
     "tags": ["nuclear", "high temp", "alloying"],
     "body": "Chemical twin of zirconium, but with the opposite nuclear behavior: hafnium has a very high neutron absorption cross section, making it the natural choice for nuclear reactor control rods."},

    {"Z": 73, "sym": "Ta", "name": "Tantalum", "mass": 180.95, "category": "transition-metal",
     "density": 16.69, "mp": 3017, "bp": 5458, "eneg": 1.5,
     "thermal": 57.5, "resist": 131, "modulus": 186, "mohs": 6.5,
     "crystal": "BCC", "config": "[Xe] 4f¹⁴ 5d³ 6s²",
     "tags": ["capacitor", "chemical resistant", "implant"],
     "body": "Tantalum capacitors are the high-capacity, small-package electrolytic capacitors in nearly every modern electronic device. Tantalum is also exceptionally corrosion resistant; it survives most acids that destroy stainless and titanium, and is biocompatible enough for surgical implants."},

    {"Z": 74, "sym": "W", "name": "Tungsten", "mass": 183.84, "category": "transition-metal",
     "density": 19.25, "mp": 3422, "bp": 5555, "eneg": 2.36,
     "thermal": 173, "resist": 52.8, "modulus": 411, "mohs": 7.5,
     "crystal": "BCC", "config": "[Xe] 4f¹⁴ 5d⁴ 6s²",
     "tags": ["high temp", "tungsten carbide", "filament", "kinetic penetrator"],
     "body": "Highest melting point of any metal (3422 °C). Pure W is the filament of incandescent lamps (now historical) and the cathode in TIG welding. The dominant industrial form is **tungsten carbide (WC)** bonded with cobalt: the inserts and end mills doing most of the world's metal cutting.\n\nDensity comparable to gold but cheap enough to be used as a kinetic-energy penetrator (replacing depleted uranium where the radiological issues matter), as counterweights in golf clubs and aircraft control surfaces, and as radiation shielding."},

    {"Z": 75, "sym": "Re", "name": "Rhenium", "mass": 186.21, "category": "transition-metal",
     "density": 21.02, "mp": 3186, "bp": 5596, "eneg": 1.9,
     "thermal": 48.0, "resist": 193, "modulus": 463, "mohs": 7.0,
     "crystal": "HCP", "config": "[Xe] 4f¹⁴ 5d⁵ 6s²",
     "tags": ["superalloy", "high temp", "catalyst"],
     "body": "Critical alloying element in single-crystal nickel superalloy turbine blades (CMSX-4 contains around 3% Re). One of the rarest stable elements in the crust, which is why Re availability constrains certain jet-engine production rates."},

    {"Z": 76, "sym": "Os", "name": "Osmium", "mass": 190.23, "category": "transition-metal",
     "density": 22.59, "mp": 3033, "bp": 5012, "eneg": 2.2,
     "thermal": 87.6, "resist": 81.2, "modulus": 558, "mohs": 7.0,
     "crystal": "HCP", "config": "[Xe] 4f¹⁴ 5d⁶ 6s²",
     "tags": ["densest", "platinum group", "fountain pen"],
     "body": "Densest naturally occurring element (22.59 g/cm³). Used as a hardener in fountain pen nib tips, in some specialty electrical contacts, and as a catalyst. Osmium tetroxide is highly toxic and a useful biological stain."},

    {"Z": 77, "sym": "Ir", "name": "Iridium", "mass": 192.22, "category": "transition-metal",
     "density": 22.56, "mp": 2466, "bp": 4428, "eneg": 2.20,
     "thermal": 147, "resist": 47.1, "modulus": 528, "mohs": 6.5,
     "crystal": "FCC", "config": "[Xe] 4f¹⁴ 5d⁷ 6s²",
     "tags": ["spark plug", "platinum group", "corrosion resistant"],
     "body": "Second-densest element, and the most corrosion-resistant metal known. Iridium spark-plug electrodes last far longer than copper or platinum. Anomalously enriched in the K-Pg boundary layer, which led Alvarez to propose an asteroid impact ended the Cretaceous."},

    {"Z": 78, "sym": "Pt", "name": "Platinum", "mass": 195.08, "category": "transition-metal",
     "density": 21.45, "mp": 1768.3, "bp": 3825, "eneg": 2.28,
     "thermal": 71.6, "resist": 105, "modulus": 168, "mohs": 4.0,
     "crystal": "FCC", "config": "[Xe] 4f¹⁴ 5d⁹ 6s¹",
     "tags": ["catalyst", "jewelry", "thermocouple", "platinum group"],
     "body": "Catalytic-converter element (handles CO and unburned hydrocarbon oxidation), bench-chemistry crucible material at temperatures that destroy ceramic, the standard resistance-thermometer element (PT100, PT1000), and one half of every Type S, R, and B thermocouple. Also the metallurgical standard for definition of the kilogram until 2019."},

    {"Z": 79, "sym": "Au", "name": "Gold", "mass": 196.97, "category": "transition-metal",
     "density": 19.30, "mp": 1064.18, "bp": 2856, "eneg": 2.54,
     "thermal": 318, "resist": 22.14, "modulus": 79, "mohs": 2.5,
     "crystal": "FCC", "config": "[Xe] 4f¹⁴ 5d¹⁰ 6s¹",
     "tags": ["jewelry", "electrical contact", "bonding wire", "corrosion-immune"],
     "body": "Does not oxidize in air or react with most acids. The combination of perfect chemical stability, high conductivity (about 70% of copper by volume), and ductility (one gram beats out to a square meter of leaf) is why gold owns electrical contacts at low signal levels, microelectronic bonding wires, and high-reliability connector plating.\n\n**Wear is the failure mode for thin gold plating.** Hard-gold (Au-Co or Au-Ni at 0.1 to 0.2% alloying) is the standard contact-finish chemistry; pure gold is too soft. Karat: 24K = pure, 18K = 75% Au, 14K = 58.3%, with Cu or Ag balance for color and hardness."},

    {"Z": 80, "sym": "Hg", "name": "Mercury", "mass": 200.59, "category": "transition-metal",
     "density": 13.534, "mp": -38.83, "bp": 356.73, "eneg": 2.00,
     "thermal": 8.30, "resist": 961, "modulus": None, "mohs": None,
     "crystal": "rhombohedral (solid)", "config": "[Xe] 4f¹⁴ 5d¹⁰ 6s²",
     "tags": ["liquid metal", "toxic", "amalgam", "barometer"],
     "body": "Only metal liquid at room temperature, dense and surface-tension-driven into perfect droplets. Historically pervasive in thermometers, barometers, and dental amalgams. **Highly toxic; bioaccumulates as methylmercury.** Industrial use has shrunk dramatically since the 1990s."},

    {"Z": 81, "sym": "Tl", "name": "Thallium", "mass": 204.38, "category": "post-transition",
     "density": 11.85, "mp": 304, "bp": 1473, "eneg": 1.62,
     "thermal": 46.1, "resist": 180, "modulus": 8, "mohs": 1.2,
     "crystal": "HCP", "config": "[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p¹",
     "tags": ["toxic", "rodenticide", "IR optics"],
     "body": "**Tasteless, odorless, and highly toxic.** Historically used as a rodenticide (banned in most jurisdictions). Modern legitimate uses are limited to specialty IR optics and some superconducting research."},

    {"Z": 82, "sym": "Pb", "name": "Lead", "mass": 207.2, "category": "post-transition",
     "density": 11.34, "mp": 327.46, "bp": 1749, "eneg": 1.87,
     "thermal": 35.3, "resist": 208, "modulus": 16, "mohs": 1.5,
     "crystal": "FCC", "config": "[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p²",
     "tags": ["dense", "shielding", "battery", "low melting", "toxic"],
     "body": "Soft, dense (11.34 g/cm³), low melting point (327 °C), and chemically forgiving. Historical uses (plumbing, paint, gasoline anti-knock) have been almost entirely banned due to cumulative toxicity.\n\n**Current legitimate uses:** lead-acid storage batteries (still the dominant battery for automotive starting and grid backup), radiation shielding (X-ray rooms, gamma sources), counterweights and ballast, and Sn-Pb electronics solder (mostly replaced by lead-free Sn-Ag-Cu since RoHS but still used in aerospace and medical for tin-whisker mitigation)."},

    {"Z": 83, "sym": "Bi", "name": "Bismuth", "mass": 208.98, "category": "post-transition",
     "density": 9.78, "mp": 271.4, "bp": 1564, "eneg": 2.02,
     "thermal": 7.97, "resist": 1290, "modulus": 32, "mohs": 2.25,
     "crystal": "rhombohedral", "config": "[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p³",
     "tags": ["low melting", "lead-free", "fusible", "pink iridescent"],
     "body": "Lead's non-toxic cousin. Low melting (271 °C), expands slightly on freezing (useful for replicating mold details), and forms colorful iridescent oxide on slow-cooled crystals. Used in fusible alloys (Wood's metal, Field's metal, fire-sprinkler fusible links), low-melting solders, and as a lead replacement in plumbing fittings and machinable brass."},

    {"Z": 84, "sym": "Po", "name": "Polonium", "mass": 209, "category": "post-transition",
     "density": 9.20, "mp": 254, "bp": 962, "eneg": 2.0,
     "thermal": 20, "config": "[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p⁴",
     "tags": ["radioactive", "alpha source"],
     "body": "Highly radioactive alpha emitter. Used in some antistatic devices and as a heat source in space-probe radioisotope thermoelectric generators."},

    {"Z": 85, "sym": "At", "name": "Astatine", "mass": 210, "category": "halogen",
     "density": None, "mp": 302, "bp": 337, "eneg": 2.2,
     "config": "[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p⁵",
     "tags": ["halogen", "radioactive", "rarest"],
     "body": "Rarest naturally occurring element on Earth (total terrestrial inventory estimated under 25 grams). Half-life of the most stable isotope is around 8 hours. Some research interest as a targeted alpha-emitter for cancer therapy."},

    {"Z": 86, "sym": "Rn", "name": "Radon", "mass": 222, "category": "noble-gas",
     "density": 0.00973, "mp": -71, "bp": -61.7, "eneg": 2.2,
     "thermal": 0.00361, "config": "[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p⁶",
     "tags": ["noble gas", "radioactive", "indoor air hazard"],
     "body": "Decay product of uranium in soil and rock; collects in poorly ventilated basements and is a significant cause of indoor-air lung cancer risk in many parts of the world. EPA action level is 4 pCi/L."},

    # ---------- Period 7 ----------
    {"Z": 87, "sym": "Fr", "name": "Francium", "mass": 223, "category": "alkali-metal",
     "density": 2.48, "mp": 27, "bp": 677, "eneg": 0.7,
     "config": "[Rn] 7s¹",
     "tags": ["radioactive", "alkali metal"],
     "body": "Among the rarest naturally occurring elements; half-life of Fr-223 is 22 minutes. No bulk samples exist; properties extrapolated from spectroscopy."},

    {"Z": 88, "sym": "Ra", "name": "Radium", "mass": 226, "category": "alkaline-earth",
     "density": 5.5, "mp": 700, "bp": 1737, "eneg": 0.9,
     "thermal": 18.6, "config": "[Rn] 7s²",
     "tags": ["radioactive", "luminous paint", "historical"],
     "body": "Discovered by the Curies. The famous luminous radium watch dials of the early 20th century caused the Radium Girls occupational tragedy. Modern radiation safety norms grew directly out of that case."},

    {"Z": 89, "sym": "Ac", "name": "Actinium", "mass": 227, "category": "actinide",
     "density": 10.07, "mp": 1050, "bp": 3200, "eneg": 1.1,
     "thermal": 12, "config": "[Rn] 6d¹ 7s²",
     "tags": ["actinide", "radioactive"],
     "body": "Eponym of the actinide series. Targeted alpha therapy with Ac-225 is an area of active oncology research."},

    {"Z": 90, "sym": "Th", "name": "Thorium", "mass": 232.04, "category": "actinide",
     "density": 11.72, "mp": 1750, "bp": 4788, "eneg": 1.3,
     "thermal": 54.0, "resist": 157, "modulus": 79, "mohs": 3.0,
     "crystal": "FCC", "config": "[Rn] 6d² 7s²",
     "tags": ["actinide", "nuclear fuel", "lantern mantle", "alloying"],
     "body": "Slightly radioactive (alpha emitter, very long half-life). Historically used in gas lantern mantles (incandescent thoria glows brilliantly hot) and as a high-temperature alloying element in tungsten welding electrodes (red-tip thoriated tungsten). Increasing interest as a fertile nuclear-fuel feedstock in thorium-cycle reactors."},

    {"Z": 91, "sym": "Pa", "name": "Protactinium", "mass": 231.04, "category": "actinide",
     "density": 15.37, "mp": 1568, "bp": 4027, "eneg": 1.5,
     "thermal": 47.0, "config": "[Rn] 5f² 6d¹ 7s²",
     "tags": ["actinide", "radioactive"],
     "body": "Highly radioactive, extremely scarce. Used only in nuclear research."},

    {"Z": 92, "sym": "U", "name": "Uranium", "mass": 238.03, "category": "actinide",
     "density": 19.1, "mp": 1132.2, "bp": 4131, "eneg": 1.38,
     "thermal": 27.5, "resist": 280, "modulus": 208, "mohs": 6.0,
     "crystal": "orthorhombic", "config": "[Rn] 5f³ 6d¹ 7s²",
     "tags": ["actinide", "nuclear fuel", "depleted uranium", "ballast"],
     "body": "Heaviest naturally occurring element. **U-235** (0.72% of natural uranium) is the only naturally fissile isotope; enrichment to 3 to 5% drives commercial light-water reactors, to over 90% drives weapons and some research reactors.\n\n**Depleted uranium** (the U-238 residue after enrichment) is so dense (19.1 g/cm³) that it serves as kinetic-energy armor-piercing rounds, aircraft control-surface counterweights, and radiation shielding. Mildly radioactive; the chemical toxicity of soluble U compounds is the bigger hazard for handlers."},

    {"Z": 93, "sym": "Np", "name": "Neptunium", "mass": 237, "category": "actinide",
     "density": 20.45, "mp": 644, "bp": 3902, "eneg": 1.36,
     "thermal": 6.3, "config": "[Rn] 5f⁴ 6d¹ 7s²",
     "tags": ["actinide", "radioactive", "neutron detector"],
     "body": "First synthetic transuranic element. Trace component of irradiated reactor fuel; some use in high-energy neutron detectors."},

    {"Z": 94, "sym": "Pu", "name": "Plutonium", "mass": 244, "category": "actinide",
     "density": 19.85, "mp": 639.4, "bp": 3228, "eneg": 1.28,
     "thermal": 6.74, "config": "[Rn] 5f⁶ 7s²",
     "tags": ["actinide", "nuclear weapon", "MOX fuel", "RTG"],
     "body": "Six allotropic phases between room temperature and melting (the most of any element), each with substantially different density: a metallurgical nightmare to cast and machine. Pu-239 is fissile and is produced in reactors from U-238 absorbing a neutron. Pu-238 (mostly alpha decay, very long half-life) is the heat source in radioisotope thermoelectric generators (Voyager, Cassini, Mars rovers)."},

    {"Z": 95, "sym": "Am", "name": "Americium", "mass": 243, "category": "actinide",
     "density": 13.69, "mp": 1176, "bp": 2011, "eneg": 1.13,
     "thermal": 10, "config": "[Rn] 5f⁷ 7s²",
     "tags": ["actinide", "smoke detector"],
     "body": "Am-241 is the alpha source in ionization-type smoke detectors. Each detector contains around 1 microgram, sealed."},

    {"Z": 96, "sym": "Cm", "name": "Curium", "mass": 247, "category": "actinide",
     "density": 13.51, "mp": 1340, "bp": 3110, "eneg": 1.28,
     "thermal": 8.8, "config": "[Rn] 5f⁷ 6d¹ 7s²",
     "tags": ["actinide", "radioactive"],
     "body": "Named for Pierre and Marie Curie. Strong alpha emitter; very limited use outside research."},

    {"Z": 97, "sym": "Bk", "name": "Berkelium", "mass": 247, "category": "actinide",
     "density": 14.78, "mp": 986, "bp": 2627, "eneg": 1.3,
     "thermal": 10, "config": "[Rn] 5f⁹ 7s²",
     "tags": ["actinide", "synthetic"],
     "body": "Synthetic. Produced in microgram quantities, mostly for research."},

    {"Z": 98, "sym": "Cf", "name": "Californium", "mass": 251, "category": "actinide",
     "density": 15.1, "mp": 900, "bp": 1470, "eneg": 1.3,
     "config": "[Rn] 5f¹⁰ 7s²",
     "tags": ["actinide", "neutron source"],
     "body": "Cf-252 is a portable spontaneous-fission neutron source used in well-logging, baggage scanning, and reactor startup."},

    {"Z": 99, "sym": "Es", "name": "Einsteinium", "mass": 252, "category": "actinide",
     "density": 8.84, "mp": 860, "bp": None, "eneg": 1.3,
     "config": "[Rn] 5f¹¹ 7s²",
     "tags": ["actinide", "synthetic"],
     "body": "First isolated from the debris of the 1952 Ivy Mike thermonuclear test. Research-only."},

    {"Z": 100, "sym": "Fm", "name": "Fermium", "mass": 257, "category": "actinide",
     "density": None, "mp": 1527, "bp": None, "eneg": 1.3,
     "config": "[Rn] 5f¹² 7s²",
     "tags": ["actinide", "synthetic"],
     "body": "Synthetic. No bulk samples have ever existed."},

    {"Z": 101, "sym": "Md", "name": "Mendelevium", "mass": 258, "category": "actinide",
     "density": None, "mp": 827, "bp": None, "eneg": 1.3,
     "config": "[Rn] 5f¹³ 7s²",
     "tags": ["actinide", "synthetic"],
     "body": "Named for Dmitri Mendeleev. Produced one atom at a time."},

    {"Z": 102, "sym": "No", "name": "Nobelium", "mass": 259, "category": "actinide",
     "density": None, "mp": 827, "bp": None, "eneg": 1.3,
     "config": "[Rn] 5f¹⁴ 7s²",
     "tags": ["actinide", "synthetic"],
     "body": "Named for Alfred Nobel. Half-life of the most stable isotope is about an hour."},

    {"Z": 103, "sym": "Lr", "name": "Lawrencium", "mass": 266, "category": "actinide",
     "density": None, "mp": 1627, "bp": None, "eneg": 1.3,
     "config": "[Rn] 5f¹⁴ 7s² 7p¹",
     "tags": ["actinide", "synthetic", "last actinide"],
     "body": "Last of the actinide series. Named for E. O. Lawrence (cyclotron inventor)."},

    {"Z": 104, "sym": "Rf", "name": "Rutherfordium", "mass": 267, "category": "transition-metal",
     "density": None, "mp": None, "config": "[Rn] 5f¹⁴ 6d² 7s²",
     "tags": ["transactinide", "synthetic"],
     "body": "First transactinide. Chemistry similar to hafnium."},

    {"Z": 105, "sym": "Db", "name": "Dubnium", "mass": 268, "category": "transition-metal",
     "density": None, "mp": None, "config": "[Rn] 5f¹⁴ 6d³ 7s²",
     "tags": ["transactinide", "synthetic"],
     "body": "Synthetic. Chemistry similar to tantalum."},

    {"Z": 106, "sym": "Sg", "name": "Seaborgium", "mass": 269, "category": "transition-metal",
     "density": None, "mp": None, "config": "[Rn] 5f¹⁴ 6d⁴ 7s²",
     "tags": ["transactinide", "synthetic"],
     "body": "Named after Glenn Seaborg in his lifetime. Chemistry similar to tungsten."},

    {"Z": 107, "sym": "Bh", "name": "Bohrium", "mass": 270, "category": "transition-metal",
     "density": None, "mp": None, "config": "[Rn] 5f¹⁴ 6d⁵ 7s²",
     "tags": ["transactinide", "synthetic"],
     "body": "Synthetic. Chemistry similar to rhenium."},

    {"Z": 108, "sym": "Hs", "name": "Hassium", "mass": 269, "category": "transition-metal",
     "density": None, "mp": None, "config": "[Rn] 5f¹⁴ 6d⁶ 7s²",
     "tags": ["transactinide", "synthetic"],
     "body": "Synthetic. Confirmed to be a transition metal with osmium-like chemistry."},

    {"Z": 109, "sym": "Mt", "name": "Meitnerium", "mass": 278, "category": "unknown",
     "density": None, "mp": None, "config": "[Rn] 5f¹⁴ 6d⁷ 7s²",
     "tags": ["synthetic", "superheavy"],
     "body": "Named for Lise Meitner. Properties largely predicted, not measured."},

    {"Z": 110, "sym": "Ds", "name": "Darmstadtium", "mass": 281, "category": "unknown",
     "density": None, "mp": None, "config": "[Rn] 5f¹⁴ 6d⁸ 7s²",
     "tags": ["synthetic", "superheavy"],
     "body": "Synthesized at GSI Darmstadt in 1994. Half-lives measured in microseconds."},

    {"Z": 111, "sym": "Rg", "name": "Roentgenium", "mass": 282, "category": "unknown",
     "density": None, "mp": None, "config": "[Rn] 5f¹⁴ 6d⁹ 7s²",
     "tags": ["synthetic", "superheavy"],
     "body": "Named for Wilhelm Röntgen (X-ray discoverer). A few atoms have ever been made."},

    {"Z": 112, "sym": "Cn", "name": "Copernicium", "mass": 285, "category": "unknown",
     "density": None, "mp": None, "config": "[Rn] 5f¹⁴ 6d¹⁰ 7s²",
     "tags": ["synthetic", "superheavy"],
     "body": "Named for Copernicus. Predicted to be a liquid or volatile metal."},

    {"Z": 113, "sym": "Nh", "name": "Nihonium", "mass": 286, "category": "unknown",
     "density": None, "mp": None, "config": "[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p¹",
     "tags": ["synthetic", "superheavy"],
     "body": "First element discovered in East Asia (RIKEN, Japan). Nihon means Japan."},

    {"Z": 114, "sym": "Fl", "name": "Flerovium", "mass": 289, "category": "unknown",
     "density": None, "mp": None, "config": "[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p²",
     "tags": ["synthetic", "superheavy", "island of stability"],
     "body": "Among the longest-lived superheavy nuclides (seconds, not microseconds). The predicted island of stability lies near here."},

    {"Z": 115, "sym": "Mc", "name": "Moscovium", "mass": 289, "category": "unknown",
     "density": None, "mp": None, "config": "[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p³",
     "tags": ["synthetic", "superheavy"],
     "body": "Synthesized at JINR Dubna near Moscow."},

    {"Z": 116, "sym": "Lv", "name": "Livermorium", "mass": 293, "category": "unknown",
     "density": None, "mp": None, "config": "[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p⁴",
     "tags": ["synthetic", "superheavy"],
     "body": "Named for Lawrence Livermore National Laboratory."},

    {"Z": 117, "sym": "Ts", "name": "Tennessine", "mass": 294, "category": "unknown",
     "density": None, "mp": None, "config": "[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p⁵",
     "tags": ["synthetic", "superheavy"],
     "body": "Named for the state of Tennessee. Penultimate element on the current table."},

    {"Z": 118, "sym": "Og", "name": "Oganesson", "mass": 294, "category": "unknown",
     "density": None, "mp": None, "config": "[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p⁶",
     "tags": ["synthetic", "superheavy", "noble configuration"],
     "body": "Heaviest element synthesized to date. Named for Yuri Oganessian, the only person with an element named after them in their lifetime besides Glenn Seaborg. Predicted to be a noble gas by electron configuration; relativistic effects probably make it solid or liquid at room temperature."},
]


# Iron has a hand-written body that exceeds what the seeder usually produces.
# Define it here so the seeder owns it too.
IRON = {
    "Z": 26, "sym": "Fe", "name": "Iron", "mass": 55.845,
    "category": "transition-metal",
    "density": 7.874, "mp": 1538, "bp": 2862, "eneg": 1.83,
    "thermal": 80.4, "resist": 96.1, "modulus": 211, "mohs": 4.0,
    "crystal": "BCC (α) / FCC (γ)", "config": "[Ar] 3d⁶ 4s²",
    "tags": ["ferrous", "transition metal", "magnetic", "structural", "abundant"],
    "hazards": ["dust combustible"],
    "related": ["alloy:aisi-1018"],
    "sources": ["asm-v1", "crc-104"],
    "body": "Fourth most abundant element in the Earth's crust by mass and the most-used metal in engineering by a wide margin. Pure iron is soft and ductile; the engineering metal you actually work with is always an alloy, almost always with carbon.\n\nIron undergoes two allotropic transformations on heating: **α-Fe (BCC, ferrite)** to **γ-Fe (FCC, austenite)** at 912 °C, then back to **δ-Fe (BCC)** at 1394 °C before melting at 1538 °C. The α to γ transition is the gate that opens all of heat treating; everything in **TEMPER** turns on what happens when austenite cools.\n\nLoses its magnetism above the Curie point at 770 °C, well before the BCC-to-FCC transition.",
}
ELEMENTS.append(IRON)


# -----------------------------------------------------------------------------
# Stats list construction
# -----------------------------------------------------------------------------

def _stat(key, label, value, unit, source="crc-104"):
    return {"key": key, "label": label, "value": value, "unit": unit, "source": source}


def build_stats(e):
    """Assemble the stats list from element dict fields, omitting Nones."""
    stats = [
        _stat("atomicNumber", "Atomic number", e["Z"], ""),
        _stat("atomicMass", "Atomic mass", e["mass"], "u"),
    ]
    if e.get("config"):
        stats.append(_stat("electronConfig", "Electron config", e["config"], ""))
    if e.get("density") is not None:
        unit = "g/cm³"
        stats.append(_stat("density", "Density", e["density"], unit))
    if e.get("mp") is not None:
        stats.append(_stat("meltingPoint", "Melting point", e["mp"], "°C"))
    if e.get("bp") is not None:
        stats.append(_stat("boilingPoint", "Boiling point", e["bp"], "°C"))
    if e.get("eneg") is not None:
        stats.append(_stat("electronegativity", "Electronegativity", e["eneg"], "Pauling"))
    if e.get("thermal") is not None:
        stats.append(_stat("thermalConductivity", "Thermal cond.", e["thermal"], "W/m·K"))
    if e.get("resist") is not None:
        stats.append(_stat("resistivity", "Electrical resistivity", e["resist"], "nΩ·m"))
    if e.get("modulus") is not None:
        stats.append(_stat("youngsModulus", "Young's modulus", e["modulus"], "GPa", source="asm-v1"))
    if e.get("mohs") is not None:
        stats.append(_stat("mohs", "Mohs hardness", e["mohs"], ""))
    if e.get("crystal"):
        stats.append(_stat("crystalStructure", "Crystal structure", e["crystal"], "",
                           source="asm-v1" if e["category"] in ("transition-metal", "alkaline-earth", "post-transition", "alkali-metal") else "crc-104"))
    return stats


def build_subtitle(e):
    Z = e["Z"]
    group = derive_group(Z)
    _, _, block = POSITIONS[Z]
    parts = [f"{e['sym']}", f"Z={Z}"]
    if group is not None:
        parts.append(f"Group {group}")
    period = POSITIONS[Z][1] if POSITIONS[Z][1] not in (8, 9) else (6 if 58 <= Z <= 71 else 7)
    parts.append(f"Period {period}")
    parts.append(f"{block}-block")
    return " · ".join(parts)


def build_entry(e):
    Z = e["Z"]
    sym = e["sym"]
    col, row_or_block, block = POSITIONS[Z]
    # The actual period for f-block elements is 6 or 7, not row 8/9.
    period = 6 if 57 <= Z <= 71 else (7 if 89 <= Z <= 103 else POSITIONS[Z][1])

    cat_tags = CATEGORY_TAGS.get(e["category"], [])
    all_tags = list(dict.fromkeys(cat_tags + list(e.get("tags", []))))

    return {
        "id": f"element:{sym.lower()}",
        "module": "assay",
        "kind": "element",
        "title": e["name"],
        "symbol": sym,
        "subtitle": build_subtitle(e),
        "Z": Z,
        "category": e["category"],
        "group": derive_group(Z),
        "period": period,
        "block": block,
        "tags": all_tags,
        "stats": build_stats(e),
        "body": e.get("body", ""),
        "hazards": e.get("hazards", []),
        "related": e.get("related", []),
        "sources": e.get("sources", ["crc-104"]),
    }


def write_manifest_entries():
    """Update manifest.json with the full assay entries list and customView flag."""
    manifest = json.loads(MANIFEST.read_text())
    syms_in_order = [e["sym"].lower() for e in sorted(ELEMENTS, key=lambda e: e["Z"])]
    for m in manifest["modules"]:
        if m["slug"] == "assay":
            m["entries"] = syms_in_order
            m["status"] = "active"
            m["customView"] = True
            break
    MANIFEST.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    print(f"Manifest updated: assay declares {len(syms_in_order)} entries.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true", help="Show diff summary, write nothing.")
    ap.add_argument("--keep", action="append", default=[], help="Symbol to skip (preserve hand edits). Repeatable.")
    args = ap.parse_args()
    keep = {s.upper() for s in args.keep}

    written, skipped = 0, 0
    for e in sorted(ELEMENTS, key=lambda x: x["Z"]):
        sym = e["sym"]
        if sym.upper() in keep:
            print(f"  · skip {sym} (preserved)")
            skipped += 1
            continue
        out = build_entry(e)
        path = ASSAY_DATA / f"{sym.lower()}.json"
        text = json.dumps(out, indent=2, ensure_ascii=False) + "\n"
        if args.dry_run:
            existed = path.exists()
            print(f"  {'~' if existed else '+'} {path.relative_to(ROOT)}")
        else:
            path.write_text(text)
        written += 1
    print(f"\nSeeded {written} element files. Skipped {skipped}.")

    if not args.dry_run:
        write_manifest_entries()

    return 0


if __name__ == "__main__":
    sys.exit(main())
