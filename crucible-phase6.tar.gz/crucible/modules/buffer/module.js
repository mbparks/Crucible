// buffer/module.js. Henderson-Hasselbalch buffer solver.
//
// Reads buffer-recipe cards from modules/buffer/data and offers an interactive
// recipe calculator. The user picks a buffer system, a target pH, a final
// molarity, and a final volume; the solver outputs grams (or mL for liquid
// acid forms) of each component to weigh out.
//
// H-H equation: pH = pKa + log10([A-]/[HA])
//   r = [A-]/[HA] = 10^(pH - pKa)
//   For total buffer concentration C: [HA] = C/(1+r), [A-] = C·r/(1+r)

import { loadEntriesForModule } from "../../shared/js/data.js";
import { renderFront } from "../../shared/js/card.js";

function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") node.className = v;
    else if (k === "dataset") for (const [dk, dv] of Object.entries(v)) node.dataset[dk] = dv;
    else if (k === "style") node.style.cssText = v;
    else if (k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (v !== null && v !== undefined && v !== false) node.setAttribute(k, v === true ? "" : v);
  }
  for (const c of children) {
    if (c === null || c === undefined || c === false) continue;
    node.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
  }
  return node;
}

function fmt(v, digits = 3) {
  if (!Number.isFinite(v)) return "—";
  if (v === 0) return "0";
  const abs = Math.abs(v);
  if (abs >= 100) return v.toFixed(0);
  if (abs >= 10) return v.toFixed(1);
  if (abs >= 0.1) return v.toFixed(digits);
  return v.toExponential(2);
}

function computeRecipe(buffer, pH, molarity, volume_mL) {
  // r = base/acid ratio
  const r = Math.pow(10, pH - buffer.pKa);
  const C = molarity;            // total buffer mol/L
  const HA_M = C / (1 + r);      // acid form molarity
  const A_M  = C * r / (1 + r);  // base form molarity
  const V_L = volume_mL / 1000;

  const acidMoles = HA_M * V_L;
  const baseMoles = A_M  * V_L;

  // Mass of base (always solid)
  const baseGrams = baseMoles * buffer.baseMW;

  // Acid: grams if solid, mL of stock if liquid (uses density and percent)
  let acidGrams = null;
  let acidVolume_mL = null;
  if (buffer.acidIsLiquid && buffer.acidDensity && buffer.acidPercent) {
    // mass of pure acid needed (g)
    const acidMassPure = acidMoles * buffer.acidMW;
    // mass of stock solution (g) = pure mass / (percent/100)
    const acidMassStock = acidMassPure / (buffer.acidPercent / 100);
    // volume of stock (mL) = mass / density
    acidVolume_mL = acidMassStock / buffer.acidDensity;
  } else {
    acidGrams = acidMoles * buffer.acidMW;
  }

  // Fraction outside the useful pH range?
  const outOfRange = (pH < buffer.phMin) || (pH > buffer.phMax);

  return {
    r, HA_M, A_M, acidMoles, baseMoles,
    acidGrams, acidVolume_mL,
    baseGrams,
    outOfRange,
  };
}

function renderSolver(buffers) {
  let currentSlug = buffers.length > 0 ? buffers[0].id.split(":")[1] : null;
  let pH = buffers[0] ? buffers[0].pKa : 7.0;
  let molarity = 0.1;
  let volume = 100;

  const wrap = el("section", { class: "bf-solver", "aria-labelledby": "bf-title" });
  wrap.appendChild(el("h2", { id: "bf-title", class: "bf-title" }, "Henderson-Hasselbalch solver"));
  wrap.appendChild(el("p", { class: "bf-sub" },
    "Pick a buffer system, target pH, final concentration, and volume. The solver outputs the mass (or stock volume, for liquid acids) of each component to weigh out. Final pH should still be checked with a calibrated meter and adjusted as needed."
  ));

  const row = el("div", { class: "bf-input-row" });

  // Buffer picker
  const bufferLabel = el("label", { class: "bf-field" });
  bufferLabel.appendChild(el("span", { class: "bf-field-label" }, "Buffer system"));
  const bufferSelect = el("select", { class: "bf-select", "aria-label": "Buffer system" });
  for (const b of buffers) {
    const slug = b.id.split(":")[1];
    const opt = el("option", { value: slug }, `${b.title} (pKa ${b.pKa})`);
    if (slug === currentSlug) opt.selected = true;
    bufferSelect.appendChild(opt);
  }
  bufferLabel.appendChild(bufferSelect);
  row.appendChild(bufferLabel);

  // pH input
  const phLabel = el("label", { class: "bf-field" });
  phLabel.appendChild(el("span", { class: "bf-field-label" }, "Target pH"));
  const phInput = el("input", { type: "number", class: "bf-input", step: "0.05", value: String(pH) });
  phLabel.appendChild(phInput);
  row.appendChild(phLabel);

  // Molarity input
  const mLabel = el("label", { class: "bf-field" });
  mLabel.appendChild(el("span", { class: "bf-field-label" }, "Concentration (M)"));
  const mInput = el("input", { type: "number", class: "bf-input", step: "0.01", min: "0.001", value: String(molarity) });
  mLabel.appendChild(mInput);
  row.appendChild(mLabel);

  // Volume input
  const vLabel = el("label", { class: "bf-field" });
  vLabel.appendChild(el("span", { class: "bf-field-label" }, "Volume (mL)"));
  const vInput = el("input", { type: "number", class: "bf-input", step: "10", min: "1", value: String(volume) });
  vLabel.appendChild(vInput);
  row.appendChild(vLabel);

  wrap.appendChild(row);

  const resultHost = el("div", { class: "bf-result" });
  wrap.appendChild(resultHost);

  function update() {
    const buf = buffers.find(b => b.id === `buffer:${bufferSelect.value}`);
    if (!buf) {
      resultHost.innerHTML = "";
      resultHost.appendChild(el("p", { class: "bf-empty" }, "Select a buffer."));
      return;
    }
    const p = parseFloat(phInput.value);
    const m = parseFloat(mInput.value);
    const v = parseFloat(vInput.value);
    if (!Number.isFinite(p) || !Number.isFinite(m) || !Number.isFinite(v) || m <= 0 || v <= 0) {
      resultHost.innerHTML = "";
      resultHost.appendChild(el("p", { class: "bf-empty" }, "Enter valid pH, concentration, and volume."));
      return;
    }

    const r = computeRecipe(buf, p, m, v);
    resultHost.innerHTML = "";

    if (r.outOfRange) {
      resultHost.appendChild(el("p", { class: "bf-warn" },
        `pH ${p.toFixed(2)} is outside the useful range for this buffer (${buf.phMin} to ${buf.phMax}). Buffering capacity will be low; consider a buffer with a pKa within ±1 of your target.`
      ));
    }

    // Recipe table
    const dl = el("dl", { class: "bf-recipe" });

    // Acid component
    dl.appendChild(el("dt", {}, buf.acidName));
    if (r.acidVolume_mL !== null) {
      dl.appendChild(el("dd", {},
        el("strong", {}, `${fmt(r.acidVolume_mL, 2)} mL`),
        ` of ${buf.acidPercent}% stock (${fmt(r.acidMoles * 1000, 2)} mmol)`
      ));
    } else {
      dl.appendChild(el("dd", {},
        el("strong", {}, `${fmt(r.acidGrams, 3)} g`),
        ` (${fmt(r.acidMoles * 1000, 2)} mmol)`
      ));
    }

    // Base component
    dl.appendChild(el("dt", {}, buf.baseName));
    dl.appendChild(el("dd", {},
      el("strong", {}, `${fmt(r.baseGrams, 3)} g`),
      ` (${fmt(r.baseMoles * 1000, 2)} mmol)`
    ));

    // Total
    dl.appendChild(el("dt", { class: "bf-recipe-total" }, "Final volume"));
    dl.appendChild(el("dd", { class: "bf-recipe-total" },
      `Bring to ${fmt(v, 0)} mL with deionized water`
    ));

    resultHost.appendChild(dl);

    // Math footer
    resultHost.appendChild(el("p", { class: "bf-math" },
      `pH = pKa + log([A⁻]/[HA]) → ratio = ${fmt(r.r, 3)} · [HA] = ${fmt(r.HA_M * 1000, 2)} mM · [A⁻] = ${fmt(r.A_M * 1000, 2)} mM`
    ));

    // Verify in practice
    resultHost.appendChild(el("p", { class: "bf-note" },
      "Dissolve both components in about 70% of final volume, mix until clear, check pH with a calibrated meter, adjust with HCl or NaOH if needed, then bring to final volume."
    ));
  }

  bufferSelect.addEventListener("change", () => {
    const buf = buffers.find(b => b.id === `buffer:${bufferSelect.value}`);
    if (buf) phInput.value = String(buf.pKa);
    update();
  });
  phInput.addEventListener("input", update);
  mInput.addEventListener("input", update);
  vInput.addEventListener("input", update);

  update();
  return wrap;
}

export async function render(root, ctx) {
  root.innerHTML = "";
  root.appendChild(el("a", { class: "detail-back-link", href: "#/" }, "← bench"));
  root.appendChild(el("p", { class: "section-eyebrow", style: "margin-top:1rem;" }, "Chemistry"));
  root.appendChild(el("h1", { class: "section-title" }, "BUFFER"));
  root.appendChild(el("p", { class: "section-lede" },
    "Buffer system reference and Henderson-Hasselbalch recipe solver. Pick any system below for the chemistry notes and the working pH range."
  ));

  const entries = await loadEntriesForModule("buffer");
  if (entries.length === 0) {
    root.appendChild(el("p", { class: "boot-note" }, "No buffer data found."));
    return;
  }

  root.appendChild(renderSolver(entries));

  root.appendChild(el("h2", { class: "section-eyebrow", style: "margin-top:2.5rem;" }, "Buffer systems"));
  const grid = el("div", { class: "card-grid" });
  for (const entry of entries) {
    const front = renderFront(entry);
    const link = el("a", { href: `#/card/${encodeURIComponent(entry.id)}`, style: "text-decoration:none;color:inherit;" });
    link.appendChild(front);
    grid.appendChild(link);
  }
  root.appendChild(grid);
}
