// phase/module.js. Interactive Fe-Fe3C phase diagram tool.
//
// Renders a static SVG of the Fe-C metastable phase diagram with the
// engineering-relevant phase regions colored. The user can click on the
// diagram, drag a crosshair, or enter (C, T) numerically to query the
// region. For two-phase regions, lever-rule mass fractions are computed
// from analytical boundary equations.
//
// Coordinate system (viewBox 0 0 1000 600):
//   x: composition 0 to 6.67 wt% C   maps to 80..940
//   y: temperature 0 to 1600 °C       maps to 540..40 (inverted)

import { loadEntriesForModule } from "../../shared/js/data.js";
import { renderFront } from "../../shared/js/card.js";

// ---------- coordinate transforms ----------

const C_MIN = 0, C_MAX = 6.67;
const T_MIN = 0, T_MAX = 1600;
const PX = { left: 80, right: 940, top: 40, bottom: 540 };

const xOf = (C) => PX.left + ((C - C_MIN) / (C_MAX - C_MIN)) * (PX.right - PX.left);
const yOf = (T) => PX.bottom - ((T - T_MIN) / (T_MAX - T_MIN)) * (PX.bottom - PX.top);
const cOfX = (x) => C_MIN + ((x - PX.left) / (PX.right - PX.left)) * (C_MAX - C_MIN);
const tOfY = (y) => T_MIN + ((PX.bottom - y) / (PX.bottom - PX.top)) * (T_MAX - T_MIN);

// ---------- key points (C %, T °C) ----------

const KEY = {
  pureFeMelt:   { C: 0.00, T: 1538 },
  peritectic:   { C: 0.16, T: 1495 },
  peritecticL:  { C: 0.51, T: 1495 },
  deltaMaxC:    { C: 0.10, T: 1493 },
  eutectoid:    { C: 0.76, T: 727  },
  eutectoidLeft:{ C: 0.022, T: 727 },
  gammaMaxC:    { C: 2.14, T: 1148 },
  eutectic:     { C: 4.30, T: 1148 },
  fe3cMelt:     { C: 6.67, T: 1227 },
};

const C_FE3C = 6.67;

// ---------- phase boundary functions ----------

// γ-side liquidus, T(C). Returns °C for given wt% C, or null if outside range.
function liquidusGamma(C) {
  if (C < 0 || C > KEY.eutectic.C) return null;
  if (C <= KEY.peritecticL.C) {
    // From (0, 1538) to (0.51, 1495), linear
    return KEY.pureFeMelt.T + (KEY.peritecticL.T - KEY.pureFeMelt.T) * (C / KEY.peritecticL.C);
  }
  // From (0.51, 1495) to (4.30, 1148), linear
  return KEY.peritecticL.T + (KEY.eutectic.T - KEY.peritecticL.T) * (C - KEY.peritecticL.C) / (KEY.eutectic.C - KEY.peritecticL.C);
}

// Fe₃C-side liquidus, T(C). From (4.30, 1148) to (6.67, 1227).
function liquidusFe3c(C) {
  if (C < KEY.eutectic.C || C > C_FE3C) return null;
  return KEY.eutectic.T + (KEY.fe3cMelt.T - KEY.eutectic.T) * (C - KEY.eutectic.C) / (C_FE3C - KEY.eutectic.C);
}

// γ-solidus (lower boundary of L+γ region), T(C). Simplified from (0.16, 1493) to (2.14, 1148).
function solidusGamma(C) {
  if (C < KEY.peritectic.C || C > KEY.gammaMaxC.C) return null;
  return KEY.peritectic.T + (KEY.gammaMaxC.T - KEY.peritectic.T) * (C - KEY.peritectic.C) / (KEY.gammaMaxC.C - KEY.peritectic.C);
}

// A3 line: γ-(α+γ) boundary, T(C). From (0, 912) to (0.76, 727).
function a3(C) {
  if (C < 0 || C > KEY.eutectoid.C) return null;
  return 912 + (KEY.eutectoid.T - 912) * (C / KEY.eutectoid.C);
}

// Acm line: γ-(γ+Fe₃C) boundary, T(C). From (0.76, 727) to (2.14, 1148).
function acm(C) {
  if (C < KEY.eutectoid.C || C > KEY.gammaMaxC.C) return null;
  return KEY.eutectoid.T + (KEY.gammaMaxC.T - KEY.eutectoid.T) * (C - KEY.eutectoid.C) / (KEY.gammaMaxC.C - KEY.eutectoid.C);
}

// α-phase max C solubility curve, approximate. C(T) for T in 0..727.
function alphaMaxC(T) {
  if (T >= 727) return 0.022;
  // Roughly quadratic decay; pinned at 0.022% at 727, 0.005% at 200, 0.001% at 20.
  const norm = T / 727;
  return Math.max(0.0008, 0.022 * norm * norm);
}

// ---------- inverse functions: composition at given temperature on each line ----------

function liquidusGammaInv(T) {
  // Returns C such that liquidusGamma(C) = T (the liquid-side composition).
  if (T >= KEY.peritecticL.T && T <= KEY.pureFeMelt.T) {
    // Lower segment from (0, 1538) down to (0.51, 1495)
    return KEY.peritecticL.C * (KEY.pureFeMelt.T - T) / (KEY.pureFeMelt.T - KEY.peritecticL.T);
  }
  if (T >= KEY.eutectic.T && T < KEY.peritecticL.T) {
    return KEY.peritecticL.C + (KEY.eutectic.C - KEY.peritecticL.C) * (KEY.peritecticL.T - T) / (KEY.peritecticL.T - KEY.eutectic.T);
  }
  return null;
}

function liquidusFe3cInv(T) {
  if (T < KEY.eutectic.T || T > KEY.fe3cMelt.T) return null;
  return KEY.eutectic.C + (C_FE3C - KEY.eutectic.C) * (T - KEY.eutectic.T) / (KEY.fe3cMelt.T - KEY.eutectic.T);
}

function solidusGammaInv(T) {
  if (T < KEY.gammaMaxC.T || T > KEY.peritectic.T) return null;
  return KEY.peritectic.C + (KEY.gammaMaxC.C - KEY.peritectic.C) * (KEY.peritectic.T - T) / (KEY.peritectic.T - KEY.gammaMaxC.T);
}

function a3Inv(T) {
  if (T < KEY.eutectoid.T || T > 912) return null;
  return KEY.eutectoid.C * (912 - T) / (912 - KEY.eutectoid.T);
}

function acmInv(T) {
  if (T < KEY.eutectoid.T || T > KEY.gammaMaxC.T) return null;
  return KEY.eutectoid.C + (KEY.gammaMaxC.C - KEY.eutectoid.C) * (T - KEY.eutectoid.T) / (KEY.gammaMaxC.T - KEY.eutectoid.T);
}

// ---------- region classifier ----------

function classify(C, T) {
  if (C < 0 || C > C_FE3C) return { region: "out-of-range" };
  if (T < 0 || T > 1600) return { region: "out-of-range" };

  // 1. Above liquidus → all liquid
  const liqGamma = liquidusGamma(C);
  const liqFe3c = liquidusFe3c(C);
  if (liqGamma !== null && T > liqGamma) return { region: "liquid", label: "L (liquid)", phases: ["L"] };
  if (liqFe3c !== null && T > liqFe3c) return { region: "liquid", label: "L (liquid)", phases: ["L"] };

  // 2. Between liquidus and eutectic horizontal: either L+γ or L+Fe3C
  if (T > KEY.eutectic.T) {
    if (C < KEY.eutectic.C) {
      // L+γ if above solidusGamma, else γ
      const sol = solidusGamma(C);
      // For C < 0.16 (left of peritectic): handled in γ region below
      if (sol !== null && T > sol) {
        const cL = liquidusGammaInv(T);
        const cS = solidusGammaInv(T);
        if (cL !== null && cS !== null) {
          const fL = (C - cS) / (cL - cS);
          const fG = 1 - fL;
          return { region: "L+γ", label: "L + γ (liquid + austenite)", phases: ["L", "γ"], fractions: { L: fL, γ: fG }, boundaries: { L: cL, γ: cS } };
        }
      }
    } else {
      // Right of eutectic: L+Fe3C above eutectic horizontal
      const cL = liquidusFe3cInv(T);
      if (cL !== null) {
        const fL = (C_FE3C - C) / (C_FE3C - cL);
        const fFe = 1 - fL;
        return { region: "L+Fe3C", label: "L + Fe₃C (liquid + cementite)", phases: ["L", "Fe₃C"], fractions: { L: fL, "Fe₃C": fFe }, boundaries: { L: cL, "Fe₃C": C_FE3C } };
      }
    }
  }

  // 3. γ single phase: between A3/Acm and solidus/eutectic
  if (T > KEY.eutectoid.T) {
    if (C < KEY.eutectoid.C) {
      const a = a3(C);
      if (a !== null && T > a) return { region: "γ", label: "γ (austenite)", phases: ["γ"] };
    } else if (C <= KEY.gammaMaxC.C) {
      const ac = acm(C);
      if (ac !== null && T > ac && T <= KEY.eutectic.T) return { region: "γ", label: "γ (austenite)", phases: ["γ"] };
      // Between peritectic and gamma max C, above acm
      if (ac !== null && T > ac) return { region: "γ", label: "γ (austenite)", phases: ["γ"] };
    }
  }

  // 4. α+γ (hypoeutectoid two-phase): below A3, above 727 °C
  if (T > KEY.eutectoid.T && C >= 0 && C < KEY.eutectoid.C) {
    const a = a3(C);
    if (a !== null && T <= a) {
      const cG = a3Inv(T);
      const cA = alphaMaxC(T);
      if (cG !== null) {
        const fG = (C - cA) / (cG - cA);
        const fA = 1 - fG;
        return { region: "α+γ", label: "α + γ (ferrite + austenite)", phases: ["α", "γ"], fractions: { α: fA, γ: fG }, boundaries: { α: cA, γ: cG } };
      }
    }
  }

  // 5. γ+Fe3C (hypereutectoid two-phase): below Acm, above 727 °C, between eutectoid C and gamma max
  if (T > KEY.eutectoid.T && C >= KEY.eutectoid.C) {
    if (C <= KEY.gammaMaxC.C) {
      const ac = acm(C);
      if (ac !== null && T <= ac) {
        const cG = acmInv(T);
        if (cG !== null) {
          const fG = (C_FE3C - C) / (C_FE3C - cG);
          const fFe = 1 - fG;
          return { region: "γ+Fe3C", label: "γ + Fe₃C (austenite + cementite)", phases: ["γ", "Fe₃C"], fractions: { γ: fG, "Fe₃C": fFe }, boundaries: { γ: cG, "Fe₃C": C_FE3C } };
        }
      }
    } else {
      // Beyond γ max (2.14% C), still above eutectic horizontal but below liquidus on Fe3C side
      // Check we are below liquidusFe3c
      const liq = liquidusFe3c(C);
      if (liq !== null && T <= liq && T > KEY.eutectic.T) {
        const cG = KEY.gammaMaxC.C;  // γ saturates at gamma max at this T (approximate)
        const fG = (C_FE3C - C) / (C_FE3C - cG);
        const fFe = 1 - fG;
        return { region: "γ+Fe3C", label: "γ + Fe₃C (austenite + cementite)", phases: ["γ", "Fe₃C"], fractions: { γ: fG, "Fe₃C": fFe }, boundaries: { γ: cG, "Fe₃C": C_FE3C } };
      }
    }
  }

  // 6. Below eutectoid (727 °C)
  if (T <= KEY.eutectoid.T) {
    const cA = alphaMaxC(T);
    if (C <= cA) return { region: "α", label: "α (ferrite)", phases: ["α"] };
    const fA = (C_FE3C - C) / (C_FE3C - cA);
    const fFe = 1 - fA;
    return { region: "α+Fe3C", label: "α + Fe₃C (ferrite + cementite)", phases: ["α", "Fe₃C"], fractions: { α: fA, "Fe₃C": fFe }, boundaries: { α: cA, "Fe₃C": C_FE3C } };
  }

  return { region: "unmapped", label: "unmapped" };
}

// ---------- SVG path helpers ----------

function sample(fn, cStart, cEnd, n) {
  const pts = [];
  for (let i = 0; i <= n; i++) {
    const C = cStart + (cEnd - cStart) * (i / n);
    const T = fn(C);
    if (T !== null) pts.push([C, T]);
  }
  return pts;
}

function svgPolyline(pts) {
  return pts.map(([C, T]) => `${xOf(C).toFixed(1)},${yOf(T).toFixed(1)}`).join(" ");
}

function svgPath(pts) {
  if (pts.length === 0) return "";
  let d = `M ${xOf(pts[0][0]).toFixed(1)} ${yOf(pts[0][1]).toFixed(1)}`;
  for (let i = 1; i < pts.length; i++) {
    d += ` L ${xOf(pts[i][0]).toFixed(1)} ${yOf(pts[i][1]).toFixed(1)}`;
  }
  return d;
}

// ---------- SVG diagram builder ----------

function buildDiagram() {
  const liqPtsGamma = sample(liquidusGamma, 0, KEY.eutectic.C, 60);
  const liqPtsFe3c  = sample(liquidusFe3c, KEY.eutectic.C, C_FE3C, 30);
  const solPtsGamma = sample(solidusGamma, KEY.peritectic.C, KEY.gammaMaxC.C, 40);
  const a3Pts       = sample(a3, 0, KEY.eutectoid.C, 30);
  const acmPts      = sample(acm, KEY.eutectoid.C, KEY.gammaMaxC.C, 30);

  // Build region polygons (composition-temperature corners; viewport coords)
  const PA = `${xOf(0)} ${yOf(0)}`;          // bottom-left
  const PB = `${xOf(C_FE3C)} ${yOf(0)}`;     // bottom-right
  const PC = `${xOf(C_FE3C)} ${yOf(T_MAX)}`; // top-right
  const PD = `${xOf(0)} ${yOf(T_MAX)}`;      // top-left

  // Liquid region: above liquidus, bounded above by viewport top
  const liqPolyTop = [`M ${xOf(0)} ${yOf(T_MAX)}`, `L ${xOf(0)} ${yOf(KEY.pureFeMelt.T)}`];
  liqPtsGamma.forEach(([C, T]) => liqPolyTop.push(`L ${xOf(C).toFixed(1)} ${yOf(T).toFixed(1)}`));
  liqPtsFe3c.forEach(([C, T]) => liqPolyTop.push(`L ${xOf(C).toFixed(1)} ${yOf(T).toFixed(1)}`));
  liqPolyTop.push(`L ${xOf(C_FE3C)} ${yOf(T_MAX)} Z`);
  const liqPathD = liqPolyTop.join(" ");

  // L+γ region: between solidusGamma and liquidusGamma, capped at eutectic
  const lGammaTop = [...liqPtsGamma].reverse();
  const lGammaBot = [...solPtsGamma];
  const lgPath = [
    `M ${xOf(0).toFixed(1)} ${yOf(KEY.pureFeMelt.T).toFixed(1)}`,
    // up to (0.16, 1493) along delta solidus (linear)
    `L ${xOf(KEY.peritectic.C).toFixed(1)} ${yOf(KEY.deltaMaxC.T).toFixed(1)}`,
    // down along solidusGamma
    ...lGammaBot.map(([C, T]) => `L ${xOf(C).toFixed(1)} ${yOf(T).toFixed(1)}`),
    // across eutectic horizontal to liquidus
    `L ${xOf(KEY.eutectic.C).toFixed(1)} ${yOf(KEY.eutectic.T).toFixed(1)}`,
    // up liquidus back to (0, 1538)
    ...lGammaTop.map(([C, T]) => `L ${xOf(C).toFixed(1)} ${yOf(T).toFixed(1)}`),
    "Z"
  ].join(" ");

  // γ single phase: bounded by solidusGamma above, A3 below, Acm right, eutectoid right side
  // Simplified: polygon from (0, 912) along A3 to (0.76, 727), eutectic horizontal to (2.14, 727)... 
  // wait, gamma extends above too. Let me trace it carefully:
  // Start at (0, 912) (A3 left end)
  // Go up to (0, 1538) along left edge - but that's into liquid. Actually γ is bounded:
  //   left: x = 0 (theoretical, but α-phase pure Fe goes up to 912)
  //   no wait, γ exists from 727 (eutectoid) up to ~912 at C=0, where it transitions to δ.
  // For simplicity I'll draw γ as the region bounded by:
  //   bottom-left: A3 from (0, 912) to (0.76, 727)
  //   bottom-right: Acm from (0.76, 727) to (2.14, 1148)
  //   top-right: gamma-solidus from (2.14, 1148) to (0.16, 1493)
  //   top-left: vertical drop from (0.16, 1493) to (0, 912) ... actually this hits δ region
  // I'll approximate: from (0, 912) up to (0, 1394) along the γ-δ boundary, then to (0.16, 1493).
  
  const gammaPath = [
    `M ${xOf(0).toFixed(1)} ${yOf(912).toFixed(1)}`,
    `L ${xOf(0).toFixed(1)} ${yOf(1394).toFixed(1)}`, // up left edge (γ-δ approximate)
    `L ${xOf(KEY.peritectic.C).toFixed(1)} ${yOf(KEY.deltaMaxC.T).toFixed(1)}`,
    ...solPtsGamma.map(([C, T]) => `L ${xOf(C).toFixed(1)} ${yOf(T).toFixed(1)}`),
    // Acm down to eutectoid
    ...[...acmPts].reverse().map(([C, T]) => `L ${xOf(C).toFixed(1)} ${yOf(T).toFixed(1)}`),
    // A3 back to (0, 912)
    ...[...a3Pts].reverse().map(([C, T]) => `L ${xOf(C).toFixed(1)} ${yOf(T).toFixed(1)}`),
    "Z"
  ].join(" ");

  // α+γ region: bounded by A3 above, eutectoid horizontal below, α-solubility left
  const alphaGammaPath = [
    `M ${xOf(0).toFixed(1)} ${yOf(912).toFixed(1)}`,
    ...a3Pts.map(([C, T]) => `L ${xOf(C).toFixed(1)} ${yOf(T).toFixed(1)}`),
    `L ${xOf(KEY.eutectoidLeft.C).toFixed(1)} ${yOf(KEY.eutectoid.T).toFixed(1)}`,
    `L ${xOf(0).toFixed(1)} ${yOf(KEY.eutectoid.T).toFixed(1)}`,
    "Z"
  ].join(" ");

  // γ+Fe3C: bounded by Acm left, eutectic horizontal top (only between gamma max and Fe3C), eutectoid bottom
  const gammaFe3cPath = [
    `M ${xOf(KEY.eutectoid.C).toFixed(1)} ${yOf(KEY.eutectoid.T).toFixed(1)}`,
    ...acmPts.map(([C, T]) => `L ${xOf(C).toFixed(1)} ${yOf(T).toFixed(1)}`),
    // along eutectic horizontal from gamma max to Fe3C melt up to liquidus Fe3c side
    `L ${xOf(C_FE3C).toFixed(1)} ${yOf(KEY.eutectic.T).toFixed(1)}`,
    `L ${xOf(C_FE3C).toFixed(1)} ${yOf(KEY.eutectoid.T).toFixed(1)}`,
    "Z"
  ].join(" ");

  // α+Fe3C: below 727, full width except thin α slice at left
  const alphaFe3cPath = [
    `M ${xOf(KEY.eutectoidLeft.C).toFixed(1)} ${yOf(KEY.eutectoid.T).toFixed(1)}`,
    `L ${xOf(C_FE3C).toFixed(1)} ${yOf(KEY.eutectoid.T).toFixed(1)}`,
    `L ${xOf(C_FE3C).toFixed(1)} ${yOf(0).toFixed(1)}`,
    `L ${xOf(KEY.eutectoidLeft.C).toFixed(1)} ${yOf(0).toFixed(1)}`,
    "Z"
  ].join(" ");

  // L+Fe3C: bounded by liquidus Fe3c (left), eutectic horizontal (bottom), right edge (C=6.67)
  const lFe3cPath = [
    `M ${xOf(KEY.eutectic.C).toFixed(1)} ${yOf(KEY.eutectic.T).toFixed(1)}`,
    ...liqPtsFe3c.map(([C, T]) => `L ${xOf(C).toFixed(1)} ${yOf(T).toFixed(1)}`),
    `L ${xOf(C_FE3C).toFixed(1)} ${yOf(KEY.eutectic.T).toFixed(1)}`,
    "Z"
  ].join(" ");

  // ===== axes and gridlines =====
  const cGridValues = [0, 0.5, 1, 1.5, 2, 3, 4, 5, 6, 6.67];
  const tGridValues = [0, 200, 400, 600, 727, 800, 1000, 1148, 1200, 1400, 1538];

  const axisLines = `
    <line x1="${PX.left}" y1="${PX.top}"    x2="${PX.left}" y2="${PX.bottom}" class="phase-axis"/>
    <line x1="${PX.left}" y1="${PX.bottom}" x2="${PX.right}" y2="${PX.bottom}" class="phase-axis"/>
  `;

  const cTicks = cGridValues.map(C =>
    `<g><line x1="${xOf(C)}" y1="${PX.bottom}" x2="${xOf(C)}" y2="${PX.bottom + 6}" class="phase-tick"/>
      <text x="${xOf(C)}" y="${PX.bottom + 22}" class="phase-tick-text" text-anchor="middle">${C}</text></g>`
  ).join("");

  const tTicks = tGridValues.map(T =>
    `<g><line x1="${PX.left - 6}" y1="${yOf(T)}" x2="${PX.left}" y2="${yOf(T)}" class="phase-tick"/>
      <text x="${PX.left - 12}" y="${yOf(T) + 4}" class="phase-tick-text" text-anchor="end">${T}</text></g>`
  ).join("");

  // ===== labels =====
  const labels = `
    <text x="${xOf(0.4)}" y="${yOf(1300)}" class="phase-region-label">γ</text>
    <text x="${xOf(0.35)}" y="${yOf(800)}" class="phase-region-label phase-region-label-sm">α+γ</text>
    <text x="${xOf(1.5)}" y="${yOf(900)}" class="phase-region-label phase-region-label-sm">γ+Fe₃C</text>
    <text x="${xOf(3)}" y="${yOf(400)}" class="phase-region-label">α+Fe₃C</text>
    <text x="${xOf(3)}" y="${yOf(1400)}" class="phase-region-label">L</text>
    <text x="${xOf(1.2)}" y="${yOf(1300)}" class="phase-region-label phase-region-label-sm">L+γ</text>
    <text x="${xOf(5.4)}" y="${yOf(1200)}" class="phase-region-label phase-region-label-sm">L+Fe₃C</text>
    <text x="${xOf(C_MIN)+18}" y="${yOf(300)}" class="phase-region-label phase-region-label-sm">α</text>
    <text x="${(PX.left + PX.right) / 2}" y="${PX.bottom + 48}" class="phase-axis-title" text-anchor="middle">Composition (wt % C)</text>
    <text x="22" y="${(PX.top + PX.bottom) / 2}" class="phase-axis-title" transform="rotate(-90, 22, ${(PX.top + PX.bottom) / 2})" text-anchor="middle">Temperature (°C)</text>
    <text x="${xOf(C_FE3C) + 6}" y="${yOf(800)}" class="phase-tick-text">Fe₃C</text>
  `;

  // ===== critical-line annotations =====
  const annotations = `
    <g class="phase-critline">
      <line x1="${xOf(KEY.eutectoidLeft.C)}" y1="${yOf(727)}" x2="${xOf(C_FE3C)}" y2="${yOf(727)}" class="phase-invariant"/>
      <text x="${xOf(5.3)}" y="${yOf(727) - 6}" class="phase-line-label">A1 / eutectoid · 727 °C</text>
      <line x1="${xOf(KEY.gammaMaxC.C)}" y1="${yOf(1148)}" x2="${xOf(C_FE3C)}" y2="${yOf(1148)}" class="phase-invariant"/>
      <text x="${xOf(5.3)}" y="${yOf(1148) - 6}" class="phase-line-label">eutectic · 1148 °C</text>
      <circle cx="${xOf(KEY.eutectoid.C)}" cy="${yOf(KEY.eutectoid.T)}" r="4" class="phase-keypoint"/>
      <circle cx="${xOf(KEY.eutectic.C)}" cy="${yOf(KEY.eutectic.T)}" r="4" class="phase-keypoint"/>
    </g>
  `;

  return `
    <svg viewBox="0 0 1000 600" class="phase-svg" xmlns="http://www.w3.org/2000/svg">
      <defs></defs>
      <path d="${liqPathD}" class="phase-region phase-r-liquid"/>
      <path d="${lgPath}" class="phase-region phase-r-lg"/>
      <path d="${gammaPath}" class="phase-region phase-r-gamma"/>
      <path d="${alphaGammaPath}" class="phase-region phase-r-ag"/>
      <path d="${gammaFe3cPath}" class="phase-region phase-r-gf"/>
      <path d="${alphaFe3cPath}" class="phase-region phase-r-af"/>
      <path d="${lFe3cPath}" class="phase-region phase-r-lf"/>

      <polyline points="${svgPolyline(liqPtsGamma)} ${svgPolyline(liqPtsFe3c)}" class="phase-line phase-line-liquidus"/>
      <polyline points="${svgPolyline(solPtsGamma)}" class="phase-line phase-line-solidus"/>
      <polyline points="${svgPolyline(a3Pts)}" class="phase-line phase-line-a3"/>
      <polyline points="${svgPolyline(acmPts)}" class="phase-line phase-line-acm"/>

      ${annotations}
      ${labels}
      ${axisLines}
      ${cTicks}
      ${tTicks}

      <g id="phase-crosshair" class="phase-crosshair">
        <line id="phase-ch-v" x1="0" y1="0" x2="0" y2="0"/>
        <line id="phase-ch-h" x1="0" y1="0" x2="0" y2="0"/>
        <circle id="phase-ch-dot" cx="0" cy="0" r="5"/>
      </g>

      <rect x="${PX.left}" y="${PX.top}" width="${PX.right - PX.left}" height="${PX.bottom - PX.top}" class="phase-hit" id="phase-hit"/>
    </svg>
  `;
}

// ---------- DOM helpers ----------

function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") node.className = v;
    else if (k === "style") node.style.cssText = v;
    else if (k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (v !== null && v !== undefined && v !== false) node.setAttribute(k, v === true ? "" : v);
  }
  for (const c of children) {
    if (c === null || c === undefined || c === false) continue;
    node.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
  }
  return node;
}

function fmtFrac(f) {
  if (f === undefined || f === null || !Number.isFinite(f)) return "—";
  return (f * 100).toFixed(1) + "%";
}

function fmtC(c) {
  if (!Number.isFinite(c)) return "—";
  if (c < 0.01) return c.toFixed(3) + " % C";
  if (c < 1) return c.toFixed(2) + " % C";
  return c.toFixed(2) + " % C";
}

// ---------- interactive widget ----------

function renderTool() {
  let curC = 0.40;
  let curT = 800;

  const wrap = el("section", { class: "phase-tool", "aria-labelledby": "phase-title" });
  wrap.appendChild(el("h2", { id: "phase-title", class: "phase-h" }, "Fe-Fe₃C interactive diagram"));
  wrap.appendChild(el("p", { class: "phase-sub" },
    "Click anywhere on the diagram or enter (C, T) values. Below: the phase region you're in, and the lever-rule mass fractions for two-phase regions. The diagram is the metastable Fe-Fe₃C system; for hot-cooled cast irons graphite forms instead of Fe₃C but the eutectoid behavior is similar."
  ));

  const svgHost = el("div", { class: "phase-svg-host" });
  svgHost.innerHTML = buildDiagram();
  wrap.appendChild(svgHost);

  const inputRow = el("div", { class: "phase-input-row" });
  const cField = el("label", { class: "phase-field" });
  cField.appendChild(el("span", { class: "phase-field-label" }, "Composition (% C)"));
  const cInput = el("input", { type: "number", class: "phase-input", step: "0.05", min: "0", max: "6.67", value: String(curC) });
  cField.appendChild(cInput);
  inputRow.appendChild(cField);

  const tField = el("label", { class: "phase-field" });
  tField.appendChild(el("span", { class: "phase-field-label" }, "Temperature (°C)"));
  const tInput = el("input", { type: "number", class: "phase-input", step: "10", min: "0", max: "1600", value: String(curT) });
  tField.appendChild(tInput);
  inputRow.appendChild(tField);

  const presetField = el("label", { class: "phase-field" });
  presetField.appendChild(el("span", { class: "phase-field-label" }, "Quick presets"));
  const preset = el("select", { class: "phase-select", "aria-label": "Preset alloy/temperature" });
  const presets = [
    { v: "", label: "select…" },
    { v: "0.18,900",  label: "AISI 1018 at 900 °C (γ)" },
    { v: "0.18,800",  label: "AISI 1018 at 800 °C (α+γ)" },
    { v: "0.45,800",  label: "AISI 1045 at 800 °C (α+γ)" },
    { v: "0.45,500",  label: "AISI 1045 at 500 °C (α+Fe₃C)" },
    { v: "0.76,800",  label: "Eutectoid steel at 800 °C (γ)" },
    { v: "0.95,900",  label: "AISI 1095 at 900 °C (γ+Fe₃C)" },
    { v: "2.0,1100",  label: "2.0 % C at 1100 °C (γ+Fe₃C)" },
    { v: "4.30,1148", label: "Eutectic point" },
    { v: "0.76,727",  label: "Eutectoid point" },
  ];
  for (const p of presets) {
    preset.appendChild(el("option", { value: p.v }, p.label));
  }
  presetField.appendChild(preset);
  inputRow.appendChild(presetField);

  wrap.appendChild(inputRow);

  const resultHost = el("div", { class: "phase-result" });
  wrap.appendChild(resultHost);

  function setCrosshair(C, T) {
    const svg = svgHost.querySelector("svg");
    if (!svg) return;
    const xv = xOf(C);
    const yv = yOf(T);
    const v = svg.querySelector("#phase-ch-v");
    const h = svg.querySelector("#phase-ch-h");
    const dot = svg.querySelector("#phase-ch-dot");
    v.setAttribute("x1", xv); v.setAttribute("x2", xv);
    v.setAttribute("y1", PX.top); v.setAttribute("y2", PX.bottom);
    h.setAttribute("y1", yv); h.setAttribute("y2", yv);
    h.setAttribute("x1", PX.left); h.setAttribute("x2", PX.right);
    dot.setAttribute("cx", xv); dot.setAttribute("cy", yv);
  }

  function update() {
    const C = parseFloat(cInput.value);
    const T = parseFloat(tInput.value);
    if (!Number.isFinite(C) || !Number.isFinite(T)) {
      resultHost.innerHTML = "";
      resultHost.appendChild(el("p", { class: "phase-empty" }, "Enter valid composition (0 to 6.67 % C) and temperature (0 to 1600 °C)."));
      return;
    }
    curC = C; curT = T;
    setCrosshair(C, T);

    const r = classify(C, T);
    resultHost.innerHTML = "";
    if (r.region === "out-of-range") {
      resultHost.appendChild(el("p", { class: "phase-empty" }, "Outside the diagram's plotted range."));
      return;
    }

    // Region pill + summary
    resultHost.appendChild(el("div", { class: `phase-pill phase-pill-${r.region.replace(/\W/g, "-")}` }, r.label || r.region));

    const sum = el("dl", { class: "phase-summary" });
    sum.appendChild(el("dt", {}, "Composition"));
    sum.appendChild(el("dd", {}, fmtC(C)));
    sum.appendChild(el("dt", {}, "Temperature"));
    sum.appendChild(el("dd", {}, T.toFixed(0) + " °C"));
    sum.appendChild(el("dt", {}, "Phases present"));
    sum.appendChild(el("dd", {}, (r.phases || []).join(" + ") || "—"));

    if (r.fractions && r.boundaries) {
      const phases = Object.keys(r.fractions);
      for (const ph of phases) {
        const f = r.fractions[ph];
        const cb = r.boundaries[ph];
        sum.appendChild(el("dt", {}, `Fraction ${ph}`));
        sum.appendChild(el("dd", {},
          el("strong", {}, fmtFrac(f)),
          ` · phase composition ${fmtC(cb)}`
        ));
      }
      resultHost.appendChild(sum);

      // Lever rule math note
      const phaseNames = Object.keys(r.boundaries);
      if (phaseNames.length === 2) {
        const [p1, p2] = phaseNames;
        const c1 = r.boundaries[p1];
        const c2 = r.boundaries[p2];
        resultHost.appendChild(el("p", { class: "phase-math" },
          `Tie line at T = ${T.toFixed(0)} °C runs from ${fmtC(c1)} (${p1}) to ${fmtC(c2)} (${p2}). Lever rule: f(${p1}) = (${c2.toFixed(2)} − ${C.toFixed(2)}) / (${c2.toFixed(2)} − ${c1.toFixed(2)}); f(${p2}) = 1 − f(${p1}).`
        ));
      }
    } else {
      resultHost.appendChild(sum);
      resultHost.appendChild(el("p", { class: "phase-math" },
        "Single-phase region: lever rule does not apply. The phase composition equals the overall composition."
      ));
    }
  }

  // Hook up inputs and SVG click
  cInput.addEventListener("input", update);
  tInput.addEventListener("input", update);
  preset.addEventListener("change", () => {
    if (!preset.value) return;
    const [c, t] = preset.value.split(",").map(Number);
    cInput.value = c;
    tInput.value = t;
    update();
  });

  const hit = svgHost.querySelector("#phase-hit");
  hit.addEventListener("click", (ev) => {
    const svg = svgHost.querySelector("svg");
    const rect = svg.getBoundingClientRect();
    const xRatio = (ev.clientX - rect.left) / rect.width;
    const yRatio = (ev.clientY - rect.top) / rect.height;
    const xv = xRatio * 1000;  // viewBox width
    const yv = yRatio * 600;   // viewBox height
    const C = cOfX(xv);
    const T = tOfY(yv);
    cInput.value = Math.max(0, Math.min(6.67, C)).toFixed(2);
    tInput.value = Math.max(0, Math.min(1600, T)).toFixed(0);
    update();
  });

  update();
  return wrap;
}

// ---------- main render ----------

export async function render(root, ctx) {
  root.innerHTML = "";
  root.appendChild(el("a", { class: "detail-back-link", href: "#/" }, "← bench"));
  root.appendChild(el("p", { class: "section-eyebrow", style: "margin-top:1rem;" }, "Materials"));
  root.appendChild(el("h1", { class: "section-title" }, "PHASE"));
  root.appendChild(el("p", { class: "section-lede" },
    "The Fe-Fe₃C diagram with click-to-query region identification and lever-rule fractions, plus reference cards for the lever rule, the Gibbs phase rule, the three common invariant transformations, and three companion binary diagrams (Cu-Zn brasses, Al-Si castings, Pb-Sn solders)."
  ));

  root.appendChild(renderTool());

  const entries = await loadEntriesForModule("phase");
  if (entries.length === 0) return;

  root.appendChild(el("h2", { class: "section-eyebrow", style: "margin-top:2.5rem;" }, "Reference cards"));
  const grid = el("div", { class: "card-grid" });
  for (const entry of entries) {
    const front = renderFront(entry);
    const link = el("a", { href: `#/card/${encodeURIComponent(entry.id)}`, style: "text-decoration:none;color:inherit;" });
    link.appendChild(front);
    grid.appendChild(link);
  }
  root.appendChild(grid);
}
