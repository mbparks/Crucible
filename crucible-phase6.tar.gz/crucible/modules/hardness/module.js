// hardness/module.js. Hardness scale converter and reference cards.
//
// Conversions follow ASTM E140 representative values for steel. The values
// are valid for through-hardened or annealed plain-carbon and low-alloy steels;
// for non-ferrous metals, tool steels above 60 HRC, or thin-case carburized
// parts, the conversion is approximate. Always verify on actual material when
// the value matters.

import { loadEntriesForModule } from "../../shared/js/data.js";
import { renderFront } from "../../shared/js/card.js";

// ASTM E140-like conversion table for steel. Each row is roughly equivalent.
// Tensile is in MPa (1 ksi ≈ 6.895 MPa). null means the scale does not apply
// in that hardness range.
const TABLE = [
  // HRC, HRB, HB,  HV,   Tensile MPa
  [ 68,  null, null, 940,  null],
  [ 67,  null, null, 900,  null],
  [ 66,  null, null, 865,  null],
  [ 65,  null, 739,  832,  null],
  [ 64,  null, 722,  800,  null],
  [ 63,  null, 705,  772,  null],
  [ 62,  null, 688,  746,  null],
  [ 61,  null, 670,  720,  null],
  [ 60,  null, 654,  697,  null],
  [ 58,  null, 615,  653,  null],
  [ 55,  null, 560,  595,  1980],
  [ 52,  null, 512,  544,  1820],
  [ 50,  null, 481,  513,  1730],
  [ 48,  null, 455,  484,  1640],
  [ 45,  null, 421,  446,  1520],
  [ 42,  null, 390,  411,  1390],
  [ 40,  null, 371,  391,  1290],
  [ 38,  null, 353,  371,  1230],
  [ 35,  null, 327,  345,  1140],
  [ 32,  null, 301,  319,  1050],
  [ 30,  null, 286,  301,  980],
  [ 28,  null, 271,  285,  920],
  [ 25,  null, 253,  266,  860],
  [ 22,  100,  238,  248,  800],
  [ 20,  98,   226,  236,  760],
  [ null, 96,  216,  225,  725],
  [ null, 94,  208,  216,  695],
  [ null, 92,  199,  207,  670],
  [ null, 90,  192,  200,  645],
  [ null, 88,  185,  193,  620],
  [ null, 86,  178,  185,  600],
  [ null, 84,  171,  178,  575],
  [ null, 82,  165,  172,  555],
  [ null, 80,  159,  166,  535],
  [ null, 75,  146,  152,  490],
  [ null, 70,  137,  142,  460],
  [ null, 65,  126,  131,  425],
  [ null, 60,  116,  121,  390],
  [ null, 55,  108,  113,  365],
  [ null, 50,  100,  105,  340],
];

const SCALES = [
  { id: "hrc",     label: "Rockwell C (HRC)",  index: 0, range: [20, 68], precision: 1 },
  { id: "hrb",     label: "Rockwell B (HRB)",  index: 1, range: [50, 100], precision: 1 },
  { id: "hb",      label: "Brinell (HB)",      index: 2, range: [100, 740], precision: 0 },
  { id: "hv",      label: "Vickers (HV)",      index: 3, range: [105, 940], precision: 0 },
  { id: "tensile", label: "Tensile (MPa)",     index: 4, range: [340, 1980], precision: 0 },
];

function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") node.className = v;
    else if (k === "dataset") for (const [dk, dv] of Object.entries(v)) node.dataset[dk] = dv;
    else if (k === "style") node.style.cssText = v;
    else if (k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (v !== null && v !== undefined && v !== false) node.setAttribute(k, v === true ? "" : v);
  }
  for (const c of children) {
    if (c === null || c === undefined || c === false) continue;
    node.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
  }
  return node;
}

/**
 * Convert a value from one scale to all the others by walking the lookup table
 * and finding the bracket that contains it, then linearly interpolating across
 * other columns.
 */
function convert(sourceScale, value) {
  const idx = sourceScale.index;
  // Build (sourceVal, row) list, ignoring nulls in the source column, ordered by sourceVal ascending
  const rows = TABLE
    .map((r, i) => ({ row: r, src: r[idx], i }))
    .filter(o => o.src !== null);
  // Sort by src ascending
  rows.sort((a, b) => a.src - b.src);

  // Out-of-range cases
  if (value < rows[0].src || value > rows[rows.length - 1].src) {
    return { outOfRange: true, range: [rows[0].src, rows[rows.length - 1].src] };
  }

  // Find bracket
  let lo = rows[0], hi = rows[rows.length - 1];
  for (let i = 0; i < rows.length - 1; i++) {
    if (rows[i].src <= value && value <= rows[i + 1].src) {
      lo = rows[i];
      hi = rows[i + 1];
      break;
    }
  }
  const t = lo.src === hi.src ? 0 : (value - lo.src) / (hi.src - lo.src);

  // Interpolate other columns
  const result = {};
  for (const s of SCALES) {
    if (s.id === sourceScale.id) continue;
    const a = lo.row[s.index];
    const b = hi.row[s.index];
    if (a === null || b === null) {
      result[s.id] = null;
    } else {
      result[s.id] = a + (b - a) * t;
    }
  }
  return { outOfRange: false, values: result };
}

function formatValue(scale, v) {
  if (v === null || v === undefined || !Number.isFinite(v)) return "—";
  if (scale.precision === 0) return Math.round(v).toString();
  return v.toFixed(scale.precision);
}

function renderConverter() {
  let currentScaleId = "hrc";
  let currentValue = 30;

  const wrap = el("section", { class: "hd-converter", "aria-labelledby": "hd-conv-title" });
  wrap.appendChild(el("h2", { id: "hd-conv-title", class: "hd-conv-title" }, "Hardness converter"));
  wrap.appendChild(el("p", { class: "hd-conv-sub" },
    "Enter a value in any scale to see equivalents. Values follow ASTM E140 for through-hardened steel; for tool steels above 60 HRC, non-ferrous metals, or thin-case parts, treat as approximate."
  ));

  const inputRow = el("div", { class: "hd-input-row" });
  const select = el("select", { class: "hd-scale-select", "aria-label": "Source scale" });
  for (const s of SCALES) {
    const opt = el("option", { value: s.id }, s.label);
    if (s.id === currentScaleId) opt.selected = true;
    select.appendChild(opt);
  }
  const input = el("input", {
    type: "number",
    class: "hd-value-input",
    step: "0.5",
    value: String(currentValue),
    "aria-label": "Hardness value",
  });

  inputRow.appendChild(el("label", { class: "hd-input-label" }, "Source:"));
  inputRow.appendChild(select);
  inputRow.appendChild(el("label", { class: "hd-input-label" }, "Value:"));
  inputRow.appendChild(input);
  wrap.appendChild(inputRow);

  const resultTable = el("dl", { class: "hd-result-table" });
  wrap.appendChild(resultTable);

  function update() {
    const scale = SCALES.find(s => s.id === currentScaleId);
    const v = parseFloat(input.value);
    resultTable.innerHTML = "";

    if (!Number.isFinite(v)) {
      resultTable.appendChild(el("p", { class: "hd-empty" }, "Enter a value."));
      return;
    }

    const result = convert(scale, v);
    if (result.outOfRange) {
      resultTable.appendChild(el("p", { class: "hd-empty" },
        `Value out of conversion range. ${scale.label} table covers ${result.range[0]} to ${result.range[1]}.`
      ));
      return;
    }
    for (const s of SCALES) {
      if (s.id === currentScaleId) continue;
      const out = result.values[s.id];
      resultTable.appendChild(el("dt", {}, s.label));
      resultTable.appendChild(el("dd", { class: out === null ? "hd-na" : "" },
        formatValue(s, out)
      ));
    }
  }

  select.addEventListener("change", () => {
    currentScaleId = select.value;
    // Set a sensible default for the new scale
    const s = SCALES.find(x => x.id === currentScaleId);
    if (s) input.value = String(Math.round((s.range[0] + s.range[1]) / 2));
    update();
  });
  input.addEventListener("input", update);

  update();
  return wrap;
}

export async function render(root, ctx) {
  root.innerHTML = "";
  root.appendChild(el("a", { class: "detail-back-link", href: "#/" }, "← bench"));
  root.appendChild(el("p", { class: "section-eyebrow", style: "margin-top:1rem;" }, "Materials"));
  root.appendChild(el("h1", { class: "section-title" }, "HARDNESS"));
  root.appendChild(el("p", { class: "section-lede" },
    "Converter and reference cards across the six common hardness scales. Click a card for the full scale definition, indenter geometry, and notes on when each scale is the right answer."
  ));

  root.appendChild(renderConverter());

  // Reference cards beneath the converter
  const entries = await loadEntriesForModule("hardness");
  if (entries.length === 0) return;

  root.appendChild(el("h2", { class: "section-eyebrow", style: "margin-top:2.5rem;" }, "Reference cards"));
  const grid = el("div", { class: "card-grid" });
  for (const entry of entries) {
    const front = renderFront(entry);
    const link = el("a", { href: `#/card/${encodeURIComponent(entry.id)}`, style: "text-decoration:none;color:inherit;" });
    link.appendChild(front);
    grid.appendChild(link);
  }
  root.appendChild(grid);
}
