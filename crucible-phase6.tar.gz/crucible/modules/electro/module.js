// electro/module.js. Galvanic couple checker and electrochemistry reference grid.
//
// The checker uses representative open-circuit potentials in flowing seawater
// vs SCE. Stainless and PH steels are listed in both active and passive states,
// reflecting that the actual potential depends on whether the Cr-rich oxide
// film is intact. The defensive engineering choice is the active value.
//
// Severity bands follow ASM Vol. 13 (Corrosion) guidance:
//   < 50 mV   : compatible
//   50 - 150  : monitor
//   150 - 300 : moderate
//   > 300     : aggressive

import { loadEntriesForModule } from "../../shared/js/data.js";
import { renderFront } from "../../shared/js/card.js";

const METALS = [
  { id: "mg",        name: "Magnesium",                        V: -1.60 },
  { id: "zn",        name: "Zinc",                             V: -1.03 },
  { id: "galv",      name: "Galvanized steel",                 V: -1.00 },
  { id: "al-5052",   name: "Aluminum 5052 / 6061",             V: -0.85 },
  { id: "al-2024",   name: "Aluminum 2024 / 7075",             V: -0.70 },
  { id: "cd",        name: "Cadmium plating",                  V: -0.70 },
  { id: "steel",     name: "Mild steel / cast iron",           V: -0.60 },
  { id: "ss304-a",   name: "304 stainless (active)",           V: -0.50 },
  { id: "pbsn",      name: "Pb-Sn solder, lead, tin",          V: -0.48 },
  { id: "ss316-a",   name: "316 stainless (active)",           V: -0.45 },
  { id: "ss17-4-a",  name: "17-4 PH (active)",                 V: -0.40 },
  { id: "brass",     name: "Brass, copper, bronze",            V: -0.28 },
  { id: "ni",        name: "Nickel, Monel",                    V: -0.15 },
  { id: "ss304-p",   name: "304 stainless (passive)",          V: -0.08 },
  { id: "ss316-p",   name: "316 stainless (passive)",          V: -0.05 },
  { id: "ag",        name: "Silver",                           V: -0.05 },
  { id: "ti",        name: "Titanium",                         V: -0.05 },
  { id: "ss17-4-p",  name: "17-4 PH (passive)",                V: -0.03 },
  { id: "in625",     name: "Inconel 625, Hastelloy",           V:  0.02 },
  { id: "graphite",  name: "Graphite",                         V:  0.25 },
  { id: "au-pt",     name: "Gold, platinum",                   V:  0.30 },
];

function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") node.className = v;
    else if (k === "dataset") for (const [dk, dv] of Object.entries(v)) node.dataset[dk] = dv;
    else if (k === "style") node.style.cssText = v;
    else if (k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (v !== null && v !== undefined && v !== false) node.setAttribute(k, v === true ? "" : v);
  }
  for (const c of children) {
    if (c === null || c === undefined || c === false) continue;
    node.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
  }
  return node;
}

function classifyDelta(mV) {
  if (mV < 50)  return { band: "compatible",  label: "Compatible", advice: "Open-circuit potential difference is small enough that galvanic corrosion is unlikely to be significant in normal service. Standard practice still applies (avoid crevices, manage water ingress)." };
  if (mV < 150) return { band: "monitor",     label: "Monitor",    advice: "Modest potential difference. Acceptable for short-duration or low-conductivity exposures. For continuous wetting in seawater or in conductive electrolytes, isolate the joint with a gasket or insulating sleeve, or oversize the anode for sacrificial loss." };
  if (mV < 300) return { band: "moderate",    label: "Moderate",   advice: "Galvanic corrosion of the anode is expected. Isolate the metals electrically (non-conductive gaskets, sleeves, or coatings), avoid wet exposure, or apply cathodic protection. The anode area should be much larger than the cathode area to spread the corrosion." };
  return         { band: "aggressive",  label: "Aggressive", advice: "Avoid this couple in any wet or marine service. The anode will corrode rapidly. If unavoidable, isolate completely, coat both surfaces, and protect with a third sacrificial anode (zinc, magnesium, or Al-Zn-In)." };
}

function renderChecker() {
  let aId = "steel";
  let bId = "brass";

  const wrap = el("section", { class: "el-checker", "aria-labelledby": "el-checker-title" });
  wrap.appendChild(el("h2", { id: "el-checker-title", class: "el-title" }, "Galvanic couple checker"));
  wrap.appendChild(el("p", { class: "el-sub" },
    "Pick two metals to see the open-circuit potential difference in seawater (vs SCE), which one is the anode, and how aggressive the galvanic action will be. Stainless steels and PH grades are listed in both active and passive states; design against the active value when continuous wetting or chloride exposure is possible."
  ));

  const row = el("div", { class: "el-input-row" });

  const aLabel = el("label", { class: "el-field" });
  aLabel.appendChild(el("span", { class: "el-field-label" }, "Metal A"));
  const aSelect = el("select", { class: "el-select", "aria-label": "Metal A" });
  for (const m of METALS) {
    const opt = el("option", { value: m.id }, `${m.name} (${m.V.toFixed(2)} V)`);
    if (m.id === aId) opt.selected = true;
    aSelect.appendChild(opt);
  }
  aLabel.appendChild(aSelect);
  row.appendChild(aLabel);

  const bLabel = el("label", { class: "el-field" });
  bLabel.appendChild(el("span", { class: "el-field-label" }, "Metal B"));
  const bSelect = el("select", { class: "el-select", "aria-label": "Metal B" });
  for (const m of METALS) {
    const opt = el("option", { value: m.id }, `${m.name} (${m.V.toFixed(2)} V)`);
    if (m.id === bId) opt.selected = true;
    bSelect.appendChild(opt);
  }
  bLabel.appendChild(bSelect);
  row.appendChild(bLabel);

  wrap.appendChild(row);

  const resultHost = el("div", { class: "el-result" });
  wrap.appendChild(resultHost);

  function update() {
    const a = METALS.find(m => m.id === aSelect.value);
    const b = METALS.find(m => m.id === bSelect.value);
    resultHost.innerHTML = "";

    if (!a || !b) return;
    if (a.id === b.id) {
      resultHost.appendChild(el("p", { class: "el-note" }, "Same metal on both sides: no galvanic couple."));
      return;
    }

    const deltaV = Math.abs(a.V - b.V);
    const deltaMv = deltaV * 1000;
    const anode = a.V < b.V ? a : b;   // more active (more negative) = anode
    const cathode = a.V < b.V ? b : a;
    const verdict = classifyDelta(deltaMv);

    // Verdict pill
    const pill = el("div", { class: `el-pill el-pill-${verdict.band}` }, verdict.label);
    resultHost.appendChild(pill);

    // Summary table
    const dl = el("dl", { class: "el-summary" });
    dl.appendChild(el("dt", {}, "Potential difference"));
    dl.appendChild(el("dd", {}, el("strong", {}, `${deltaMv.toFixed(0)} mV`), ` (${deltaV.toFixed(3)} V)`));

    dl.appendChild(el("dt", {}, "Anode (corrodes)"));
    dl.appendChild(el("dd", {}, el("strong", {}, anode.name), ` · ${anode.V.toFixed(2)} V vs SCE`));

    dl.appendChild(el("dt", {}, "Cathode (protected)"));
    dl.appendChild(el("dd", {}, el("strong", {}, cathode.name), ` · ${cathode.V.toFixed(2)} V vs SCE`));

    resultHost.appendChild(dl);

    // Advice
    resultHost.appendChild(el("p", { class: "el-advice" }, verdict.advice));

    // Area ratio reminder
    resultHost.appendChild(el("p", { class: "el-note" },
      "Area ratio matters as much as potential. A small anode against a large cathode corrodes very fast (concentrated current); a small cathode on a large anode corrodes slowly. Keep cathode area smaller than anode area when the couple is unavoidable."
    ));
  }

  aSelect.addEventListener("change", () => { update(); });
  bSelect.addEventListener("change", () => { update(); });

  update();
  return wrap;
}

export async function render(root, ctx) {
  root.innerHTML = "";
  root.appendChild(el("a", { class: "detail-back-link", href: "#/" }, "← bench"));
  root.appendChild(el("p", { class: "section-eyebrow", style: "margin-top:1rem;" }, "Chemistry"));
  root.appendChild(el("h1", { class: "section-title" }, "ELECTRO"));
  root.appendChild(el("p", { class: "section-lede" },
    "Galvanic couple checker for materials selection, plus the standard reduction potential and galvanic series tables, sacrificial anode notes, and the bath chemistries for the common plating and anodizing processes."
  ));

  root.appendChild(renderChecker());

  const entries = await loadEntriesForModule("electro");
  if (entries.length === 0) return;

  root.appendChild(el("h2", { class: "section-eyebrow", style: "margin-top:2.5rem;" }, "Reference cards"));
  const grid = el("div", { class: "card-grid" });
  for (const entry of entries) {
    const front = renderFront(entry);
    const link = el("a", { href: `#/card/${encodeURIComponent(entry.id)}`, style: "text-decoration:none;color:inherit;" });
    link.appendChild(front);
    grid.appendChild(link);
  }
  root.appendChild(grid);
}
