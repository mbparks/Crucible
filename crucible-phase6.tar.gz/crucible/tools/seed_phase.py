#!/usr/bin/env python3
"""
CRUCIBLE phase-diagram seeder.

Generates modules/phase/data/<slug>.json: reference cards for the lever rule,
Gibbs phase rule, eutectic/eutectoid/peritectic transformations, and three
companion binary diagrams (Cu-Zn brasses, Al-Si castings, Pb-Sn solders).

The main attraction in this module is the interactive Fe-C diagram living in
modules/phase/module.js, which renders the diagram and computes lever-rule
fractions at any (composition, temperature) point.

Sources: ASM Vol. 3 (Alloy Phase Diagrams), Reed-Hill (Physical Metallurgy
Principles), Massalski (Binary Alloy Phase Diagrams).
"""

import json
import sys
import argparse
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "modules" / "phase" / "data"
MANIFEST = ROOT / "shared" / "data" / "manifest.json"


def _stat(key, label, value, unit, source="asm-v3"):
    return {"key": key, "label": label, "value": value, "unit": unit, "source": source}


ENTRIES = [
    {
        "slug": "lever-rule", "title": "Lever rule",
        "symbol": "f = Δ/L",
        "kind": "reference",
        "subtitle": "Mass-balance calculation of phase fractions in any two-phase region",
        "stats": [
            _stat("formulaAlpha", "Mass fraction α", "(C_β − C₀) / (C_β − C_α)", ""),
            _stat("formulaBeta", "Mass fraction β", "(C₀ − C_α) / (C_β − C_α)", ""),
            _stat("constraint", "Constraint", "f_α + f_β = 1.000", ""),
            _stat("applies", "Applies in", "any two-phase region · pulled to phase boundaries by tie line", ""),
            _stat("workedAlpha", "Example: 0.4% C at 800 °C in α+γ", "≈ 13 % α", "(C_α ≈ 0.02, C_γ ≈ 0.46)"),
            _stat("workedGamma", "Example: 0.4% C at 800 °C in α+γ", "≈ 87 % γ", ""),
        ],
        "tags": ["lever rule", "tie line", "phase fraction", "metallurgy", "reference"],
        "body": "**The lever rule is mass balance on a tie line.** In a two-phase region at temperature T, the two phases each have a fixed composition (read off the phase boundaries at temperature T, where the horizontal tie line crosses them). The overall composition C₀ must equal the weighted average of those two compositions, weighted by mass fraction.\n\n**Setup**: Let C_α and C_β be the boundary compositions of phases α and β at temperature T; let C₀ be the overall alloy composition. The tie line is the horizontal segment at T from (C_α, T) to (C_β, T); C₀ sits somewhere on that line.\n\n**The fraction of each phase is the *opposite-side* lever arm divided by total length:**\n- f_α = (C_β − C₀) / (C_β − C_α)\n- f_β = (C₀ − C_α) / (C_β − C_α)\n\n**Mnemonic**: the fraction of a phase is proportional to its distance from the *other* phase's boundary. If C₀ is close to the C_α boundary, there's mostly α (and very little β); the lever arm reaching back to C_β is long.\n\n**Worked example**: hypoeutectoid steel at 0.40 % C, 800 °C, in the α + γ region. At T = 800 °C, the α-(α+γ) boundary is essentially 0 %, and the γ-(α+γ) boundary (the A3 line) is at C_γ ≈ 0.46 %. So:\n- f_α = (0.46 − 0.40) / (0.46 − 0.02) ≈ 0.14\n- f_γ = (0.40 − 0.02) / (0.46 − 0.02) ≈ 0.86\n\nIn this state the steel is about 14 % ferrite by mass, 86 % austenite. The PHASE interactive Fe-C tool computes these fractions automatically for any (C, T) point you click.",
        "related": ["alloy:aisi-1018", "alloy:aisi-1045", "temper:1045-hardening"],
        "sources": ["asm-v3"],
    },
    {
        "slug": "gibbs-phase-rule", "title": "Gibbs phase rule",
        "symbol": "F = C − P + 2",
        "kind": "reference",
        "subtitle": "Degrees of freedom in a thermodynamic system · why phase diagrams look the way they do",
        "stats": [
            _stat("formula", "Phase rule", "F = C − P + 2", "(C components, P phases, F degrees of freedom)"),
            _stat("formulaCondensed", "Condensed-system form", "F = C − P + 1", "(pressure fixed, e.g., atmospheric)"),
            _stat("threePhaseLine", "Three-phase invariant", "F = 0", "(eutectic, eutectoid, peritectic horizontal lines)"),
            _stat("twoPhaseRegion", "Two-phase region", "F = 1", "(temperature alone fixes compositions)"),
            _stat("singlePhase", "Single phase region", "F = 2", "(both T and C can vary independently)"),
        ],
        "tags": ["Gibbs phase rule", "thermodynamics", "degrees of freedom", "reference"],
        "body": "**Why phase diagrams look the way they do.** For a system in thermodynamic equilibrium, the number of independent variables that can be changed without leaving the current set of phases is F = C − P + 2, where C is the number of components (independent chemical species) and P is the number of phases coexisting.\n\nFor binary alloy systems at fixed atmospheric pressure, the rule becomes F = C − P + 1 (the '+1' counts only temperature since pressure is fixed at 1 atm). With C = 2:\n\n**One phase present (F = 2)**: temperature and composition can both vary independently. Single-phase regions are 2D areas on the diagram.\n\n**Two phases present (F = 1)**: only temperature can vary; phase compositions then follow the phase boundaries. Two-phase regions are 2D on the diagram (a range of overall compositions can produce the two phases at any given T), but for any specific T the phase compositions are fixed.\n\n**Three phases present (F = 0)**: nothing varies; it's invariant. This produces the horizontal lines on phase diagrams: the eutectic line, eutectoid line, peritectic line. At those exact temperatures, with three phases coexisting, you have no freedom to change anything without forcing a phase to disappear.\n\n**Practical takeaway for steels**: the eutectoid (727 °C in Fe-Fe₃C) is an invariant point. Above it, you can have γ alone; just below it (and to the right of the eutectoid composition), you have α + Fe₃C; the transformation at 727 °C is the simultaneous formation of those two phases from γ. That's why pearlite has alternating ferrite-cementite lamellae instead of a smooth gradient.",
        "related": ["phase:lever-rule"],
        "sources": ["asm-v3"],
    },
    {
        "slug": "eutectic-eutectoid", "title": "Eutectic, eutectoid, peritectic",
        "symbol": "L → α + β",
        "kind": "reference",
        "subtitle": "The four common invariant three-phase transformations",
        "stats": [
            _stat("eutectic", "Eutectic", "L → α + β on cooling", "(liquid to two solids)"),
            _stat("eutecticSig", "Eutectic significance", "lowest-melting composition in the system", ""),
            _stat("eutectoid", "Eutectoid", "γ → α + β on cooling", "(one solid to two solids)"),
            _stat("eutectoidSig", "Eutectoid significance", "Fe-C 0.76% C at 727 °C → pearlite", ""),
            _stat("peritectic", "Peritectic", "L + α → β on cooling", "(liquid + solid produce different solid)"),
            _stat("peritecticSig", "Peritectic significance", "Fe-C 0.16% C at 1495 °C · slow, often incomplete in real cooling", ""),
            _stat("monotectic", "Monotectic", "L₁ → L₂ + α on cooling", "(two-liquid systems, e.g., Cu-Pb)"),
        ],
        "tags": ["eutectic", "eutectoid", "peritectic", "monotectic", "invariant", "reference"],
        "body": "**Eutectic** is the most familiar: a single liquid composition that solidifies to two distinct solid phases at one temperature. The 63 Sn / 37 Pb solder eutectic at 183 °C is the prototypical example: a single-temperature freeze with no plastic range. The eutectic structure is alternating lamellae or rods of the two product solids.\n\n**Eutectoid** is the eutectic's solid-state analog: a single solid phase decomposes into two other solid phases at one temperature. **The Fe-C eutectoid at 0.76 % C, 727 °C, producing pearlite (alternating ferrite and cementite lamellae) is the central transformation of heat-treated steel.** Above the eutectoid, austenite (γ) exists as a single FCC phase that dissolves significant carbon; on slow cooling through 727 °C, γ decomposes into α (BCC, very low C) plus Fe₃C (cementite, 6.67 % C). Rapid cooling diverts the transformation toward bainite, martensite, or retained austenite (covered in TEMPER).\n\n**Peritectic** is the trickier one: a liquid reacts with one solid phase to produce a different solid. In iron-carbon, the peritectic at 0.16 % C, 1495 °C means liquid + δ-ferrite → γ-austenite. Peritectic reactions are diffusion-limited and slow; in real cooling, they typically leave residual δ-ferrite trapped inside the new γ grains, giving as-cast inhomogeneity that must be homogenized at elevated temperature before forging or rolling.\n\n**Monotectic** appears in immiscible systems (Cu-Pb, Cu-Fe at certain compositions) where liquid splits into two liquids: a high-density Pb-rich liquid and a low-density Cu-rich liquid, with one of them solidifying. Used commercially in **leaded bearing brasses** (where Pb-rich droplets dispersed through the Cu-Zn matrix provide self-lubrication).",
        "related": ["phase:lever-rule", "solder:sn63-pb37", "alloy:aisi-1045"],
        "sources": ["asm-v3"],
    },
    {
        "slug": "cu-zn-brass", "title": "Cu-Zn (brass) binary diagram",
        "symbol": "Cu-Zn",
        "kind": "binary-diagram",
        "subtitle": "Copper-zinc system · alpha brass, alpha-beta brass, beta brass · cartridge brass to Muntz metal",
        "stats": [
            _stat("alphaBrassRange", "α brass", "0 to 36 % Zn · FCC · ductile · cold-formed", ""),
            _stat("alphaBrassClassic", "Cartridge brass (C260)", "30 % Zn · ASTM B16", ""),
            _stat("alphaBetaRange", "α + β brass", "36 to 46 % Zn · two-phase · hot-worked", ""),
            _stat("betaBrassRange", "β brass", "46 to 50 % Zn · BCC · ordered β' below 470 °C", ""),
            _stat("muntzMetal", "Muntz metal (C280)", "40 % Zn · hot-rolled sheet · marine", ""),
            _stat("alphaBetaC360", "Free-cutting brass (C360)", "35 % Zn + 3 % Pb · α + β + Pb droplets", ""),
            _stat("solidusCu", "Cu side liquidus", "1084.6 °C at 0 % Zn", ""),
            _stat("eutectoidNote", "No simple eutectic", "(complex β-γ-ε-η peritectic cascade beyond 50 % Zn)", ""),
        ],
        "tags": ["binary diagram", "Cu-Zn", "brass", "α-brass", "α-β brass"],
        "body": "The copper-zinc system underlies all commercial brasses. The diagram has a wide α (FCC) field from pure Cu out to about 36 % Zn at room temperature, an α+β two-phase field from 36 to about 46 %, a small β (BCC ordered) field, and several intermetallic compounds (γ, ε, η) at higher Zn contents that are not commercially exploited.\n\n**α brasses (0 to 36 % Zn)** are single-phase, FCC, and behave like dilute Cu: ductile, weldable, deep-drawable. Cartridge brass (C260) at 30 % Zn is the prototype for cold-formed cups, cartridge cases, electrical fittings.\n\n**α+β brasses (36 to 46 % Zn)** include free-machining (C360, with lead inclusions for chip breaking) and high-strength architectural and marine brasses (Muntz metal C280 at 40 % Zn, naval brass C464 with added Sn). The β phase is harder and gives higher strength; the two-phase mixture is hot-worked rather than cold-formed.\n\n**Dezincification** is a corrosion mode specific to α+β brasses: Zn leaches out preferentially in saltwater or aggressive water (chloride, low pH), leaving a porous copper-rich residue. Marine and plumbing brasses are alloyed with arsenic or tin to inhibit dezincification.\n\nFor the visual diagram, search 'Cu-Zn phase diagram' or consult ASM Vol. 3, p. 2-176.",
        "related": ["alloy:cu-c260", "alloy:cu-c360", "element:cu", "element:zn"],
        "sources": ["asm-v3"],
    },
    {
        "slug": "al-si-casting", "title": "Al-Si (aluminum casting) binary diagram",
        "symbol": "Al-Si",
        "kind": "binary-diagram",
        "subtitle": "Aluminum-silicon system · eutectic at 12.6 % Si · cast 356, 357, A380, 413",
        "stats": [
            _stat("eutectic", "Eutectic point", "12.6 % Si at 577 °C", ""),
            _stat("hypoeutectic", "Hypoeutectic alloys", "< 12.6 % Si · 356 (7 % Si), A380 (8 % Si)", ""),
            _stat("eutecticAlloys", "Near-eutectic alloys", "12 to 13 % Si · 413 · die casting workhorse", ""),
            _stat("hypereutectic", "Hypereutectic", "> 12.6 % Si · 390 (17 % Si) · wear surfaces", ""),
            _stat("modification", "Sr or Na modification", "refines eutectic Si from flakes to fibers", ""),
            _stat("primaryAlpha", "Hypoeutectic structure", "primary α-Al dendrites + (α + Si) eutectic", ""),
            _stat("primarySi", "Hypereutectic structure", "primary Si polygons in (α + Si) eutectic", ""),
        ],
        "tags": ["binary diagram", "Al-Si", "casting", "356", "die casting", "modification"],
        "body": "The aluminum-silicon system dominates commercial Al casting alloys because the **eutectic temperature (577 °C) is low** (easy melting and casting) and the **eutectic structure** (α-Al matrix with embedded Si) gives a good combination of strength, wear resistance, and corrosion resistance.\n\n**Hypoeutectic** (< 12.6 % Si): the most common cast alloys. Solidifies with primary α-Al dendrites that grow first, then the remaining liquid (now enriched to ~12.6 % Si) solidifies as the eutectic. **356 (Al-7Si-0.3Mg)** is the workhorse: castable, weldable, can be heat-treated (T6 condition) for good strength. Used for wheels, cylinder heads, structural castings.\n\n**Near-eutectic** (12 to 13 % Si): **413** alloy is the die-casting standard, with minimum shrinkage on solidification (because there is no extensive two-phase freezing range) and excellent flow into thin sections.\n\n**Hypereutectic** (> 12.6 % Si): primary silicon crystallizes first as polygonal blocks, surrounded by the eutectic matrix. **390 (17 % Si)** is used in unlined aluminum engine blocks; the hard Si particles provide a wear surface that doesn't need a separate steel cylinder liner.\n\n**Modification with Sr (~0.02 %) or Na (~0.005 %)**: changes the eutectic Si morphology from coarse plate-like flakes (which act as crack-initiation sites) to fine fibers or spheroids. **Modified 356 has roughly 50 % higher elongation** than unmodified for the same composition. This is one of the most important commercial casting practices.\n\nFor the visual diagram, consult ASM Vol. 3, p. 2-43.",
        "related": ["alloy:al-6061", "element:al", "element:si"],
        "sources": ["asm-v3"],
    },
    {
        "slug": "pb-sn-solder", "title": "Pb-Sn (solder) binary diagram",
        "symbol": "Pb-Sn",
        "kind": "binary-diagram",
        "subtitle": "Lead-tin system · eutectic at 63 Sn / 37 Pb, 183 °C · the canonical solder diagram",
        "stats": [
            _stat("eutectic", "Eutectic", "63 % Sn at 183 °C", ""),
            _stat("eutecticAlloy", "Sn63 / Pb37", "eutectic electronics solder · no plastic range", ""),
            _stat("sn60pb40", "Sn60 / Pb40 (common 60/40)", "183 to 191 °C · 8 °C plastic range", ""),
            _stat("sn50pb50", "Sn50 / Pb50 (plumbing)", "183 to 216 °C · 33 °C plastic range", ""),
            _stat("alphaPbSolubility", "Sn in Pb at 183 °C", "19.5 %", ""),
            _stat("betaSnSolubility", "Pb in Sn at 183 °C", "2.5 %", ""),
            _stat("rohsImpact", "RoHS impact", "phased out for electronics in EU since 2006", ""),
        ],
        "tags": ["binary diagram", "Pb-Sn", "solder", "eutectic", "electronics"],
        "body": "The textbook eutectic diagram and the basis of all conventional tin-lead solders. **Eutectic composition 63 % Sn / 37 % Pb melts at 183 °C** with no plastic range; the liquid freezes to a fine lamellar (Pb-rich α) + (Sn-rich β) eutectic structure in a single thermal event.\n\n**Off-eutectic solders** have a plastic range (temperature range where solid and liquid coexist). **Sn60Pb40** (common 60/40 hand-soldering rosin-core wire) freezes from 191 °C down to 183 °C, an 8 °C plastic range that lets the joint hold its shape briefly during cooling. **Sn50Pb50 plumbing solder** has a much wider range (216 down to 183 °C) which is required for sweeping copper pipe joints, where the solder must be pasty long enough to be wiped into the fitting.\n\n**RoHS** (Restriction of Hazardous Substances, EU 2003/2006) phased out lead-containing solders for new consumer electronics in 2006. **SAC305 (96.5 Sn / 3.0 Ag / 0.5 Cu)** replaced Sn63Pb37 in most applications, with a higher melting point (217 °C peak) that drove reflow oven temperatures up by about 30 °C and forced redesigns of many electronic-component packages.\n\n**Reading the diagram** for a Sn50Pb50 alloy cooling from molten:\n- Above 216 °C: all liquid\n- 216 to 183 °C: liquid plus primary β (Sn-rich) crystals; lever rule gives the ratio at each T\n- 183 °C: remaining liquid (at the eutectic composition 63 Sn) freezes as a eutectic mixture; primary β is now suspended in the eutectic matrix\n- Below 183 °C: solid (α + β) with the primary β still distinguishable as larger grains\n\nFor the visual diagram, consult ASM Vol. 3, p. 2-318.",
        "related": ["solder:sn63-pb37", "solder:sn60-pb40", "solder:sac305", "element:pb", "element:sn"],
        "sources": ["asm-v3"],
    },
    {
        "slug": "fe-c-key", "title": "Fe-C diagram interactive key",
        "symbol": "Fe-Fe₃C",
        "kind": "reference",
        "subtitle": "Phase regions and critical lines of the Fe-Fe₃C metastable diagram",
        "stats": [
            _stat("liquidus", "Liquidus", "1538 °C at 0 % C · 1148 °C eutectic at 4.30 % C", ""),
            _stat("eutectic", "Eutectic", "L → γ + Fe₃C at 4.30 % C, 1148 °C", "(ledeburite)"),
            _stat("eutectoid", "Eutectoid (A1)", "γ → α + Fe₃C at 0.76 % C, 727 °C", "(pearlite)"),
            _stat("peritectic", "Peritectic", "L + δ → γ at 0.16 % C, 1495 °C", ""),
            _stat("a3Line", "A3 line", "912 °C at 0 % C down to 727 °C at 0.76 % C", "(γ → α + γ)"),
            _stat("acmLine", "Acm line", "727 °C at 0.76 % C up to 1148 °C at 2.14 % C", "(γ → γ + Fe₃C)"),
            _stat("alphaMax", "α max solubility", "0.022 % C at 727 °C", ""),
            _stat("gammaMax", "γ max solubility", "2.14 % C at 1148 °C", ""),
            _stat("fe3c", "Cementite Fe₃C", "6.67 % C · hard intermetallic · decomposes to graphite very slowly", ""),
        ],
        "tags": ["Fe-C", "phase diagram", "key", "eutectoid", "eutectic", "pearlite"],
        "body": "Companion reference for the interactive Fe-C diagram at the top of the PHASE module. The 'Fe-Fe₃C' system is metastable: thermodynamically, the most stable form of carbon-in-iron at low temperature is **graphite**, not cementite. In practice, the Fe-Fe₃C transformation is so much faster than Fe-graphite at engineering cooling rates that we use the metastable diagram for steel work. Gray cast irons (with their flake graphite) are made by holding melts long enough at high temperature to nucleate stable graphite; carbide-bearing cast irons (white iron) skip the graphite phase and freeze into a Fe-Fe₃C structure.\n\n**Phase regions of interest:**\n- **α (alpha-ferrite)**: BCC, dissolves at most 0.022 % C at 727 °C, nearly zero at room temp. Soft, magnetic, ductile.\n- **γ (gamma-austenite)**: FCC, dissolves up to 2.14 % C at 1148 °C. Soft, non-magnetic, the parent phase for all hardening.\n- **δ (delta-ferrite)**: BCC, exists only above 1394 °C. Dissolves up to 0.10 % C at the peritectic. Important in welding (high-Cr stainless welds rely on retained δ for solidification cracking resistance).\n- **Fe₃C (cementite)**: orthorhombic intermetallic, 6.67 % C, hard (about 800 HV), brittle. The carbide in pearlite, in tempered steels, and the dispersed phase in cast irons.\n\n**Critical lines**:\n- **A1** (727 °C horizontal): eutectoid line. Cooling through it from γ-region produces pearlite.\n- **A3** (slope from 912 °C at 0 % C to 727 °C at 0.76 % C): γ-to-α transformation start on cooling for hypoeutectoid steels.\n- **Acm** (slope from 727 °C to 1148 °C, from 0.76 % to 2.14 % C): cementite-precipitation start on cooling for hypereutectoid steels.\n- **Liquidus** and **solidus**: the upper boundaries of the two-phase L+γ region.\n\nThe interactive tool at the top of PHASE lets you click anywhere on the diagram or enter (C, T) to see which region you're in and the lever-rule fractions where applicable.",
        "related": ["phase:lever-rule", "phase:gibbs-phase-rule", "phase:eutectic-eutectoid", "alloy:aisi-1018", "alloy:aisi-1045", "alloy:aisi-1095"],
        "sources": ["asm-v3"],
    },
]


def build_entry(spec):
    return {
        "id": f"phase:{spec['slug']}",
        "module": "phase",
        "kind": spec.get("kind", "reference"),
        "title": spec["title"],
        "symbol": spec.get("symbol", ""),
        "subtitle": spec.get("subtitle", ""),
        "tags": spec.get("tags", []),
        "stats": spec.get("stats", []),
        "body": spec.get("body", ""),
        "hazards": spec.get("hazards", []),
        "related": spec.get("related", []),
        "sources": spec.get("sources", ["asm-v3"]),
    }


def write_manifest_entries():
    manifest = json.loads(MANIFEST.read_text())
    slugs = [s["slug"] for s in ENTRIES]
    for m in manifest["modules"]:
        if m["slug"] == "phase":
            m["entries"] = slugs
            m["status"] = "active"
            m["customView"] = True
            break
    MANIFEST.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    print(f"Manifest updated: phase declares {len(slugs)} entries, customView=true.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    written = 0
    for spec in ENTRIES:
        entry = build_entry(spec)
        path = DATA_DIR / f"{spec['slug']}.json"
        text = json.dumps(entry, indent=2, ensure_ascii=False) + "\n"
        if args.dry_run:
            print(f"  {'~' if path.exists() else '+'} {path.relative_to(ROOT)}")
        else:
            path.write_text(text)
        written += 1
    print(f"\nSeeded {written} phase files.")
    if not args.dry_run:
        write_manifest_entries()
    return 0


if __name__ == "__main__":
    sys.exit(main())
