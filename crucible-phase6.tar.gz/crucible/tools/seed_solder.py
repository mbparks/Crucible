#!/usr/bin/env python3
"""
CRUCIBLE solder seeder.

Generates modules/solder/data/<slug>.json across electronics solders,
plumbing solders, silver brazing alloys, phos-copper brazes, and a small
selection of specialty alloys.

Data follows ASTM B32 (tin-lead and lead-free solders), AWS A5.8 (brazing
filler metals), and standard manufacturer data sheets.

Usage:
    python3 tools/seed_solder.py
"""

import json
import sys
import argparse
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "modules" / "solder" / "data"
MANIFEST = ROOT / "shared" / "data" / "manifest.json"


CATEGORY_TAGS = {
    "electronics-leaded":   ["electronics", "Sn-Pb", "low temperature"],
    "electronics-lead-free": ["electronics", "lead-free", "RoHS"],
    "plumbing":             ["plumbing", "potable water"],
    "silver-braze":         ["brazing", "silver braze", "high strength"],
    "phos-copper-braze":    ["brazing", "phos-copper", "self-fluxing on copper"],
    "specialty":            ["specialty"],
    "jewelry":              ["jewelry", "precious metal"],
}


def _stat(key, label, value, unit, source="astm-b32"):
    return {"key": key, "label": label, "value": value, "unit": unit, "source": source}


def stats_from(spec):
    out = []
    src = spec.get("comp_source", "astm-b32")
    for elem, val in spec.get("comp", []):
        out.append({"key": f"comp_{elem.lower()}", "label": elem, "value": val, "unit": "%", "source": src})
    if "solidus" in spec:
        out.append(_stat("solidus", "Solidus", spec["solidus"], "°C"))
    if "liquidus" in spec:
        out.append(_stat("liquidus", "Liquidus", spec["liquidus"], "°C"))
        rng = spec["liquidus"] - spec["solidus"]
        out.append(_stat("plasticRange", "Plastic range", rng, "°C"))
    return out


SOLDERS = [
    # ============ Electronics, leaded ============
    {
        "slug": "sn63-pb37", "title": "Sn63/Pb37", "symbol": "Sn63",
        "category": "electronics-leaded",
        "subtitle": "Tin-lead eutectic solder · ASTM B32 Sn63 · 183 °C",
        "comp": [("Sn", "62.5-63.5"), ("Pb", "36.5-37.5")],
        "solidus": 183, "liquidus": 183,
        "tags": ["eutectic", "no plastic range", "hand soldering", "rework"],
        "body": "The textbook eutectic. Solidifies at a single temperature with no plastic (slushy) range, so the joint sets cleanly as it cools rather than passing through a phase where slight mechanical movement causes cold solder joints.\n\n**Use cases**: hand-soldering, rework, where joint quality matters more than mechanical strength. Most pre-RoHS electronics ran Sn63 or Sn60. Many aerospace, medical, and military programs still use Sn63 by exception because the lead-free alternatives have problems (tin whiskers, higher reflow temperatures) that the exception programs cannot accept.\n\n**Flux**: rosin-based (RMA, RA) for through-hole and rework; no-clean low-residue flux for high-mix prototyping.",
        "related": ["element:sn", "element:pb"],
        "sources": ["astm-e407"],
    },
    {
        "slug": "sn60-pb40", "title": "Sn60/Pb40", "symbol": "Sn60",
        "category": "electronics-leaded",
        "subtitle": "Tin-lead near-eutectic · ASTM B32 Sn60 · 183-190 °C",
        "comp": [("Sn", "59.5-61.5"), ("Pb", "38.5-40.5")],
        "solidus": 183, "liquidus": 190,
        "tags": ["near-eutectic", "general purpose", "tinning", "older boards"],
        "body": "Slightly less expensive than Sn63 and historically the most common 'general-purpose' electronics solder. Has a 7 °C plastic range, which marginally helps when bridging gaps but slightly hurts joint quality on small fine-pitch work. Largely interchangeable with Sn63 in practice for hand soldering."
    },

    # ============ Electronics, lead-free ============
    {
        "slug": "sac305", "title": "SAC305", "symbol": "SAC305",
        "category": "electronics-lead-free",
        "subtitle": "Sn-Ag-Cu lead-free electronics solder · IPC J-STD-006",
        "comp": [("Sn", "96.5"), ("Ag", "3.0"), ("Cu", "0.5")],
        "solidus": 217, "liquidus": 220,
        "tags": ["SAC", "RoHS", "reflow", "wave"],
        "body": "The de facto lead-free electronics solder since the 2006 RoHS transition. Higher melting point than Sn-Pb (217 versus 183 °C) drove up reflow oven temperatures, board substrate temperature ratings (TG required higher), and stresses on components.\n\n**Tin whiskers** are the major reliability concern: pure-tin surfaces grow thin metallic filaments over time that can short adjacent traces. Silver and copper do not fully suppress whiskering. Conformal coating, post-plate baking, or annealing reduce risk; the aerospace and medical exceptions to lead-free are because no fully whisker-free lead-free system has been qualified.",
        "related": ["element:sn", "element:ag", "element:cu"],
        "sources": ["astm-e407"],
    },
    {
        "slug": "sn99-cu", "title": "Sn99.3/Cu0.7", "symbol": "Sn-Cu",
        "category": "electronics-lead-free",
        "subtitle": "Lead-free wave solder · ASTM B32 Sn99CuA",
        "comp": [("Sn", "99.3"), ("Cu", "0.7")],
        "solidus": 227, "liquidus": 227,
        "tags": ["wave solder", "low cost", "no silver", "tin whisker prone"],
        "body": "The cheapest lead-free solder by far (no silver). Used in cost-sensitive wave-solder production. Joints are visually duller and more grain-coarse than SAC305 and somewhat less ductile, but mechanically adequate for consumer products. Whisker risk is similar to SAC."
    },
    {
        "slug": "sn-ag", "title": "Sn96.5/Ag3.5", "symbol": "Sn-Ag",
        "category": "electronics-lead-free",
        "subtitle": "Tin-silver eutectic · ASTM B32 Sn96 · 221 °C",
        "comp": [("Sn", "96.5"), ("Ag", "3.5")],
        "solidus": 221, "liquidus": 221,
        "tags": ["lead-free", "eutectic", "low temp electronics", "plumbing potable"],
        "body": "Eutectic, slightly lower melting than SAC305, and approved for potable water plumbing in lead-free plumbing codes. Used in some low-mass electronics where the silver content improves wettability over Sn-Cu. Common in solder paste used for SMT rework."
    },
    {
        "slug": "sn-bi", "title": "Sn42/Bi58", "symbol": "Sn-Bi",
        "category": "electronics-lead-free",
        "subtitle": "Low-temperature lead-free solder · 138 °C eutectic",
        "comp": [("Sn", "42"), ("Bi", "58")],
        "solidus": 138, "liquidus": 138,
        "tags": ["low temperature", "step solder", "BGA rework"],
        "body": "Eutectic at 138 °C, well below standard Sn-Pb. Used where heat-sensitive components cannot tolerate full reflow (some LEDs, certain MEMS devices), and increasingly as the second-step solder in mixed-temperature SMT assemblies (high-temp components first, low-temp components afterward without disturbing the first set).\n\n**Joints are brittle** compared to Sn-Ag-Cu; mechanical robustness is poor. Not a general-purpose substitute for SAC305."
    },

    # ============ Plumbing ============
    {
        "slug": "sn95-sb5", "title": "Sn95/Sb5", "symbol": "Sn95",
        "category": "plumbing",
        "subtitle": "Lead-free plumbing solder · ASTM B32 Sn95 · potable water",
        "comp": [("Sn", "95"), ("Sb", "5")],
        "solidus": 235, "liquidus": 240,
        "tags": ["plumbing", "potable water", "lead-free", "copper to copper"],
        "body": "Historical lead-free plumbing solder, the post-1986 transition replacement for 50/50 Sn-Pb in US potable water plumbing. The 5% antimony raises the working temperature and gives mechanical strength comparable to leaded plumbing solders.\n\n**Flux**: zinc-chloride based, acid-cored. Wipe joints fully after solidification to prevent corrosion of the assembled fitting.",
        "related": ["element:sn", "element:sb"],
        "sources": ["astm-e407"],
    },

    # ============ Silver brazing ============
    {
        "slug": "bag-1", "title": "BAg-1 (45% silver)", "symbol": "BAg-1",
        "category": "silver-braze",
        "subtitle": "Cadmium-bearing silver braze · AWS A5.8 BAg-1 · 605-620 °C",
        "comp": [("Ag", "45"), ("Cu", "15"), ("Zn", "16"), ("Cd", "24")],
        "solidus": 605, "liquidus": 620,
        "tags": ["silver braze", "lowest melting", "cadmium", "narrow range"],
        "body": "The lowest-melting common silver braze. The cadmium addition was historically the universal choice for tight-clearance brazing and where minimum thermal stress matters.\n\n**Cadmium is highly toxic**, both as vapor at brazing temperature and as a chronic hazard in finished joints in potable-water service. Most jurisdictions and most production specifications now require cadmium-free brazes (BAg-7, BAg-24).",
        "hazards": ["cadmium vapor", "carcinogen"],
        "related": ["element:ag", "solder:bag-7"],
        "sources": ["astm-e407"],
    },
    {
        "slug": "bag-7", "title": "BAg-7 (56% silver)", "symbol": "BAg-7",
        "category": "silver-braze",
        "subtitle": "Cadmium-free silver braze · AWS A5.8 BAg-7 · 618-651 °C",
        "comp": [("Ag", "56"), ("Cu", "22"), ("Zn", "17"), ("Sn", "5")],
        "solidus": 618, "liquidus": 651,
        "tags": ["silver braze", "cadmium-free", "general purpose", "food contact"],
        "body": "The volume-grade general-purpose cadmium-free silver braze. Approved for food and beverage contact, potable water plumbing, refrigeration brazing, and most industrial joining of copper, brass, bronze, steel, and stainless. The tin replaces cadmium as a melting-range depressant and gives the braze its slightly milky finish color (versus the bright silver of cadmium-bearing alloys).\n\n**Flux**: AWS Type FB3-A or FB3-C (fluoride-bearing) for general use, FB3-D (high-temperature) for joints kept above 540 °C during process. Avoid silver brazing fluxes containing fluorides on aluminum or magnesium parts (they will attack them).",
        "related": ["element:ag", "element:cu", "element:zn", "element:sn", "solder:bag-1"],
        "sources": ["astm-e407"],
    },
    {
        "slug": "bag-24", "title": "BAg-24 (50% silver)", "symbol": "BAg-24",
        "category": "silver-braze",
        "subtitle": "Cadmium-free silver braze for thin sections · AWS A5.8 · 660-707 °C",
        "comp": [("Ag", "50"), ("Cu", "20"), ("Zn", "28"), ("Ni", "2")],
        "solidus": 660, "liquidus": 707,
        "tags": ["silver braze", "cadmium-free", "stainless", "wider range"],
        "body": "Higher-melting cadmium-free silver braze. The nickel addition improves wetting on stainless steel and tungsten carbide, which is why BAg-24 dominates carbide-tipped tool brazing (saw blade teeth, lathe tool tips). Wider plastic range makes it more forgiving for gap-filling on imperfect joints."
    },

    # ============ Phos-copper brazing ============
    {
        "slug": "bcup-2", "title": "BCuP-2 (phos-copper)", "symbol": "BCuP-2",
        "category": "phos-copper-braze",
        "subtitle": "Self-fluxing copper braze · AWS A5.8 BCuP-2 · 710-795 °C",
        "comp": [("Cu", "92.75"), ("P", "7.25")],
        "solidus": 710, "liquidus": 795,
        "tags": ["phos-copper", "no flux needed copper-copper", "refrigeration", "plumbing"],
        "body": "**Self-fluxing on copper-to-copper joints.** The phosphorus acts as a reducer of any copper oxide and produces a clean joint without external flux. This is the dominant brazing alloy for refrigeration plumbing (copper-to-copper-to-copper, all sealed and pressure-tested).\n\n**Not for use on ferrous metals** (steel, stainless): the phosphorus produces brittle iron phosphides at the joint that crack under any stress. For copper-to-brass joints, external flux is still required.",
        "related": ["element:cu", "element:p", "solder:bcup-5"],
        "sources": ["astm-e407"],
    },
    {
        "slug": "bcup-5", "title": "BCuP-5 (silver phos-copper)", "symbol": "BCuP-5",
        "category": "phos-copper-braze",
        "subtitle": "Silver-bearing phos-copper · AWS A5.8 BCuP-5 · 645-815 °C",
        "comp": [("Cu", "80"), ("Ag", "15"), ("P", "5")],
        "solidus": 645, "liquidus": 815,
        "tags": ["phos-copper", "silver", "wider gap", "plumbing"],
        "body": "The widest melting range of any common braze (170 °C plastic range). The silver lowers the solidus and gives a much more forgiving fillet on imperfect gaps. Plumbing and refrigeration brazing where the joint geometry is variable. Self-fluxing on copper, like all BCuP alloys."
    },

    # ============ Specialty ============
    {
        "slug": "au80-sn20", "title": "Au80/Sn20", "symbol": "Au-Sn",
        "category": "specialty",
        "subtitle": "Gold-tin die-attach solder · 280 °C eutectic",
        "comp": [("Au", "80"), ("Sn", "20")],
        "solidus": 280, "liquidus": 280,
        "tags": ["semiconductor", "die attach", "hermetic", "no flux"],
        "body": "Eutectic at 280 °C. The semiconductor industry standard for hermetic die-attach in laser diode packages, microwave devices, and military-grade hybrid circuits. No flux is needed; the gold matrix prevents oxidation of the joint during reflow. Joint is mechanically very hard and stiff (not for thermal-cycling-sensitive structures)."
    },
    {
        "slug": "bni-2", "title": "BNi-2 (nickel braze)", "symbol": "BNi-2",
        "category": "specialty",
        "subtitle": "Nickel-chromium braze · AWS A5.8 BNi-2 · 970-1000 °C",
        "comp": [("Ni", "82"), ("Cr", "7"), ("B", "3"), ("Si", "4.5"), ("Fe", "3")],
        "solidus": 970, "liquidus": 1000,
        "tags": ["nickel braze", "stainless", "honeycomb", "vacuum braze"],
        "body": "The volume-grade vacuum-furnace braze for stainless steel, nickel superalloys, and titanium honeycomb structures. Used in jet-engine static structures, honeycomb panels for aerospace, and stainless-steel heat exchangers.\n\nRun in a vacuum or hydrogen furnace at 1010 to 1040 °C, no flux needed (the boron and silicon are self-fluxing in inert atmosphere). The joint matches the parent metal in corrosion resistance and remains stable to about 800 °C in service."
    },

    # ============ Jewelry ============
    {
        "slug": "sterling-medium", "title": "Sterling silver solder (medium)", "symbol": "Ag-med",
        "category": "jewelry",
        "subtitle": "Medium-flow sterling silver solder · ~720 °C",
        "comp": [("Ag", "70"), ("Cu", "20"), ("Zn", "10")],
        "solidus": 720, "liquidus": 745,
        "tags": ["silversmith", "sterling", "step soldering"],
        "body": "Silversmith stock comes in **easy, medium, hard, and IT (extra hard)** grades stepped 30 to 50 °C apart so multi-joint pieces can be assembled sequentially: hard first, then medium for the second joint without remelting the hard, then easy for the third. The color matches sterling (92.5 silver) closely after pickling.\n\nUse a borax-based flux. The work pickles in dilute sulfuric or sparex after each step to remove flux residue and reveal a fresh surface."
    },
]


def build_entry(spec):
    cat = spec["category"]
    cat_tags = CATEGORY_TAGS.get(cat, [])
    all_tags = list(dict.fromkeys(cat_tags + list(spec.get("tags", []))))
    return {
        "id": f"solder:{spec['slug']}",
        "module": "solder",
        "kind": "solder",
        "title": spec["title"],
        "symbol": spec.get("symbol", ""),
        "subtitle": spec.get("subtitle", ""),
        "category": cat,
        "tags": all_tags,
        "stats": stats_from(spec),
        "body": spec.get("body", ""),
        "hazards": spec.get("hazards", []),
        "related": spec.get("related", []),
        "sources": spec.get("sources", ["astm-b32"]),
    }


def write_manifest_entries():
    manifest = json.loads(MANIFEST.read_text())
    slugs = [s["slug"] for s in SOLDERS]
    for m in manifest["modules"]:
        if m["slug"] == "solder":
            m["entries"] = slugs
            m["status"] = "active"
            break
    MANIFEST.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    print(f"Manifest updated: solder declares {len(slugs)} entries.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    written = 0
    for spec in SOLDERS:
        entry = build_entry(spec)
        path = DATA_DIR / f"{spec['slug']}.json"
        text = json.dumps(entry, indent=2, ensure_ascii=False) + "\n"
        if args.dry_run:
            print(f"  {'~' if path.exists() else '+'} {path.relative_to(ROOT)}")
        else:
            path.write_text(text)
        written += 1
    print(f"\nSeeded {written} solder files.")

    if not args.dry_run:
        write_manifest_entries()
    return 0


if __name__ == "__main__":
    sys.exit(main())
