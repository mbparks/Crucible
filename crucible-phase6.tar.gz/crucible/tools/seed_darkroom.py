#!/usr/bin/env python3
"""
CRUCIBLE darkroom seeder.

Generates modules/darkroom/data/<slug>.json: black and white film developers
plus reference cards for time/temperature compensation, push/pull, agitation
protocols, and the rest of the wet chain (stop bath, fixer, wash).

Sources: Anchell & Troop (The Film Developing Cookbook), Kodak technical
publications, Ilford technical sheets.
"""

import json
import sys
import argparse
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "modules" / "darkroom" / "data"
MANIFEST = ROOT / "shared" / "data" / "manifest.json"


def _stat(key, label, value, unit, source="anchell-troop"):
    return {"key": key, "label": label, "value": value, "unit": unit, "source": source}


ENTRIES = [
    # ========== DEVELOPERS ==========
    {
        "slug": "d-76", "title": "D-76",
        "symbol": "D-76",
        "kind": "developer",
        "subtitle": "Kodak · MQ borax-buffered fine-grain · the reference developer · ID-11 equivalent",
        "stats": [
            _stat("type", "Type", "MQ (metol + hydroquinone)", ""),
            _stat("buffer", "Buffer", "borax (sodium tetraborate)", ""),
            _stat("stockPh", "Stock pH", 8.5, ""),
            _stat("stockKeeping", "Stock keeping", 6, "months sealed"),
            _stat("dilutions", "Working dilutions", "stock, 1:1, 1:3", ""),
            _stat("refTemp", "Reference temp", 20, "°C"),
            _stat("capacityStock", "Stock capacity", "16 rolls per gallon", ""),
            _stat("formula1", "Metol", 2.0, "g/L"),
            _stat("formula2", "Sodium sulfite anhydrous", 100, "g/L"),
            _stat("formula3", "Hydroquinone", 5.0, "g/L"),
            _stat("formula4", "Borax (decahydrate)", 2.0, "g/L"),
        ],
        "tags": ["developer", "MQ", "fine-grain", "general-purpose", "ID-11"],
        "body": "The canonical fine-grain MQ developer, in continuous production since 1927. The reference developer everyone else is compared against. **Ilford ID-11 is chemically identical** and the same times apply.\n\n**Mixing order** (per 1 L water at 52 °C): dissolve in this order to prevent metol oxidation, since hydroquinone in alkaline solution will rapidly oxidize unprotected metol. Pinch of sulfite first, then metol fully dissolved, then the bulk of sulfite, then hydroquinone, then borax. The 100 g/L sulfite is the heart of D-76: it acts as both preservative and as a mild silver-halide solvent, which is where the fine grain comes from.\n\n**Dilution behavior**: stock gives the finest grain at the cost of some sharpness; **1:1** is the workhorse and what most published times assume; **1:3** is one-shot and pushes acutance higher at the cost of slightly grittier grain. At 1:3 increase time by ~50% over 1:1.\n\n**Push/pull**: pushes one stop cleanly (~40% time increase), two stops with visible grain and contrast bloom. Pull one stop by reducing time ~25%.\n\n**Replenishment**: D-76R adds metol, sulfite, hydroquinone, and borax back to the working stock; replenish at 30 mL per roll developed. Discard the stock after 18 months or after replenishing to twice the original volume.",
        "hazards": ["irritant", "metol allergen (rare)", "alkaline"],
        "related": ["darkroom:dilution-math", "darkroom:time-temp-compensation", "reagent:na2s2o3"],
        "sources": ["anchell-troop"],
    },
    {
        "slug": "xtol", "title": "XTOL",
        "symbol": "XTOL",
        "kind": "developer",
        "subtitle": "Kodak · ascorbate / Phenidone · fine grain plus speed plus sharpness · modern D-76 successor",
        "stats": [
            _stat("type", "Type", "ascorbic acid + Phenidone (PC)", ""),
            _stat("stockKeeping", "Stock keeping", 6, "months sealed (sudden death failure mode)"),
            _stat("dilutions", "Working dilutions", "stock, 1:1, 1:2, 1:3", ""),
            _stat("refTemp", "Reference temp", 20, "°C"),
            _stat("capacityStock", "Stock capacity", "10 rolls per liter", ""),
            _stat("speedGain", "Effective speed", "+1/3 to +2/3 stop vs D-76", ""),
        ],
        "tags": ["developer", "ascorbate", "PC", "fine-grain", "T-grain"],
        "body": "Kodak's late 1990s replacement for D-76 in many labs. Uses ascorbic acid (vitamin C) and Phenidone instead of metol and hydroquinone: more environmentally friendly waste, no metol allergy risk, and slightly higher film speed with finer grain than D-76. Excellent on T-grain films (T-Max 100/400, Delta 100/400) where the structured-grain crystals benefit from the gentle reduction.\n\n**Sudden death failure**: XTOL can fail abruptly with no visible warning if the stock degrades; a roll comes out blank or extremely thin. The cause is suspected to be ascorbate exhaustion under marginal storage. **Mix from the foil packets in distilled water**, store in tightly sealed brown glass at room temperature, replace at 6 months max even if it looks fine, mark the mixing date on the bottle.\n\n**1:1** is the standard working strength; **1:2 and 1:3** for finer grain at longer times. At 1:3 development times reach 14 to 20 min, which is long but gives the best grain and tonal separation."
    },
    {
        "slug": "hc-110", "title": "HC-110",
        "symbol": "HC-110",
        "kind": "developer",
        "subtitle": "Kodak · liquid syrup concentrate · multiple dilutions · 'add a few drops' developer",
        "stats": [
            _stat("type", "Type", "liquid syrup (hydroquinone + alkali in glycols)", ""),
            _stat("stockKeeping", "Concentrate keeping", "indefinite", "(syrup unopened, years)"),
            _stat("dilutionA", "Dilution A", "1:15 from concentrate", "(strong, short times)"),
            _stat("dilutionB", "Dilution B", "1:31 from concentrate", "(standard)"),
            _stat("dilutionH", "Dilution H", "1:63 from concentrate", "(extended times)"),
            _stat("dilutionF", "Dilution F", "1:79 from concentrate", "(very long times, semi-stand)"),
            _stat("refTemp", "Reference temp", 20, "°C"),
        ],
        "tags": ["developer", "liquid concentrate", "long shelf life", "travel", "low-volume"],
        "body": "Liquid syrup that you dilute fresh for each session. The concentrate keeps essentially forever in the unopened bottle, which makes HC-110 the developer for photographers who don't shoot enough film to use up a powder kit before it expires. **The syrup is viscous**; warm the bottle in hot water before pouring or you will dispense less than you think.\n\n**Dilution naming** uses letters from Kodak's original document. **Dilution B (1:31)** is what almost all published times assume. **Dilution H (1:63)** doubles the time and is popular for low-contrast scenes and for keeping highlight detail under harsh lighting. **Dilution F (1:79)** with very dilute working solution and minimal agitation gives compensated, low-fog development for high-contrast subjects (the 'semi-stand' technique).\n\n**Modern Kodak HC-110** has reformulated since the original. Older 'classic' HC-110 had a viscous brown syrup; the current product is a less concentrated lighter formulation. Check the actual concentration on the bottle label, not the historical dilution names, if absolute consistency matters."
    },
    {
        "slug": "rodinal", "title": "Rodinal (R09)",
        "symbol": "Rodinal",
        "kind": "developer",
        "subtitle": "Agfa / Adox · p-aminophenol concentrate · sharpest grain · sold since 1891",
        "stats": [
            _stat("type", "Type", "p-aminophenol single-agent", ""),
            _stat("concentrateKeeping", "Concentrate keeping", "indefinite", "(the bottle gets darker but still works)"),
            _stat("dilutionStrong", "Strong dilution", "1:25", ""),
            _stat("dilutionStd", "Standard dilution", "1:50", ""),
            _stat("dilutionDilute", "Dilute (semi-stand)", "1:100 or 1:200", ""),
            _stat("refTemp", "Reference temp", 20, "°C"),
        ],
        "tags": ["developer", "p-aminophenol", "high-acutance", "classic", "long shelf life"],
        "body": "**The oldest developer still in production** (since 1891). Sold under various names: Agfa Rodinal, Adox Rodinal, Foma Fomadon R09, Spur Adonal. All are essentially the same chemistry. A dark brown viscous concentrate that keeps for decades unopened.\n\nRodinal is a **high-acutance, non-solvent developer**: it produces sharp, gritty grain (the opposite of D-76). Mid-tones have a characteristic edge-effect 'snap' that high-end large-format photographers prize.\n\n**Dilutions**: 1:25 strong is rarely used. **1:50 is the workhorse**, gives reasonable grain on slow films (50 to 100 ISO) and visible grain on fast films. **1:100 and 1:200 semi-stand** development (minimal agitation, 60 to 90 min times) gives compensating action: the developer exhausts in highlight areas while continuing to work in shadows, compressing extreme-contrast scenes into a printable range.\n\n**Not for T-grain films**: Rodinal makes the structured grain of T-Max and Delta look unpleasantly gritty. Stick to traditional cubic-grain emulsions (Tri-X, HP5+, FP4+) for the classic Rodinal look."
    },
    {
        "slug": "tmax-developer", "title": "T-MAX Developer",
        "symbol": "TMAX-D",
        "kind": "developer",
        "subtitle": "Kodak · liquid · optimized for T-grain emulsions · high contrast and speed",
        "stats": [
            _stat("type", "Type", "liquid concentrate", ""),
            _stat("dilutions", "Working dilutions", "1:4 (one-shot), 1:9 (replenished)", ""),
            _stat("refTemp", "Reference temp", 24, "°C", "anchell-troop"),
            _stat("speedGain", "Effective speed", "+1/3 stop on T-Max films", ""),
            _stat("pushFactor", "Push 1 stop", "+25% time", ""),
            _stat("pushFactor2", "Push 2 stops", "+85% time", ""),
        ],
        "tags": ["developer", "T-grain", "liquid", "push processing", "Tri-X"],
        "body": "Designed alongside T-Max 100 and 400 (1986) to optimize development of the new tabular-grain emulsions. T-grain crystals are flat hexagonal plates rather than the irregular polyhedra of traditional emulsions; they have more surface area per silver mass, react faster, and need a developer tuned for that geometry.\n\n**1:4 one-shot** is the standard; mix the working solution from concentrate at session start, use, discard. Times around 7 to 10 min at 24 °C for typical T-Max exposures. **24 °C reference temp** (not 20 °C); compensate published times appropriately.\n\nGood push developer: pushes T-Max 400 to 1600 cleanly (T-Max 400 at EI 1600 plus 85% time addition gives usable negatives). Pushing Tri-X works too but Tri-X in T-Max Developer has slightly more grain than Tri-X in HC-110 dilution B at the same speed."
    },
    {
        "slug": "ddx", "title": "DD-X",
        "symbol": "DD-X",
        "kind": "developer",
        "subtitle": "Ilford · liquid · speed-boosting fine-grain · Phenidone/hydroquinone",
        "stats": [
            _stat("type", "Type", "liquid PQ (Phenidone + hydroquinone)", ""),
            _stat("dilutions", "Working dilution", "1:4 only", ""),
            _stat("refTemp", "Reference temp", 20, "°C"),
            _stat("speedGain", "Effective speed", "rated box speed reliably", ""),
            _stat("grainProfile", "Grain", "fine, slightly gritty vs ID-11", ""),
        ],
        "tags": ["developer", "Ilford", "PQ", "speed-boosting", "liquid"],
        "body": "Ilford's premium liquid developer. **Single working dilution (1:4)** simplifies the workflow at the cost of some flexibility. Delivers true box speed on most films (where D-76 1:1 loses about 1/3 stop). Particularly good on Delta 3200, where pushing to box-rated EI 3200 needs DD-X's speed-boosting characteristics; D-76 leaves Delta 3200 effectively at EI 1600 to 2000.\n\nLiquid form means consistent batch-to-batch results and no powder-mixing variability."
    },
    {
        "slug": "perceptol", "title": "Perceptol",
        "symbol": "Perceptol",
        "kind": "developer",
        "subtitle": "Ilford · ultra-fine grain solvent developer · costs 1 stop of speed",
        "stats": [
            _stat("type", "Type", "MQ with high sulfite + sodium chloride", ""),
            _stat("dilutions", "Working dilutions", "stock, 1:1, 1:3", ""),
            _stat("refTemp", "Reference temp", 20, "°C"),
            _stat("speedLoss", "Effective speed", "-1 stop typical (EI 200 from 400)", ""),
            _stat("grainProfile", "Grain", "smallest of any general-purpose B&W developer", ""),
        ],
        "tags": ["developer", "Ilford", "ultra-fine-grain", "solvent", "MCM-100 equivalent"],
        "body": "Pushes the silver-halide solvent action even further than D-76: extra sulfite plus chloride dissolves more grain edges, leaving smaller silver clumps. The price is roughly one stop of effective film speed; rate Tri-X at EI 200, HP5+ at EI 200, FP4+ at EI 64.\n\nFor 35mm portraiture and architectural work where grain is the limiting factor, Perceptol's tight grain on 400-speed film at EI 200 can match the apparent sharpness of slower films developed conventionally. **Equivalent to the older Kodak Microdol-X / MCM-100** formulas."
    },
    {
        "slug": "caffenol-cl", "title": "Caffenol-C-L",
        "symbol": "Caffenol",
        "kind": "developer",
        "subtitle": "DIY · instant coffee + washing soda + vitamin C · for fun · works surprisingly well",
        "stats": [
            _stat("type", "Type", "DIY: caffeic acid + ascorbic acid (PC analog)", ""),
            _stat("recipeCoffee", "Instant coffee", 40, "g/L (not freeze-dried)"),
            _stat("recipeWashingSoda", "Washing soda (Na₂CO₃·10H₂O)", 16, "g/L"),
            _stat("recipeAscorbate", "Vitamin C (ascorbic acid)", 16, "g/L"),
            _stat("recipeKBr", "Potassium bromide (optional)", 1, "g/L (fog reducer)"),
            _stat("refTemp", "Reference temp", 20, "°C"),
            _stat("baseDevTime", "Tri-X at EI 400 base time", 12, "min"),
        ],
        "tags": ["developer", "DIY", "caffenol", "coffee", "ascorbate"],
        "body": "**Yes, you really can develop B&W film in coffee.** The caffeic acid (in coffee) is a polyphenol that, like other polyphenols (gallic acid, pyrogallol), acts as a photographic developer in alkaline solution. Add ascorbic acid (vitamin C) for synergy and to keep highlights clean. Add washing soda for the alkalinity. The result is a surprisingly capable developer with characteristic warm-tone negatives.\n\n**Use instant coffee (not freeze-dried)**: freeze-drying changes the caffeic-acid form and gives muddy results. Cheap supermarket instant coffee works best; specialty single-origin instants vary unpredictably. Add washing soda first, then coffee, then ascorbic acid last (delays the reaction until you start developing).\n\n**Add 1 g/L potassium bromide** if you have it (from a chemistry supply) to suppress base fog, especially on older films or any film rated faster than EI 400. Without KBr, expect slightly elevated fog density. Working solution is single-use; discard after one roll.\n\n**Not a precision developer.** Times vary between batches by 20% or more depending on the coffee. Plan on a test roll if you're trying for serious work. The fun is in the experiment, the warm tones, and the satisfaction of developing a roll for under a dollar."
    },

    # ========== REFERENCE CARDS ==========
    {
        "slug": "dilution-math", "title": "Developer dilution math",
        "symbol": "1:N",
        "kind": "reference",
        "subtitle": "Stock-to-working ratios, one-shot vs replenishment, replenishment math",
        "stats": [
            _stat("ratio11", "1:1 dilution", "equal parts stock + water", "(stock = working / 2)"),
            _stat("ratio13", "1:3 dilution", "1 part stock + 3 water", "(stock = working / 4)"),
            _stat("ratio131", "1:31 dilution (HC-110 B)", "1 part syrup + 31 water", ""),
            _stat("stockForRoll", "Stock per 35mm roll", "~250 mL minimum agent contact", "(tank dependent)"),
            _stat("replenishRate", "Replenishment", "30 to 70 mL/roll", "(developer-specific)"),
        ],
        "tags": ["reference", "dilution", "replenishment", "process"],
        "body": "**Standard dilution notation** is parts-stock-to-parts-water. '1:1' means equal parts (half stock by volume); '1:3' means 1 part stock plus 3 parts water (quarter stock); '1:31' means 1 part syrup plus 31 parts water (HC-110 dilution B, roughly 3% concentrate by volume).\n\n**Minimum stock per roll**: most film developers need at least 5 to 10 g of working developer agent per roll. Concentrate that into the minimum tank volume and you have a per-roll stock requirement. **35mm rolls** need around 250 mL working solution to cover the reel in a tank; **120 rolls** need 500 mL. At 1:1 dilution that's 125 mL of stock per 35mm roll, 250 mL per 120 roll. At 1:31 dilution it's 8 mL of HC-110 concentrate per 35mm roll, 16 mL per 120 roll.\n\n**One-shot vs replenishment**: one-shot is used once and discarded. Replenishment lets you reuse stock by adding back the consumed components. Replenisher solutions (D-76R, ID-11R, etc.) restore the developer balance; typical replenishment is 30 to 70 mL per roll. Replenished baths can give consistent results for 100+ rolls but require careful logging and periodic chemical analysis or seasoning rolls.\n\n**Mass to working solution**: if a recipe gives masses per liter of stock (e.g., D-76 has 5 g hydroquinone per L), then 1:1 working has 2.5 g/L of that agent; 1:3 has 1.25 g/L. This is why dilute developers need longer times: less agent per unit time means slower reduction.",
        "related": ["developer:d-76", "developer:hc-110", "developer:rodinal"],
        "sources": ["anchell-troop"],
    },
    {
        "slug": "time-temp-compensation", "title": "Time and temperature compensation",
        "symbol": "T(°C)",
        "kind": "reference",
        "subtitle": "Adjusting development time when the tank is hotter or colder than 20 °C",
        "stats": [
            _stat("rule18", "Rule (18 to 24 °C)", "subtract 7% per °C above 20", ""),
            _stat("rule17", "Rule (17 to 20 °C)", "add 8% per °C below 20", ""),
            _stat("rule24up", "Rule (above 24 °C)", "use Arrhenius curve, not linear", ""),
            _stat("rule15down", "Rule (below 17 °C)", "use Arrhenius curve, not linear", ""),
            _stat("standard", "Standard reference", 20, "°C (most published times)"),
            _stat("tmaxStandard", "T-Max Developer reference", 24, "°C"),
        ],
        "tags": ["reference", "temperature", "process control", "Arrhenius"],
        "body": "Developer reactions roughly double in rate per 10 °C temperature rise (Arrhenius behavior), but for the engineering-relevant ±4 °C range a linear approximation is good enough:\n\n**Rule of thumb (20 °C nominal)**:\n- Add 8% per °C below 20\n- Subtract 7% per °C above 20\n- Linear within ±4 °C only; beyond that use manufacturer's curves or Arrhenius\n\n**Worked example**: D-76 1:1 standard time 10 min at 20 °C. Tank reads 22 °C. New time = 10 × (1 - 2 × 0.07) = 8.6 min. Tank reads 18 °C. New time = 10 × (1 + 2 × 0.08) = 11.6 min.\n\n**Why 20 °C**: it's the standard reference for nearly all published B&W times. Kodak T-Max developer is unusual in using 24 °C as the reference because the original T-Max developer was formulated for color-process compatibility. Note the 24 °C reference when reading T-Max Developer times.\n\n**Temperature drift in the tank**: a 250 mL tank cools by about 1 °C per 5 min in a 18 °C room. For long developments (15+ min at 20 °C, semi-stand at 1:100, etc.) the tank temperature will drift toward ambient. Pre-warm or pre-cool the tank in a water bath, or develop with the tank in a temperature-controlled bath.",
        "related": ["developer:d-76", "developer:tmax-developer"],
        "sources": ["anchell-troop"],
    },
    {
        "slug": "push-pull-tables", "title": "Push and pull processing",
        "symbol": "±EV",
        "kind": "reference",
        "subtitle": "Time adjustments for shooting film at non-rated speeds",
        "stats": [
            _stat("push1stop", "Push 1 stop", "+40 to +50% time", "(film/developer dependent)"),
            _stat("push2stop", "Push 2 stops", "+80 to +110% time", ""),
            _stat("push3stop", "Push 3 stops", "+150 to +200% time", "(noticeable grain and contrast loss)"),
            _stat("pull1stop", "Pull 1 stop", "-20 to -30% time", ""),
            _stat("pull2stop", "Pull 2 stops", "-40 to -50% time", "(rarely useful)"),
            _stat("trixD76pushTimes", "Tri-X D-76 1:1 EI 400 base", 10, "min (start)"),
            _stat("trixD76push1", "Tri-X D-76 1:1 EI 800", 14, "min"),
            _stat("trixD76push2", "Tri-X D-76 1:1 EI 1600", 20, "min"),
        ],
        "tags": ["reference", "push", "pull", "process"],
        "body": "**Push processing** lets you shoot film at higher EI than its rated speed and recover usable images by extending development time. This works because extended development continues to amplify the latent image in already-exposed grains, but **does not create new image** in unexposed shadow areas. The result: highlights and midtones are well exposed and printable; deep shadows go to pure black (no detail) where there is no exposure to develop.\n\n**Push 1 stop** is reliable and clean on most films. **Push 2 stops** is usable, with visible grain growth, increased contrast, and some shadow detail loss. **Push 3 stops** is for atmosphere and grain texture, not for clean technique. Beyond 3 stops the negative is mostly compression and clumpy grain.\n\n**Pull processing** lets you shoot film at lower EI than rated (typically to soften high-contrast scenes) and compresses the negative range by under-developing. Useful for contrasty subjects (snow at noon, indoor with bright windows). Pulling much more than 1 stop is rarely useful; the negatives go flat and printing them is harder than just developing normally and using a soft paper grade.\n\n**Specific tables** are developer/film dependent. The published time × 1.4 for 1 stop push is a starting point only. Test rolls in your tank, at your temperature, with your agitation are mandatory for repeatable results.",
        "related": ["developer:d-76", "developer:tmax-developer", "developer:ddx"],
        "sources": ["anchell-troop"],
    },
    {
        "slug": "agitation-protocols", "title": "Agitation protocols",
        "symbol": "↺",
        "kind": "reference",
        "subtitle": "Continuous, intermittent, semi-stand, stand · effects on contrast and edge effects",
        "stats": [
            _stat("continuous", "Continuous agitation", "constant flow over emulsion", "(low contrast, no edge effects)"),
            _stat("intermittentStd", "Standard (Kodak)", "5 s every 30 s after initial 30 s", ""),
            _stat("intermittentIlford", "Ilford method", "4 inversions every 60 s after initial 10 s", ""),
            _stat("semiStand", "Semi-stand", "1 inversion at 30 s, then 30 to 60 min still", "(high acutance, compensation)"),
            _stat("stand", "Stand", "no agitation after initial 30 s, 60 to 120 min", "(strong compensation, low contrast)"),
        ],
        "tags": ["reference", "agitation", "process control", "compensation"],
        "body": "Agitation controls **edge effects** (adjacency phenomena where developer is exhausted at boundaries and migrates from adjacent areas), **uniformity** (preventing surge marks and streaks), and **compensating action** (in dilute developers, exhaustion in highlights with continued action in shadows).\n\n**Continuous agitation** maximizes development rate, eliminates compensating action, gives uniform density at the cost of edge effects. Used in rotary processors and some color processes.\n\n**Standard intermittent** (Kodak: 5 s every 30 s; Ilford: 4 inversions every 60 s) is what published times assume. **The Ilford method gives slightly more contrast** than the Kodak method on the same film; some prefer one or the other for aesthetic reasons.\n\n**Semi-stand and stand** development work only with dilute developers (Rodinal 1:100, HC-110 dilution F, dilute Pyrocat-HD). The dilute developer **exhausts in highlight regions** while continuing to work in shadows. The result is high acutance from edge effects and a 'compressed' tonal range that prints well on hard paper. Excellent for high-contrast scenes (bright windows, harsh sunlight); destructive on already low-contrast scenes (you get muddy negatives).\n\n**Inversion vs swizzle stick**: stainless steel tank inversions give cleaner agitation than rotating a center-pin reel ('swizzle stick'). Plastic tanks with a center pin work but can leave development streaks if the agitation pattern is inconsistent.",
        "related": ["developer:rodinal", "developer:hc-110"],
        "sources": ["anchell-troop"],
    },
]


def build_entry(spec):
    return {
        "id": f"developer:{spec['slug']}" if spec.get("kind", "developer") == "developer" else f"darkroom:{spec['slug']}",
        "module": "darkroom",
        "kind": spec.get("kind", "developer"),
        "title": spec["title"],
        "symbol": spec.get("symbol", ""),
        "subtitle": spec.get("subtitle", ""),
        "tags": spec.get("tags", []),
        "stats": spec.get("stats", []),
        "body": spec.get("body", ""),
        "hazards": spec.get("hazards", []),
        "related": spec.get("related", []),
        "sources": spec.get("sources", ["anchell-troop"]),
    }


def write_manifest_entries():
    manifest = json.loads(MANIFEST.read_text())
    slugs = [s["slug"] for s in ENTRIES]
    for m in manifest["modules"]:
        if m["slug"] == "darkroom":
            m["entries"] = slugs
            m["status"] = "active"
            m["phase"] = 5
            break
    MANIFEST.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    print(f"Manifest updated: darkroom declares {len(slugs)} entries.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    written = 0
    for spec in ENTRIES:
        entry = build_entry(spec)
        path = DATA_DIR / f"{spec['slug']}.json"
        text = json.dumps(entry, indent=2, ensure_ascii=False) + "\n"
        if args.dry_run:
            print(f"  {'~' if path.exists() else '+'} {path.relative_to(ROOT)}")
        else:
            path.write_text(text)
        written += 1
    print(f"\nSeeded {written} darkroom files.")
    if not args.dry_run:
        write_manifest_entries()
    return 0


if __name__ == "__main__":
    sys.exit(main())
