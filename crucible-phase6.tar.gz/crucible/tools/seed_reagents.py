#!/usr/bin/env python3
"""
CRUCIBLE reagent seeder.

Generates modules/reagent/data/<slug>.json: common laboratory reagents with
molar mass, stock concentration, density, and dilution notes. Plus a couple
of reference cards (dilution math, concentration units).

Reagent properties from the Merck Index (15th ed.) and CRC Handbook.
"""

import json
import sys
import argparse
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "modules" / "reagent" / "data"
MANIFEST = ROOT / "shared" / "data" / "manifest.json"


def _stat(key, label, value, unit, source="merck-index"):
    return {"key": key, "label": label, "value": value, "unit": unit, "source": source}


REAGENTS = [
    # ========== STRONG ACIDS ==========
    {
        "slug": "hcl-conc", "title": "Hydrochloric acid, concentrated",
        "symbol": "HCl 37%",
        "subtitle": "Concentrated HCl · 37% w/w · ~12.1 M",
        "stats": [
            _stat("formula", "Formula", "HCl", ""),
            _stat("molarMass", "Molar mass", 36.46, "g/mol"),
            _stat("density", "Density", 1.19, "g/mL (37%)"),
            _stat("concentration", "Stock concentration", "37 w/w", "%"),
            _stat("stockMolarity", "Stock molarity", 12.1, "M"),
            _stat("pka", "pKa", -7, ""),
            _stat("boilingPoint", "Boiling (azeotrope)", 110, "°C (20.2% HCl)"),
        ],
        "tags": ["strong acid", "mineral acid", "fuming", "metal cleaning"],
        "body": "Aqueous solution of hydrogen chloride gas. The 37 w/w% commercial concentrated grade is the working laboratory stock. Fumes visibly in moist air (the white fumes are aerosolized droplets of dilute acid that condense around HCl gas).\n\n**Dilution by volume to common working strengths** (target / mL of conc HCl per L of solution):\n- 6 M (50%) → 496 mL/L\n- 3 M → 248 mL/L\n- 1 M → 83 mL/L\n- 0.1 M → 8.3 mL/L\n\n**Always add acid to water**, never the reverse. The heat of dilution will steam the surface and spit acid otherwise.",
        "hazards": ["corrosive", "respiratory irritant"],
        "related": ["element:cl", "element:h", "etch:aqua-regia"],
        "sources": ["merck-index", "crc-104"],
    },
    {
        "slug": "h2so4-conc", "title": "Sulfuric acid, concentrated",
        "symbol": "H₂SO₄ 98%",
        "subtitle": "Concentrated H₂SO₄ · 98% w/w · ~18.0 M",
        "stats": [
            _stat("formula", "Formula", "H₂SO₄", ""),
            _stat("molarMass", "Molar mass", 98.08, "g/mol"),
            _stat("density", "Density", 1.84, "g/mL (98%)"),
            _stat("concentration", "Stock concentration", "98 w/w", "%"),
            _stat("stockMolarity", "Stock molarity", 18.0, "M"),
            _stat("pka1", "pKa1", -3, ""),
            _stat("pka2", "pKa2", 1.99, ""),
            _stat("boilingPoint", "Boiling point", 337, "°C"),
        ],
        "tags": ["strong acid", "diprotic", "dehydrating", "battery acid"],
        "body": "The highest-volume industrial chemical by mass. Concentrated H₂SO₄ is a powerful dehydrating agent: it pulls water out of carbohydrates, paper, and skin, leaving char. The heat of dilution is enormous; **always add acid to water** in a thin stream while stirring, never water to acid.\n\n**Common working dilutions** (mL conc per L of solution):\n- 6 M → 333 mL/L\n- 1 M → 55 mL/L\n- 0.1 M → 5.5 mL/L\n\nBattery acid is ~37% (≈ 4.5 M). Drain cleaner is often >95%.",
        "hazards": ["corrosive", "dehydrating", "thermal hazard on dilution"],
        "related": ["element:s", "element:o", "element:h"],
        "sources": ["merck-index", "crc-104"],
    },
    {
        "slug": "hno3-conc", "title": "Nitric acid, concentrated",
        "symbol": "HNO₃ 70%",
        "subtitle": "Concentrated HNO₃ · 70% w/w · ~15.8 M",
        "stats": [
            _stat("formula", "Formula", "HNO₃", ""),
            _stat("molarMass", "Molar mass", 63.01, "g/mol"),
            _stat("density", "Density", 1.42, "g/mL (70%)"),
            _stat("concentration", "Stock concentration", "70 w/w", "%"),
            _stat("stockMolarity", "Stock molarity", 15.8, "M"),
            _stat("pka", "pKa", -1.4, ""),
            _stat("boilingPoint", "Boiling (azeotrope)", 121.9, "°C (68% HNO₃)"),
        ],
        "tags": ["strong acid", "oxidizing acid", "fuming", "metallurgy"],
        "body": "Strong oxidizing acid that dissolves most metals except gold, platinum, iridium, and (when concentrated and cold) iron and aluminum (which passivate). The yellow color of stock bottles is dissolved NO₂ from slow decomposition; fresh batches are clear.\n\n**Metals and HNO₃:**\n- Copper, silver, mercury: dissolve to nitrates with brown NO₂ fume\n- Iron, aluminum, chromium: passivate in concentrated, dissolve in dilute\n- Gold, platinum: only attacked by aqua regia (HNO₃ + HCl)\n\n**Fuming red HNO₃** (>86%) is a rocket-fuel oxidizer; **WFNA** (white fuming, near 100%) is more aggressive again. The 70% stock is what you'll usually use.",
        "hazards": ["corrosive", "oxidizer", "respiratory irritant (NO₂)"],
        "related": ["element:n", "element:o", "etch:aqua-regia", "etch:nital"],
        "sources": ["merck-index"],
    },
    {
        "slug": "acetic-glacial", "title": "Acetic acid, glacial",
        "symbol": "CH₃COOH",
        "subtitle": "Glacial acetic acid · 99.8% w/w · ~17.4 M",
        "stats": [
            _stat("formula", "Formula", "CH₃COOH", ""),
            _stat("molarMass", "Molar mass", 60.05, "g/mol"),
            _stat("density", "Density", 1.05, "g/mL"),
            _stat("concentration", "Stock concentration", "99.8 w/w", "%"),
            _stat("stockMolarity", "Stock molarity", 17.4, "M"),
            _stat("pka", "pKa", 4.76, ""),
            _stat("meltingPoint", "Melting point", 16.6, "°C"),
            _stat("boilingPoint", "Boiling point", 118, "°C"),
        ],
        "tags": ["weak acid", "organic acid", "buffer component", "glacial"],
        "body": "'Glacial' refers to the ice-like crystals that form at 16.6 °C; the lab is often below this in winter and the bottle solidifies. Warm the bottle gently to liquefy before pouring.\n\n**The acid form of the acetate buffer system** (pKa 4.76). Combined with sodium acetate, gives a useful buffer in the pH 3.8 to 5.8 range.\n\nDilute acetic acid is vinegar (5% w/v is household, 7% is white pickling).",
        "hazards": ["combustible", "corrosive"],
        "related": ["element:c", "element:o", "element:h", "buffer:acetate"],
        "sources": ["merck-index"],
    },

    # ========== STRONG BASES ==========
    {
        "slug": "naoh-pellets", "title": "Sodium hydroxide",
        "symbol": "NaOH",
        "subtitle": "Caustic soda · solid pellets · deliquescent",
        "stats": [
            _stat("formula", "Formula", "NaOH", ""),
            _stat("molarMass", "Molar mass", 40.00, "g/mol"),
            _stat("density", "Density", 2.13, "g/cm³ (solid)"),
            _stat("meltingPoint", "Melting point", 318, "°C"),
            _stat("solubility", "Solubility (20 °C)", 1090, "g/L (very high)"),
            _stat("phStock", "1 M solution pH", 14.0, ""),
        ],
        "tags": ["strong base", "caustic", "deliquescent", "saponification"],
        "body": "The standard strong base. Sold as solid pellets or as solutions (50% w/w stock is common industrially). Pellets are deliquescent: they pull moisture from air and form a wet caustic puddle if left open. Store sealed.\n\n**Dissolving exotherm** is significant: 1 M solution heats about 30 °C above starting water temperature. Add slowly to cool water, stir continuously.\n\n**Use cases**: pH adjustment up, saponification (soap making), drain cleaning, hot caustic black-oxide finish on steel, aluminum etch prep before anodizing.",
        "hazards": ["corrosive", "caustic", "exotherm on dissolution"],
        "related": ["element:na", "etch:caustic-black-oxide"],
        "sources": ["merck-index"],
    },
    {
        "slug": "koh-pellets", "title": "Potassium hydroxide",
        "symbol": "KOH",
        "subtitle": "Caustic potash · solid pellets · deliquescent",
        "stats": [
            _stat("formula", "Formula", "KOH", ""),
            _stat("molarMass", "Molar mass", 56.11, "g/mol"),
            _stat("density", "Density", 2.04, "g/cm³ (solid)"),
            _stat("meltingPoint", "Melting point", 360, "°C"),
            _stat("solubility", "Solubility (20 °C)", 1120, "g/L"),
        ],
        "tags": ["strong base", "caustic", "soft soap", "alkaline batteries"],
        "body": "Strong base analogous to NaOH; chemically interchangeable for most lab work. KOH gives **soft soap** (potassium soaps are water-soluble, sodium soaps are bar soap). Used in alkaline batteries and in some metallographic etchants where the K+ counterion matters (Murakami's reagent for tungsten carbides).",
        "hazards": ["corrosive", "caustic"],
        "related": ["element:k", "etch:murakami"],
        "sources": ["merck-index"],
    },
    {
        "slug": "nh4oh-conc", "title": "Ammonium hydroxide, concentrated",
        "symbol": "NH₄OH 29%",
        "subtitle": "Aqueous ammonia · ~29% NH₃ · ~14.5 M",
        "stats": [
            _stat("formula", "Formula", "NH₃·H₂O", ""),
            _stat("molarMass", "Molar mass", 35.05, "g/mol (as NH₃·H₂O)"),
            _stat("density", "Density", 0.90, "g/mL (29%)"),
            _stat("concentration", "Stock concentration", "29 w/w NH₃", "%"),
            _stat("stockMolarity", "Stock molarity", 14.5, "M"),
            _stat("pkb", "pKb", 4.75, "(pKa of NH₄⁺ is 9.25)"),
        ],
        "tags": ["weak base", "ammonia", "household cleaner", "patina"],
        "body": "Aqueous ammonia. The 29% lab stock is sometimes labeled 'ammonium hydroxide' but is really just dissolved NH₃ gas. **Strong fumes**; always open in a fume hood. Household ammonia cleaners are typically 3 to 10% NH₃.\n\n**Use cases**: pH adjustment up (gentler than NaOH), copper/brass etching and patinas (forms a deep blue tetrammine copper complex), removing fingerprints from optical glass, dissolving silver salts in photo darkroom.",
        "hazards": ["respiratory irritant", "fume hood"],
        "related": ["element:n", "etch:ammonia-patina"],
        "sources": ["merck-index"],
    },

    # ========== COMMON SALTS ==========
    {
        "slug": "na2co3", "title": "Sodium carbonate",
        "symbol": "Na₂CO₃",
        "subtitle": "Soda ash · washing soda · anhydrous",
        "stats": [
            _stat("formula", "Formula", "Na₂CO₃", ""),
            _stat("molarMass", "Molar mass", 105.99, "g/mol"),
            _stat("density", "Density", 2.54, "g/cm³"),
            _stat("solubility", "Solubility (20 °C)", 215, "g/L"),
            _stat("phSolution", "1 M solution pH", 11.6, ""),
        ],
        "tags": ["soda ash", "carbonate", "weak base", "glass", "soap"],
        "body": "Mild alkaline salt, safer to handle than NaOH for general pH adjustment up. Forms the **carbonate buffer system** with bicarbonate (pKa 10.33).\n\nIndustrial use is dominated by glass manufacture (a flux for SiO₂), soap and detergent formulation, and pH control of process water. Decahydrate (washing soda) is what's sold for laundry.",
        "related": ["element:na", "element:c", "element:o", "buffer:carbonate"],
        "sources": ["merck-index"],
    },
    {
        "slug": "nahco3", "title": "Sodium bicarbonate",
        "symbol": "NaHCO₃",
        "subtitle": "Baking soda · mild buffer · safe quench for spilled acid",
        "stats": [
            _stat("formula", "Formula", "NaHCO₃", ""),
            _stat("molarMass", "Molar mass", 84.01, "g/mol"),
            _stat("density", "Density", 2.20, "g/cm³"),
            _stat("solubility", "Solubility (20 °C)", 96, "g/L"),
            _stat("decompose", "Decomposes", 50, "°C (to Na₂CO₃ + H₂O + CO₂)"),
        ],
        "tags": ["baking soda", "bicarbonate", "acid neutralizer", "spill response"],
        "body": "The cheap, safe acid neutralizer kept on hand for accidental acid spills. Dust onto the spill until fizzing stops, then mop up and rinse.\n\nDecomposes on heating above 50 °C to sodium carbonate plus water and CO₂, which is why it works as a chemical leavening agent (and as a Class B/C fire extinguisher fill, where the CO₂ smothers the flame).",
        "related": ["element:na", "buffer:carbonate"],
        "sources": ["merck-index"],
    },
    {
        "slug": "nacl", "title": "Sodium chloride",
        "symbol": "NaCl",
        "subtitle": "Common salt · halite",
        "stats": [
            _stat("formula", "Formula", "NaCl", ""),
            _stat("molarMass", "Molar mass", 58.44, "g/mol"),
            _stat("density", "Density", 2.16, "g/cm³"),
            _stat("meltingPoint", "Melting point", 801, "°C"),
            _stat("solubility", "Solubility (20 °C)", 358, "g/L (5.4 M sat.)"),
            _stat("eutecticBrine", "Eutectic brine", "-21.1 °C at 23.3% NaCl", ""),
        ],
        "tags": ["salt", "saline", "brine", "chloride"],
        "body": "Standard ionic strength reference. **Physiological saline** is 0.9% w/v (0.154 M), the isotonic concentration for human cells. **Seawater** averages 3.5% w/v (0.6 M).\n\n**Brine quenching** for steel (10 to 23% NaCl) is faster than plain water; the salt disrupts the vapor film that forms during quench and increases heat transfer at the steel surface."
    },
    {
        "slug": "na2s2o3", "title": "Sodium thiosulfate",
        "symbol": "Na₂S₂O₃·5H₂O",
        "subtitle": "Photographic fixer · iodine titrant · chlorine neutralizer",
        "stats": [
            _stat("formula", "Formula", "Na₂S₂O₃·5H₂O", ""),
            _stat("molarMass", "Molar mass", 248.18, "g/mol (pentahydrate)"),
            _stat("density", "Density", 1.69, "g/cm³"),
            _stat("solubility", "Solubility (20 °C)", 700, "g/L (very high)"),
        ],
        "tags": ["photo fixer", "iodometry", "chlorine quench", "darkroom"],
        "body": "Pentahydrate is the lab and darkroom form. Reduces I₂ to I⁻ stoichiometrically (the basis of iodometric titration; the indicator is starch which turns dark blue with I₂ and clears at the endpoint).\n\n**In the darkroom**, dissolved silver halides (the unexposed parts of a film or print) form a soluble silver-thiosulfate complex that washes away. Modern rapid fixers use ammonium thiosulfate instead because it works ~5x faster.",
        "related": ["element:na", "element:s", "developer:d-76"],
        "sources": ["merck-index", "anchell-troop"],
    },
    {
        "slug": "edta-disodium", "title": "EDTA disodium",
        "symbol": "Na₂H₂EDTA·2H₂O",
        "subtitle": "Chelating agent · disodium dihydrate · ~0.1 M working solution",
        "stats": [
            _stat("formula", "Formula", "C₁₀H₁₄N₂Na₂O₈·2H₂O", ""),
            _stat("molarMass", "Molar mass", 372.24, "g/mol"),
            _stat("solubility", "Solubility (20 °C)", 108, "g/L"),
            _stat("pka1", "pKa1", 2.0, ""),
            _stat("pka2", "pKa2", 2.7, ""),
            _stat("pka3", "pKa3", 6.16, ""),
            _stat("pka4", "pKa4", 10.26, ""),
        ],
        "tags": ["chelator", "complexometry", "metal extraction", "water hardness"],
        "body": "Six binding sites (two amines, four carboxylates) wrap around a metal ion in a 1:1 complex. Forms strong complexes with most divalent and trivalent metals. **Complexometric titrations** of water hardness (Ca and Mg) use EDTA with Eriochrome Black T indicator at pH 10 (ammonia buffer).\n\nAlso used to extract metal contaminants from soil and biological samples, as a stabilizer in cosmetics and food (sequesters trace Fe and Cu that would catalyze oxidation), and in chelation therapy for heavy-metal poisoning.",
        "related": [],
        "sources": ["merck-index"],
    },

    # ========== REFERENCE CARDS ==========
    {
        "slug": "dilution-math", "title": "Dilution math",
        "symbol": "M₁V₁=M₂V₂",
        "kind": "reference",
        "subtitle": "Concentration arithmetic for solution prep",
        "stats": [
            _stat("dilution", "Dilution rule", "M₁V₁ = M₂V₂", "(stock × volume = final × volume)"),
            _stat("massToMolarity", "Mass to molarity", "M = (mass_g) / (MW × L)", ""),
            _stat("percentToMolarity", "% w/v to M", "M = (10 × % × density) / MW", ""),
            _stat("ppmToMolarity", "ppm to M", "M = ppm × 10⁻³ / MW", "(for dilute aq sol)"),
            _stat("molesFromVolume", "Moles from volume", "n = M × V", ""),
            _stat("dilutionFactor", "Dilution factor", "DF = V_final / V_stock", ""),
        ],
        "tags": ["reference", "math", "stoichiometry", "concentration"],
        "body": "**The two equations that handle 90% of solution prep:**\n\n1. **Dilution**: M₁V₁ = M₂V₂. Given a stock at M₁, to make V₂ of a solution at M₂, use V₁ = M₂V₂/M₁ of stock and bring to V₂ with solvent.\n\n2. **Solid to molarity**: dissolve (M × V × MW) grams in less than V of solvent, dissolve fully, then bring to volume V. Do not pre-dilute and add water to a fixed volume mark; volume changes on solute addition.\n\n**Worked example**: 100 mL of 0.1 M HCl from 12.1 M stock. V₁ = (0.1 × 0.1)/12.1 = 0.000826 L = 0.83 mL. Pipet 0.83 mL stock into a 100 mL volumetric flask containing about 70 mL water, swirl, bring to mark with water.\n\n**Concentration unit conversions** for a 37% w/w aqueous HCl (density 1.19 g/mL):\n- 37 g HCl per 100 g solution = 37 × 1.19 / 100 = 0.4403 g/mL\n- M = (0.4403 × 1000) / 36.46 = 12.1 mol/L\n\nUse this pattern for any concentrated stock to convert manufacturer's percentage spec into a working molarity.",
        "related": [],
        "sources": [],
    },
    {
        "slug": "serial-dilution", "title": "Serial dilution",
        "symbol": "10×",
        "kind": "reference",
        "subtitle": "Stepwise dilutions for assays, standards, and titrations",
        "stats": [
            _stat("tenFold", "10× dilution", "1 part stock + 9 parts solvent", ""),
            _stat("twoFold", "2× dilution", "1 part stock + 1 part solvent", ""),
            _stat("logCurve", "Log dilution curve", "C₀, C₀/10, C₀/100, C₀/1000, ...", ""),
            _stat("twoFoldCurve", "2-fold curve", "C₀, C₀/2, C₀/4, C₀/8, ...", ""),
            _stat("minStep", "Min reliable step", "1:20 by pipette, larger by volumetric", ""),
        ],
        "tags": ["reference", "assay", "standards curve", "titration"],
        "body": "**Why serial:** a single dilution from a strong stock to a very dilute working solution often spans 4 to 6 orders of magnitude, which would require either an enormous volume of solvent or an impractically tiny volume of stock. Stepping in 10× increments keeps every pipetting operation in the comfortable 0.1 to 10 mL range.\n\n**Procedure** for a 10× serial dilution curve (six points, 100 mM down to 1 μM):\n1. Label six tubes: 100 mM, 10 mM, 1 mM, 100 μM, 10 μM, 1 μM.\n2. Add 900 μL solvent to tubes 2 through 6.\n3. Pipet 1 mL stock into tube 1 (label only; this is the undiluted point).\n4. Pipet 100 μL from tube 1 into tube 2, mix.\n5. Pipet 100 μL from tube 2 into tube 3, mix.\n6. Continue through tube 6.\n\n**Use a fresh tip at every step** (especially when going from concentrated to dilute) or carryover dominates the lower points. Vortex or invert between transfers; pipetting from an unmixed tube introduces a stratified concentration error.",
        "related": ["reagent:dilution-math"],
        "sources": [],
    },
]


def build_entry(spec):
    kind = spec.get("kind", "reagent")
    return {
        "id": f"reagent:{spec['slug']}",
        "module": "reagent",
        "kind": kind,
        "title": spec["title"],
        "symbol": spec.get("symbol", ""),
        "subtitle": spec.get("subtitle", ""),
        "tags": spec.get("tags", []),
        "stats": spec.get("stats", []),
        "body": spec.get("body", ""),
        "hazards": spec.get("hazards", []),
        "related": spec.get("related", []),
        "sources": spec.get("sources", ["merck-index"]),
    }


def write_manifest_entries():
    manifest = json.loads(MANIFEST.read_text())
    slugs = [s["slug"] for s in REAGENTS]
    for m in manifest["modules"]:
        if m["slug"] == "reagent":
            m["entries"] = slugs
            m["status"] = "active"
            break
    MANIFEST.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    print(f"Manifest updated: reagent declares {len(slugs)} entries.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    written = 0
    for spec in REAGENTS:
        entry = build_entry(spec)
        path = DATA_DIR / f"{spec['slug']}.json"
        text = json.dumps(entry, indent=2, ensure_ascii=False) + "\n"
        if args.dry_run:
            print(f"  {'~' if path.exists() else '+'} {path.relative_to(ROOT)}")
        else:
            path.write_text(text)
        written += 1
    print(f"\nSeeded {written} reagent files.")
    if not args.dry_run:
        write_manifest_entries()
    return 0


if __name__ == "__main__":
    sys.exit(main())
