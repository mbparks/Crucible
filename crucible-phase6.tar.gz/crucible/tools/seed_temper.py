#!/usr/bin/env python3
"""
CRUCIBLE temper seeder.

Generates modules/temper/data/<slug>.json: heat-treat schedules for the common
alloys, the tempering color chart, and a quenchant selection card.

Schedule values follow ASM Handbook Vol. 4 (Heat Treating) and the ASM
Specialty Handbook: Heat Treater's Guide.

Usage:
    python3 tools/seed_temper.py
"""

import json
import sys
import argparse
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "modules" / "temper" / "data"
MANIFEST = ROOT / "shared" / "data" / "manifest.json"


def _stat(key, label, value, unit, source="asm-v4"):
    return {"key": key, "label": label, "value": value, "unit": unit, "source": source}


# Each schedule lists austenitize T, quench, temper T, target hardness, plus optional
# subzero / soak time / preheat fields.
SCHEDULES = [
    {
        "slug": "1045-hardening",
        "title": "AISI 1045 hardening", "symbol": "1045",
        "subtitle": "Through-hardening schedule for medium-carbon steel",
        "stats": [
            _stat("austenitizeTemp", "Austenitize", "830-860", "°C"),
            _stat("soakTime", "Soak", "30-45", "min per 25 mm"),
            _stat("quench", "Quench", "Water (sections >25 mm) or oil", ""),
            _stat("asQuenchedHardness", "As-quenched", "55-58", "HRC (surface)"),
            _stat("temperTemp", "Temper", "150-650", "°C, see body for target"),
            _stat("hardenability", "Hardenability", "Shallow (50% martensite at 6-10 mm)", ""),
        ],
        "tags": ["carbon steel", "water quench", "shafts", "induction option"],
        "body": "1045 is medium-carbon plain steel. Without alloying, hardenability is shallow, so through-hardening is limited to sections under about 25 mm in water and under about 10 mm in oil.\n\n**Tempering targets:**\n- 150 to 200 °C → 55-58 HRC (wear surface, brittle)\n- 200 to 315 °C → 50-55 HRC (general purpose hardened part)\n- 425 to 540 °C → 35-45 HRC (tough shaft)\n- 540 to 650 °C → 25-35 HRC (PHT condition)\n\n**Induction hardening** of wear surfaces is the dominant industrial use: heat just the surface to 870 to 900 °C with an induction coil, water-spray quench. Result is a hard case (55 to 60 HRC) over an unaffected tough core.",
        "related": ["alloy:aisi-1045"],
        "sources": ["asm-v4", "asm-htg"],
    },
    {
        "slug": "1095-knife",
        "title": "AISI 1095 knife heat treat", "symbol": "1095",
        "subtitle": "Knife and spring schedule for high-carbon steel",
        "stats": [
            _stat("austenitizeTemp", "Austenitize", "790-815", "°C"),
            _stat("soakTime", "Soak", "5-10", "min at temperature"),
            _stat("quench", "Quench", "Fast oil (Parks 50) or warm water", ""),
            _stat("asQuenchedHardness", "As-quenched", "64-66", "HRC"),
            _stat("temperKnife", "Temper for knife", "175-230", "°C → 58-62 HRC"),
            _stat("temperSpring", "Temper for spring", "315-425", "°C → 45-50 HRC"),
        ],
        "tags": ["carbon steel", "knife", "spring", "bladesmithing"],
        "body": "**Bladesmith schedule:**\n1. Normalize: 845 °C, hold 5 min per 6 mm thickness, air cool. Repeat 2-3 cycles to refine grain.\n2. Anneal (if needed for machining): 790 °C, slow furnace cool to 425 °C.\n3. Austenitize: 790-815 °C for 5-10 min. Use a magnet to verify nonmagnetic (you're above Curie point).\n4. Quench: fast oil (Parks 50, McMaster 11K91) edge-down to minimize warp. Brine quench gives higher hardness but more cracking risk.\n5. Test: quenched edge should skate a fresh file.\n6. Cryogenic (optional): -75 °C dry ice slurry, 1 hour. Transforms retained austenite.\n7. Temper: 175-230 °C, 1 hour, twice. Target 58-60 HRC for kitchen knife, 60-62 HRC for outdoor or tactical.\n\n**Tempering colors** (oxide layer visible after polish): pale straw 220 °C, dark straw 240 °C, brown 255 °C, purple 280 °C, dark blue 290 °C, pale blue 320 °C.",
        "related": ["alloy:aisi-1095", "temper:tempering-colors"],
        "sources": ["asm-v4"],
    },
    {
        "slug": "4140-ht",
        "title": "AISI 4140 heat treat", "symbol": "4140",
        "subtitle": "Quench and temper for chromoly alloy steel",
        "stats": [
            _stat("austenitizeTemp", "Austenitize", "845-870", "°C"),
            _stat("soakTime", "Soak", "30 min per 25 mm + 30 min", ""),
            _stat("quench", "Quench", "Oil (sections to 75 mm)", ""),
            _stat("asQuenchedHardness", "As-quenched", "58-60", "HRC max"),
            _stat("temperRange", "Temper range", "200-700", "°C"),
            _stat("hardenability", "Hardenability", "Deep (Jominy J24 ≈ 55 HRC at half depth)", ""),
        ],
        "tags": ["alloy steel", "oil quench", "deep hardening", "PHT"],
        "body": "Standard quench and temper. The molybdenum prevents temper embrittlement that can plague Cr alloy steels, which is why 4140 is the favorite alloy steel for through-hardened structural parts.\n\n**Tempering targets:**\n- 200 °C → 58 HRC (wear)\n- 315 °C → 50 HRC (high-strength shafting)\n- 425 °C → 42 HRC\n- 540 °C → 35 HRC (PHT condition, the as-purchased condition)\n- 650 °C → 25 HRC (high-toughness tempering)\n\n**Stress relief** of welded parts: 595-650 °C for 1 hr per 25 mm, slow furnace cool. Avoid 260-345 °C temper range, which gives lower toughness than either side (blue brittleness).",
        "related": ["alloy:aisi-4140"],
        "sources": ["asm-v4", "asm-htg"],
    },
    {
        "slug": "8620-carburize",
        "title": "AISI 8620 carburize-and-quench", "symbol": "8620",
        "subtitle": "Gas carburizing cycle for low-alloy gear and pin stock",
        "stats": [
            _stat("carburizeTemp", "Carburize", "900-925", "°C"),
            _stat("carburizeTime", "Time", "4-12", "hours for 0.5-1.5 mm case"),
            _stat("carburizeAtmosphere", "Atmosphere", "Endothermic, 0.8-1.0% C potential", ""),
            _stat("quench", "Quench", "Oil, agitated", ""),
            _stat("temperTemp", "Temper", "150-175", "°C"),
            _stat("caseHardness", "Case hardness", "58-62", "HRC"),
            _stat("coreHardness", "Core hardness", "32-38", "HRC"),
        ],
        "tags": ["carburizing", "case harden", "gears", "wear"],
        "body": "Gas carburizing in an endothermic atmosphere (a controlled mixture of CO, H₂, and N₂ from cracked natural gas) is the volume process for case-hardened parts. Carbon diffuses into the surface up to about 0.8-1.0% over hours at temperature; depth depends on the time-temperature integral.\n\n**Case depth rule of thumb**: 0.5 mm per 4 hours at 900 °C, 1.0 mm per 8 hours, 1.5 mm per 16 hours. Direct quench from the carburizing temperature gives the deepest case but most distortion; reheat-and-quench (slow cool from carburize, reheat to 850 °C, quench) gives finer grain and less distortion at the cost of a longer cycle.\n\n**Vacuum (low-pressure) carburizing** with acetylene and gas quench has become the premium alternative for clean parts and minimal distortion.",
        "related": ["alloy:aisi-8620"],
        "sources": ["asm-v4", "asm-htg"],
    },
    {
        "slug": "a2-cycle",
        "title": "A2 tool steel heat treat", "symbol": "A2",
        "subtitle": "Air-hardening cycle for cold-work tool steel",
        "stats": [
            _stat("preheatTemp", "Preheat", "760", "°C, equalize"),
            _stat("austenitizeTemp", "Austenitize", "940-980", "°C"),
            _stat("soakTime", "Soak", "15-30", "min at temperature"),
            _stat("quench", "Quench", "Still air or air blast", ""),
            _stat("asQuenchedHardness", "As-quenched", "62-64", "HRC"),
            _stat("temper", "Temper", "175-540", "°C, twice, 2 hr each"),
            _stat("dimensionalChange", "Dimensional change", "+0.0001 in/in (typ)", ""),
        ],
        "tags": ["tool steel", "air harden", "blanking dies", "dimensional stability"],
        "body": "Why A2 is loved by toolmakers: it air-hardens (no quench cracks), it grows just slightly on hardening (predictable, lockable into the design), and it tempers without distortion. Used for blanking dies, punches, forming dies, gauges.\n\n**Common targets after double temper:**\n- 200 °C → 60-62 HRC (blanking dies, gauges)\n- 425 °C → 56-58 HRC (forming dies, where toughness matters more)\n- 510 °C → 58-60 HRC (secondary hardening peak, best wear at moderate toughness)\n\n**Subzero treatment** at -75 °C between quench and first temper transforms retained austenite and gives slightly improved dimensional stability. Common for precision gauge work.",
        "related": ["alloy:tool-a2"],
        "sources": ["asm-v4", "asm-htg"],
    },
    {
        "slug": "d2-cycle",
        "title": "D2 tool steel heat treat", "symbol": "D2",
        "subtitle": "High-chromium cold-work cycle",
        "stats": [
            _stat("preheatTemp", "Preheat", "815-845", "°C"),
            _stat("austenitizeTemp", "Austenitize", "1010-1040", "°C"),
            _stat("soakTime", "Soak", "20-45", "min at temperature"),
            _stat("quench", "Quench", "Air or oil (oil for sections >50 mm)", ""),
            _stat("asQuenchedHardness", "As-quenched", "62-64", "HRC"),
            _stat("temperPrimary", "Primary temper", "175-230", "°C → 60-62 HRC"),
            _stat("temperSecondary", "Secondary temper", "490-540", "°C → 58-60 HRC"),
        ],
        "tags": ["tool steel", "high chromium", "wear resistant", "double temper"],
        "body": "Always double-temper D2; the chromium carbide system retains significant austenite from quench that transforms on first temper and needs the second temper to soften the freshly-formed martensite.\n\n**Distortion** is more than A2. Plan finish allowance of 0.002 to 0.004 inch on critical surfaces. **Surface finish** in EDM applications: D2 EDMs cleanly, polishes well, takes a mirror with care.\n\n**Cryogenic treatment** between quench and first temper is more impactful for D2 than for A2 because there's much more retained austenite to transform.",
        "related": ["alloy:tool-d2"],
        "sources": ["asm-v4", "asm-htg"],
    },
    {
        "slug": "o1-quench",
        "title": "O1 tool steel quench-and-temper", "symbol": "O1",
        "subtitle": "Oil-hardening cycle for general tool service",
        "stats": [
            _stat("austenitizeTemp", "Austenitize", "790-815", "°C"),
            _stat("soakTime", "Soak", "15-30", "min"),
            _stat("quench", "Quench", "Oil (medium speed, like Parks AAA)", ""),
            _stat("asQuenchedHardness", "As-quenched", "63-65", "HRC"),
            _stat("temperTemp", "Temper", "175-260", "°C → 58-62 HRC"),
            _stat("dimensionalChange", "Dimensional change", "+0.0002 to 0.0004 in/in", ""),
        ],
        "tags": ["tool steel", "oil quench", "general purpose", "machinable annealed"],
        "body": "The most-used tool steel for one-off shop tooling and hobbyist knife making. Machines easily in the annealed condition (around 92-95 HRB), then takes a predictable quench-and-temper to 58-62 HRC.\n\n**Distortion** is higher than A2 (some growth and some warp); not the best for thin precision parts but fine for solid tools, knives, broaches, and gauges where post-grind cleanup handles the change.",
        "related": ["alloy:tool-o1"],
        "sources": ["asm-v4", "asm-htg"],
    },
    {
        "slug": "17-4-h900",
        "title": "17-4 PH H900 aging", "symbol": "17-4 H900",
        "subtitle": "Precipitation hardening for 17-4 PH stainless",
        "stats": [
            _stat("solutionTemp", "Solution treat (Cond. A)", "1040", "°C"),
            _stat("solutionQuench", "Solution quench", "Air or oil", ""),
            _stat("ageTemp", "Age (H900)", "482", "°C"),
            _stat("ageTime", "Age time", "1", "hour"),
            _stat("ageCool", "Cool", "Air", ""),
            _stat("ultimateTensile", "Result", "1310", "MPa tensile, 44 HRC"),
        ],
        "tags": ["PH stainless", "aging", "aerospace", "Condition A"],
        "body": "17-4 PH is sold most often in **Condition A** (solution-treated, soft, machinable at 32-38 HRC). Aging takes it to final strength without distortion or quench. The H-number is the aging temperature in °F.\n\n**Aging matrix:**\n- H900 (482 °C, 1 hr) → 1310 MPa tensile, 44 HRC, lowest toughness\n- H925 (496 °C, 4 hr) → 1170 MPa, 42 HRC\n- H1025 (552 °C, 4 hr) → 1070 MPa, 38 HRC, balanced\n- H1075 (580 °C, 4 hr) → 1000 MPa, 36 HRC\n- H1150 (621 °C, 4 hr) → 930 MPa, 33 HRC, highest toughness\n- H1150-M (over-age, 760 °C 2 hr then 621 °C 4 hr) → highest toughness for thick sections\n\n**Stress corrosion cracking risk** rises sharply below H1025. For marine or chloride service, prefer H1075 or above.",
        "related": ["alloy:ss-17-4"],
        "sources": ["asm-v1", "asm-v4"],
    },
    {
        "slug": "tempering-colors",
        "title": "Tempering colors", "symbol": "color",
        "kind": "reference",
        "subtitle": "Visible oxide color as a temperature gauge for plain steels",
        "stats": [
            _stat("paleStraw", "Pale straw", "220", "°C"),
            _stat("darkStraw", "Dark straw", "240", "°C"),
            _stat("brown", "Brown", "255", "°C"),
            _stat("brownPurple", "Brown-purple", "270", "°C"),
            _stat("purple", "Purple", "280", "°C"),
            _stat("darkBlue", "Dark blue", "290", "°C"),
            _stat("midBlue", "Mid blue", "305", "°C"),
            _stat("paleBlue", "Pale blue", "320", "°C"),
            _stat("gray", "Gray", ">340", "°C"),
        ],
        "tags": ["reference", "tempering", "color chart", "without instruments"],
        "body": "Polish a clean steel surface bright, then heat in air. The oxide layer that forms is thin enough to produce interference colors, and the color depends on the layer thickness which in turn depends on the temperature reached. This is how tempering was done for centuries before pyrometers, and it still works.\n\n**Typical use:**\n- 220 to 250 °C (straws): edge tools, knives, taps and dies. 58-62 HRC.\n- 270 to 290 °C (purples): springs, drills, light hammers.\n- 290 to 320 °C (blues): heavier springs, screwdrivers, wrenches.\n- Beyond 320 °C: the colors fade to a uniform gray; use a thermometer.\n\n**Calibrate against a thermocouple** before relying on this; colors shift with surface finish, alloy content, and rate of heating. Stainless steels and aluminum bronzes form their own colors which do not map to this chart.",
        "related": ["temper:1095-knife"],
        "sources": ["asm-v4"],
    },
    {
        "slug": "quenchant-selection",
        "title": "Quenchant selection", "symbol": "quench",
        "kind": "selection-guide",
        "subtitle": "Picking the right quench medium for the job",
        "stats": [
            _stat("water", "Water (room temp)", "Fastest, severity ~1.0", ""),
            _stat("brine", "10% brine", "Faster than water, severity ~2.0", ""),
            _stat("fastOil", "Fast oil (Parks 50)", "Severity ~0.5, knife steels", ""),
            _stat("convOil", "Conventional oil", "Severity ~0.3, alloy steels", ""),
            _stat("polymer", "Polymer (PAG, 10-20%)", "Adjustable severity 0.3 to 0.8", ""),
            _stat("salt", "Hot salt (250-300 °C)", "Marquench, low distortion", ""),
            _stat("air", "Still air", "Severity ~0.02, A2/D2/HSS only", ""),
        ],
        "tags": ["reference", "quenching", "selection", "process"],
        "body": "The severity rating (H-value) is roughly the inverse of the surface heat-transfer coefficient at the critical 700 to 500 °C range. Faster quench gives more hardness on plain-carbon steels but more distortion and crack risk on geometries with thick-thin transitions.\n\n**Rules of practice:**\n- Plain-carbon steels under 25 mm need water or brine to fully harden. Above that, accept incomplete through-hardening.\n- Alloy steels (4140 family) hold themselves in oil to 75 mm easily, with much lower distortion.\n- Tool steels: A2/D2/M2 air-harden; O1/W1 need oil/water.\n- Stainless (martensitic 410, 420): air or oil.\n- For thin precision parts where distortion is the priority, **marquenching** (hot-salt quench to just above Ms, then air cool through the martensite range) cuts distortion roughly in half versus straight oil.\n\n**Polymer quenchants** (polyalkylene glycol) give adjustable severity by varying concentration; they have largely replaced petroleum oils in production for cleaner work environments.",
        "related": [],
        "sources": ["asm-v4", "asm-htg"],
    },
    {
        "slug": "stress-relief",
        "title": "Stress relief", "symbol": "SR",
        "kind": "process-card",
        "subtitle": "Removing residual stress without softening the part",
        "stats": [
            _stat("carbonSteel", "Carbon steel SR", "595-650", "°C, 1 hr per 25 mm"),
            _stat("alloySteel", "Alloy steel SR", "595-650", "°C, 1 hr per 25 mm"),
            _stat("toolSteel", "Tool steel SR (preharden)", "650-700", "°C"),
            _stat("aluminum", "Aluminum SR (T6 → T651)", "Stretched 1.5-3% post-quench", ""),
            _stat("austenitic", "Austenitic SS SR", "870-925", "°C (avoid 480-870 sensitization)"),
            _stat("cooling", "Cooling rate", "≤55 °C/hr to 315 °C, then air", ""),
        ],
        "tags": ["stress relief", "post weld", "process", "distortion control"],
        "body": "Most distortion problems in machined or welded parts come from locked-in residual stresses; relieving them costs one furnace cycle and saves rework. The temperature is below the lower critical temperature for steels, so the existing hardness is preserved.\n\n**Slow cool** is essential. Air cooling from stress-relief temperature can re-induce nearly as much stress as you just removed. Furnace cool to 315 °C, then still air to room temperature.\n\n**For carbon and alloy steels** that have been welded, this is a near-mandatory step for fatigue or precision-critical service. For tool steels in the prehardened state (4140 PHT, S7), stress relief after rough machining before finish machining holds tolerances on tight features.",
        "related": [],
        "sources": ["asm-v4"],
    },
]


def build_entry(spec):
    kind = spec.get("kind", "heat-treat-schedule")
    return {
        "id": f"temper:{spec['slug']}",
        "module": "temper",
        "kind": kind,
        "title": spec["title"],
        "symbol": spec.get("symbol", ""),
        "subtitle": spec.get("subtitle", ""),
        "tags": spec.get("tags", []),
        "stats": spec.get("stats", []),
        "body": spec.get("body", ""),
        "hazards": spec.get("hazards", []),
        "related": spec.get("related", []),
        "sources": spec.get("sources", ["asm-v4"]),
    }


def write_manifest_entries():
    manifest = json.loads(MANIFEST.read_text())
    slugs = [s["slug"] for s in SCHEDULES]
    for m in manifest["modules"]:
        if m["slug"] == "temper":
            m["entries"] = slugs
            m["status"] = "active"
            break
    MANIFEST.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    print(f"Manifest updated: temper declares {len(slugs)} entries.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    written = 0
    for spec in SCHEDULES:
        entry = build_entry(spec)
        path = DATA_DIR / f"{spec['slug']}.json"
        text = json.dumps(entry, indent=2, ensure_ascii=False) + "\n"
        if args.dry_run:
            print(f"  {'~' if path.exists() else '+'} {path.relative_to(ROOT)}")
        else:
            path.write_text(text)
        written += 1
    print(f"\nSeeded {written} temper files.")

    if not args.dry_run:
        write_manifest_entries()
    return 0


if __name__ == "__main__":
    sys.exit(main())
