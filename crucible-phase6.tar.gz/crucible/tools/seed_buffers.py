#!/usr/bin/env python3
"""
CRUCIBLE buffer seeder.

Generates modules/buffer/data/<slug>.json: buffer system reference cards
keyed by pKa, with acid and base form molecular weights, useful pH range,
and notes on temperature and ionic-strength sensitivity.

The H-H solver in modules/buffer/module.js reads these cards to drive
its recipe calculator.

Sources: Good et al. (1966), Merck Index, Sigma-Aldrich buffer references.
"""

import json
import sys
import argparse
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "modules" / "buffer" / "data"
MANIFEST = ROOT / "shared" / "data" / "manifest.json"


def _stat(key, label, value, unit, source="merck-index"):
    return {"key": key, "label": label, "value": value, "unit": unit, "source": source}


BUFFERS = [
    {
        "slug": "acetate", "title": "Acetate buffer",
        "symbol": "AcOH / AcO⁻",
        "subtitle": "Acetic acid / sodium acetate · pKa 4.76 · range 3.8 to 5.8",
        # Solver data
        "pKa": 4.76,
        "acidName": "acetic acid",
        "acidFormula": "CH₃COOH",
        "acidMW": 60.05,
        "acidIsLiquid": True, "acidDensity": 1.05, "acidPercent": 99.8,
        "baseName": "sodium acetate (anhydrous)",
        "baseFormula": "CH₃COONa",
        "baseMW": 82.03,
        "phMin": 3.8, "phMax": 5.8,
        "tags": ["acetate", "weak acid", "biology", "histology"],
        "body": "The classic weak-acid buffer system. pKa 4.76 at 25 °C. Used wherever a buffer in the acidic pH 4 to 6 range is needed: histology staining, enzymology of low-pH proteases (pepsin etc.), agarose gel running buffer (TAE uses acetate at pH 8.3 but the buffering is mostly from the Tris).\n\n**Temperature coefficient**: small, around -0.0002 pH/°C. Not a concern for routine work.\n\n**Trihydrate form** (CH₃COONa·3H₂O, MW 136.08) is also widely sold; if you use the trihydrate, scale the mass by 136.08/82.03 = 1.66."
    },
    {
        "slug": "phosphate", "title": "Phosphate buffer (Sørensen)",
        "symbol": "H₂PO₄⁻ / HPO₄²⁻",
        "subtitle": "Monosodium / disodium phosphate · pKa 7.20 · range 6.2 to 8.2",
        "pKa": 7.20,
        "acidName": "sodium dihydrogen phosphate (anhydrous)",
        "acidFormula": "NaH₂PO₄",
        "acidMW": 119.98,
        "acidIsLiquid": False,
        "baseName": "disodium hydrogen phosphate (anhydrous)",
        "baseFormula": "Na₂HPO₄",
        "baseMW": 141.96,
        "phMin": 6.2, "phMax": 8.2,
        "tags": ["phosphate", "biology", "physiological", "PBS"],
        "body": "Phosphoric acid has three pKas: 2.15, 7.20, 12.35. The middle one is right at physiological pH 7.4, which is why phosphate buffer is the default for cell biology and biochemistry. **PBS** (phosphate-buffered saline) is 137 mM NaCl + 2.7 mM KCl + 10 mM phosphate at pH 7.4.\n\n**Limitations**: precipitates with divalent cations (Ca²⁺, Mg²⁺ phosphates are insoluble); inhibits some enzymes; cell-killing osmolyte if used too concentrated. Tris or HEPES are sometimes preferred when those matter.\n\n**Common forms**: anhydrous, monohydrate (Na₂HPO₄·H₂O 138.0), dihydrate (Na₂HPO₄·2H₂O 156.0), heptahydrate (Na₂HPO₄·7H₂O 268.1), dodecahydrate (Na₂HPO₄·12H₂O 358.1). The decahydrate is the most common form sold for buffer prep but the anhydrous is the cleaner calculation."
    },
    {
        "slug": "tris-hcl", "title": "Tris-HCl buffer",
        "symbol": "Tris / Tris·HCl",
        "subtitle": "Tris(hydroxymethyl)aminomethane · pKa 8.06 · range 7.0 to 9.0",
        "pKa": 8.06,
        "acidName": "Tris·HCl (Tris hydrochloride)",
        "acidFormula": "C₄H₁₂NO₃Cl",
        "acidMW": 157.60,
        "acidIsLiquid": False,
        "baseName": "Tris base",
        "baseFormula": "C₄H₁₁NO₃",
        "baseMW": 121.14,
        "phMin": 7.0, "phMax": 9.0,
        "tags": ["Tris", "biology", "molecular biology", "electrophoresis"],
        "body": "The default buffer of molecular biology. Used in PCR, SDS-PAGE running buffer, agarose gels (TAE = Tris-acetate-EDTA, TBE = Tris-borate-EDTA), and protein extraction.\n\n**Strong temperature coefficient**: about -0.028 pH/°C. A Tris buffer adjusted to pH 8.0 at 25 °C reads pH 7.7 at 37 °C and pH 8.6 at 4 °C. Always pH-calibrate at the working temperature.\n\n**Preparation**: dissolve Tris base in water, adjust to target pH with HCl. The conventional recipe gives Tris-HCl rather than mixing the two solid forms.\n\n**Limitations**: reacts with aldehydes (don't use with glutaraldehyde fixatives), penetrates cell membranes (good for some assays, bad for others), interferes with some protein assays (Bradford works, Lowry doesn't)."
    },
    {
        "slug": "citrate", "title": "Citrate buffer",
        "symbol": "Citric acid / Na₃ citrate",
        "subtitle": "Citric acid · pKa1 3.13, pKa2 4.76, pKa3 6.40 · range 3 to 7",
        "pKa": 4.76,
        "acidName": "citric acid (monohydrate)",
        "acidFormula": "C₆H₈O₇·H₂O",
        "acidMW": 210.14,
        "acidIsLiquid": False,
        "baseName": "trisodium citrate (dihydrate)",
        "baseFormula": "C₆H₅Na₃O₇·2H₂O",
        "baseMW": 294.10,
        "phMin": 3.0, "phMax": 6.2,
        "tags": ["citrate", "triprotic", "food", "antigen retrieval"],
        "body": "Triprotic acid (three pKas: 3.13, 4.76, 6.40), gives buffering across most of the acid pH range. Common in food (citric acid is GRAS, gives the tart in soft drinks), in histology (citrate buffer pH 6.0 for antigen retrieval in IHC), and in anti-coagulant blood collection (sodium citrate sequesters Ca²⁺).\n\nUse pKa 4.76 for general 3.5 to 6 buffering. The solver here treats citrate as a single-pKa system; for precise work near the pKa transitions, look at full speciation models."
    },
    {
        "slug": "carbonate", "title": "Carbonate / bicarbonate",
        "symbol": "HCO₃⁻ / CO₃²⁻",
        "subtitle": "Sodium bicarbonate / sodium carbonate · pKa 10.33 · range 9.3 to 11.3",
        "pKa": 10.33,
        "acidName": "sodium bicarbonate",
        "acidFormula": "NaHCO₃",
        "acidMW": 84.01,
        "acidIsLiquid": False,
        "baseName": "sodium carbonate (anhydrous)",
        "baseFormula": "Na₂CO₃",
        "baseMW": 105.99,
        "phMin": 9.3, "phMax": 11.3,
        "tags": ["carbonate", "alkaline", "ELISA coating", "open to air"],
        "body": "Alkaline buffer for the 9 to 11 pH range. **Coating buffer** for ELISA plates is typically 0.05 M carbonate at pH 9.6, which protonates and adheres antibodies to the polystyrene well surface.\n\n**Open to air, this buffer drifts.** CO₂ from atmosphere dissolves and forms more carbonic acid, lowering the pH. For precise work, use sealed vessels or freshly degassed water."
    },
    {
        "slug": "mes", "title": "MES buffer",
        "symbol": "MES",
        "subtitle": "2-(N-morpholino)ethanesulfonic acid · pKa 6.10 · Good's buffer",
        "pKa": 6.10,
        "acidName": "MES (free acid)",
        "acidFormula": "C₆H₁₃NO₄S",
        "acidMW": 195.24,
        "acidIsLiquid": False,
        "baseName": "MES sodium salt",
        "baseFormula": "C₆H₁₂NNaO₄S",
        "baseMW": 217.22,
        "phMin": 5.5, "phMax": 6.7,
        "tags": ["Good's buffer", "biological", "low temp coeff", "plant tissue culture"],
        "body": "One of Norman Good's twelve original biological buffers (Good et al., 1966), designed to fill gaps in biologically inert buffering. **Minimal temperature coefficient**, low metal binding, doesn't cross cell membranes, doesn't absorb in the UV.\n\nThe go-to pH 6 buffer for plant tissue culture (Murashige and Skoog medium), some enzymology, and capillary electrophoresis. **Bring to pH** with NaOH from the free acid form, or with HCl from the sodium salt."
    },
    {
        "slug": "mops", "title": "MOPS buffer",
        "symbol": "MOPS",
        "subtitle": "3-(N-morpholino)propanesulfonic acid · pKa 7.20 · Good's buffer",
        "pKa": 7.20,
        "acidName": "MOPS (free acid)",
        "acidFormula": "C₇H₁₅NO₄S",
        "acidMW": 209.26,
        "acidIsLiquid": False,
        "baseName": "MOPS sodium salt",
        "baseFormula": "C₇H₁₄NNaO₄S",
        "baseMW": 231.24,
        "phMin": 6.5, "phMax": 7.9,
        "tags": ["Good's buffer", "biological", "RNA gels", "low temp coeff"],
        "body": "One pKa unit above MES, in the same morpholine family. **Standard running buffer for denaturing RNA gels** (MOPS plus formaldehyde). Same advantages as MES: biologically inert, low temperature coefficient, no UV absorbance."
    },
    {
        "slug": "hepes", "title": "HEPES buffer",
        "symbol": "HEPES",
        "subtitle": "4-(2-hydroxyethyl)-1-piperazineethanesulfonic acid · pKa 7.55",
        "pKa": 7.55,
        "acidName": "HEPES (free acid)",
        "acidFormula": "C₈H₁₈N₂O₄S",
        "acidMW": 238.30,
        "acidIsLiquid": False,
        "baseName": "HEPES sodium salt",
        "baseFormula": "C₈H₁₇N₂NaO₄S",
        "baseMW": 260.29,
        "phMin": 6.8, "phMax": 8.2,
        "tags": ["Good's buffer", "biological", "cell culture", "physiological"],
        "body": "The default buffer for cell culture media when CO₂/bicarbonate alone can't hold the pH (open dishes, microscopy chambers). Holds physiological pH 7.2 to 7.4 stably across reasonable temperature swings.\n\n**Generates radicals** under intense visible or UV light, which can be a problem in long-exposure live-cell microscopy. Substitute or supplement with reducing scavengers if you see photodamage."
    },
]


def build_entry(spec):
    stats = [
        _stat("pKa", "pKa (25 °C)", spec["pKa"], ""),
        _stat("phRange", "Useful pH range", f"{spec['phMin']} to {spec['phMax']}", ""),
        _stat("acidForm", "Acid form", spec["acidFormula"], ""),
        _stat("acidMW", "Acid MW", spec["acidMW"], "g/mol"),
        _stat("baseForm", "Conjugate base", spec["baseFormula"], ""),
        _stat("baseMW", "Base MW", spec["baseMW"], "g/mol"),
    ]
    # Top-level fields that the solver consumes
    return {
        "id": f"buffer:{spec['slug']}",
        "module": "buffer",
        "kind": "buffer-recipe",
        "title": spec["title"],
        "symbol": spec.get("symbol", ""),
        "subtitle": spec.get("subtitle", ""),
        "pKa": spec["pKa"],
        "phMin": spec["phMin"],
        "phMax": spec["phMax"],
        "acidName": spec["acidName"],
        "acidFormula": spec["acidFormula"],
        "acidMW": spec["acidMW"],
        "acidIsLiquid": spec.get("acidIsLiquid", False),
        "acidDensity": spec.get("acidDensity"),
        "acidPercent": spec.get("acidPercent"),
        "baseName": spec["baseName"],
        "baseFormula": spec["baseFormula"],
        "baseMW": spec["baseMW"],
        "tags": spec.get("tags", []),
        "stats": stats,
        "body": spec.get("body", ""),
        "hazards": spec.get("hazards", []),
        "related": spec.get("related", []),
        "sources": spec.get("sources", ["merck-index"]),
    }


def write_manifest_entries():
    manifest = json.loads(MANIFEST.read_text())
    slugs = [s["slug"] for s in BUFFERS]
    for m in manifest["modules"]:
        if m["slug"] == "buffer":
            m["entries"] = slugs
            m["status"] = "active"
            m["customView"] = True
            break
    MANIFEST.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    print(f"Manifest updated: buffer declares {len(slugs)} entries, customView=true.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    written = 0
    for spec in BUFFERS:
        entry = build_entry(spec)
        path = DATA_DIR / f"{spec['slug']}.json"
        text = json.dumps(entry, indent=2, ensure_ascii=False) + "\n"
        if args.dry_run:
            print(f"  {'~' if path.exists() else '+'} {path.relative_to(ROOT)}")
        else:
            path.write_text(text)
        written += 1
    print(f"\nSeeded {written} buffer files.")
    if not args.dry_run:
        write_manifest_entries()
    return 0


if __name__ == "__main__":
    sys.exit(main())
