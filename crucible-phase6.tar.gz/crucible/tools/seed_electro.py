#!/usr/bin/env python3
"""
CRUCIBLE electrochemistry seeder.

Generates modules/electro/data/<slug>.json: standard reduction potentials,
galvanic series in seawater, sacrificial anodes, plating baths, anodize
baths, electroless nickel.

Sources: Vanýsek (CRC Electrochemical Series), ASM Vol. 13 (Corrosion),
manufacturer plating handbooks.
"""

import json
import sys
import argparse
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "modules" / "electro" / "data"
MANIFEST = ROOT / "shared" / "data" / "manifest.json"


def _stat(key, label, value, unit, source="asm-v13"):
    return {"key": key, "label": label, "value": value, "unit": unit, "source": source}


ENTRIES = [
    # =================== REFERENCE TABLES ===================
    {
        "slug": "galvanic-series", "title": "Galvanic series in seawater",
        "symbol": "galvanic",
        "kind": "electro-reference",
        "subtitle": "Practical engineering ordering of metals from active to noble · vs SCE",
        "stats": [
            _stat("magnesium", "Magnesium", "-1.65 to -1.55", "V vs SCE"),
            _stat("zinc", "Zinc", "-1.05 to -1.00", "V vs SCE"),
            _stat("alAlloys", "Al alloys (5052, 6061)", "-0.85", "V vs SCE"),
            _stat("alHighStr", "Al alloys (2024, 7075)", "-0.70", "V vs SCE"),
            _stat("cadmium", "Cadmium plating", "-0.70", "V vs SCE"),
            _stat("mildSteel", "Mild steel, cast iron", "-0.65 to -0.55", "V vs SCE"),
            _stat("ss304Active", "304 stainless (active)", "-0.50", "V vs SCE"),
            _stat("ss316Active", "316 stainless (active)", "-0.45", "V vs SCE"),
            _stat("leadTin", "Lead, tin, Sn-Pb solder", "-0.45", "V vs SCE"),
            _stat("brass", "Brass, copper, bronze", "-0.30 to -0.25", "V vs SCE"),
            _stat("nickel", "Nickel, Monel", "-0.15", "V vs SCE"),
            _stat("ss304Passive", "304 stainless (passive)", "-0.08", "V vs SCE"),
            _stat("ss316Passive", "316 stainless (passive)", "-0.05", "V vs SCE"),
            _stat("silver", "Silver", "-0.05", "V vs SCE"),
            _stat("titanium", "Titanium, Hastelloy", "0.00", "V vs SCE"),
            _stat("inconel", "Inconel 625", "0.00 to +0.05", "V vs SCE"),
            _stat("graphiteAuPt", "Graphite, gold, platinum", "+0.25 to +0.30", "V vs SCE"),
        ],
        "tags": ["galvanic", "corrosion", "couple", "seawater", "reference"],
        "body": "The engineering ordering of metals by their open-circuit potential in flowing seawater versus a saturated calomel electrode (SCE). When two dissimilar metals are electrically connected and bathed by the same electrolyte, the more active (lower number) metal becomes the **anode** and corrodes preferentially; the more noble (higher number) metal becomes the **cathode** and is protected.\n\n**Stainless steels carry two entries** because they exist in two states. The **passive** state, with a stable Cr-rich oxide film, is much more noble (around -0.05 V). Under continuous wetting in chlorides, under crevice conditions, or under low-oxygen mud burial, the film breaks down and the steel becomes **active** with a potential more similar to mild steel. Designing against galvanic corrosion always uses the active value to be safe.\n\n**Voltage differences and severity** for a coupled pair in seawater:\n- Under 50 mV: no significant galvanic action expected\n- 50 to 150 mV: monitor; isolate for long exposures or critical service\n- 150 to 300 mV: moderate to severe corrosion of the anode; isolate or protect\n- Over 300 mV: aggressive attack; avoid the couple or apply cathodic protection",
        "related": [],
        "sources": ["asm-v13"],
    },
    {
        "slug": "standard-potentials", "title": "Standard reduction potentials",
        "symbol": "E°",
        "kind": "electro-reference",
        "subtitle": "Selected E° values vs SHE at 25 °C, 1 M activity",
        "stats": [
            _stat("li", "Li⁺ + e⁻ → Li", "-3.04", "V"),
            _stat("k", "K⁺ + e⁻ → K", "-2.93", "V"),
            _stat("ca", "Ca²⁺ + 2e⁻ → Ca", "-2.87", "V"),
            _stat("na", "Na⁺ + e⁻ → Na", "-2.71", "V"),
            _stat("mg", "Mg²⁺ + 2e⁻ → Mg", "-2.37", "V"),
            _stat("al", "Al³⁺ + 3e⁻ → Al", "-1.66", "V"),
            _stat("ti", "Ti²⁺ + 2e⁻ → Ti", "-1.63", "V"),
            _stat("zn", "Zn²⁺ + 2e⁻ → Zn", "-0.76", "V"),
            _stat("cr", "Cr³⁺ + 3e⁻ → Cr", "-0.74", "V"),
            _stat("fe2", "Fe²⁺ + 2e⁻ → Fe", "-0.44", "V"),
            _stat("ni", "Ni²⁺ + 2e⁻ → Ni", "-0.25", "V"),
            _stat("sn", "Sn²⁺ + 2e⁻ → Sn", "-0.14", "V"),
            _stat("pb", "Pb²⁺ + 2e⁻ → Pb", "-0.13", "V"),
            _stat("h", "2H⁺ + 2e⁻ → H₂", "0.00", "V (reference)"),
            _stat("cu2", "Cu²⁺ + 2e⁻ → Cu", "+0.34", "V"),
            _stat("cu1", "Cu⁺ + e⁻ → Cu", "+0.52", "V"),
            _stat("fe3", "Fe³⁺ + e⁻ → Fe²⁺", "+0.77", "V"),
            _stat("ag", "Ag⁺ + e⁻ → Ag", "+0.80", "V"),
            _stat("o2", "O₂ + 4H⁺ + 4e⁻ → 2H₂O", "+1.23", "V"),
            _stat("cl2", "Cl₂ + 2e⁻ → 2Cl⁻", "+1.36", "V"),
            _stat("au", "Au³⁺ + 3e⁻ → Au", "+1.50", "V"),
            _stat("f2", "F₂ + 2e⁻ → 2F⁻", "+2.87", "V"),
        ],
        "tags": ["standard potentials", "thermodynamics", "SHE", "reference"],
        "body": "Standard reduction potentials at 25 °C, unit activity, vs the standard hydrogen electrode (SHE). These are thermodynamic values; the **galvanic series** in seawater is the practical engineering analog that captures real surface effects (oxide films, dissolved oxygen, ion concentrations).\n\nReversing the sign and adding gives a cell voltage: for Zn|Zn²⁺‖Cu²⁺|Cu, E_cell = E°_Cu - E°_Zn = 0.34 - (-0.76) = 1.10 V (the classic Daniell cell).\n\n**Sign convention**: E° as written is the reduction half-reaction. Larger positive E° means stronger oxidizing agent (more eager to gain electrons). Smaller (more negative) E° means stronger reducing agent.\n\n**SCE conversion**: V vs SCE = V vs SHE - 0.241 V at 25 °C.",
        "related": ["electro:galvanic-series"],
        "sources": ["vanysek", "crc-104"],
    },

    # =================== SACRIFICIAL ANODES ===================
    {
        "slug": "sacrificial-zinc", "title": "Zinc sacrificial anode",
        "symbol": "Zn anode",
        "kind": "sacrificial-anode",
        "subtitle": "Standard marine sacrificial anode · ASTM B418 · saltwater",
        "stats": [
            _stat("composition", "Composition", "Zn 99.99 + traces (Al, Cd, Fe)", "% min"),
            _stat("potential", "Open-circuit potential", "-1.05", "V vs SCE"),
            _stat("driveTo", "Drives steel to", "-0.80", "V vs SCE (typ)"),
            _stat("capacity", "Theoretical capacity", 820, "A·h/kg"),
            _stat("actualCapacity", "Practical capacity", "780", "A·h/kg"),
            _stat("useIn", "Use in", "seawater, brackish water (NaCl > 0.5%)", ""),
        ],
        "tags": ["sacrificial anode", "marine", "zinc", "ASTM B418"],
        "body": "The default sacrificial anode for steel hulls, propeller shafts, rudders, ballast tanks, and seawater piping in marine and offshore service. Bolted or welded to the structure, electrically connected, and replaced when about 60% consumed (typically every 2 to 5 years depending on current demand).\n\n**Does not work in freshwater**: the zinc oxide film that forms in low-chloride water passivates the surface and stops the current. For freshwater service, switch to magnesium anodes.",
        "related": ["element:zn", "alloy:al-5052"],
        "sources": ["asm-v13"],
    },
    {
        "slug": "sacrificial-magnesium", "title": "Magnesium sacrificial anode",
        "symbol": "Mg anode",
        "kind": "sacrificial-anode",
        "subtitle": "Freshwater and soil sacrificial anode · ASTM B843 · water heaters",
        "stats": [
            _stat("composition", "Composition", "Mg AZ63 or pure Mg with Al, Zn, Mn", ""),
            _stat("potential", "Open-circuit potential", "-1.65", "V vs SCE"),
            _stat("driveTo", "Drives steel to", "-0.85", "V vs SCE (target)"),
            _stat("capacity", "Theoretical capacity", 2200, "A·h/kg"),
            _stat("actualCapacity", "Practical capacity", "1100", "A·h/kg (typical, 50% eff)"),
            _stat("useIn", "Use in", "freshwater, soil, low-resistivity media", ""),
        ],
        "tags": ["sacrificial anode", "freshwater", "water heater", "buried pipeline", "soil"],
        "body": "The most negative practical sacrificial metal. Used in domestic hot water tanks (the 'anode rod'), buried steel water lines, and freshwater piers. Capacity per kilogram is more than double zinc but practical efficiency is lower (around 50%) due to a side reaction with water that wastes some current.\n\n**Replace the water heater anode rod every 3 to 5 years.** Without it, the tank corrodes from the inside. Pulling and inspecting an anode rod is the cheapest preventive maintenance task on a water heater.",
        "related": ["element:mg"],
        "sources": ["asm-v13"],
    },
    {
        "slug": "sacrificial-aluminum", "title": "Aluminum-zinc-indium anode",
        "symbol": "Al-Zn-In",
        "kind": "sacrificial-anode",
        "subtitle": "Modern offshore sacrificial anode · NACE TM0190 · saltwater",
        "stats": [
            _stat("composition", "Composition", "Al 95+ · Zn 3 to 6 · In 0.01 to 0.04", "%"),
            _stat("potential", "Open-circuit potential", "-1.10", "V vs SCE"),
            _stat("driveTo", "Drives steel to", "-0.85", "V vs SCE"),
            _stat("capacity", "Practical capacity", "2400 to 2700", "A·h/kg"),
            _stat("useIn", "Use in", "saltwater (chloride-rich)", ""),
        ],
        "tags": ["sacrificial anode", "offshore", "Al-Zn-In", "marine"],
        "body": "Higher capacity per kilogram than either zinc or magnesium, the volume choice for large structures (offshore platforms, ship hulls, large piers) where anode weight and ROV replacement cost dominate. Indium prevents the aluminum from passivating in seawater so the anode stays active throughout its life."
    },

    # =================== PLATING BATHS ===================
    {
        "slug": "nickel-sulfamate", "title": "Nickel sulfamate plating bath",
        "symbol": "Ni plate",
        "kind": "plating-bath",
        "subtitle": "Low-stress nickel electroplating · electroforming and structural plating",
        "stats": [
            _stat("nickel", "Ni(NH₂SO₃)₂·4H₂O", "300 to 600", "g/L"),
            _stat("nickelChloride", "NiCl₂·6H₂O", "0 to 15", "g/L (anode activator)"),
            _stat("boricAcid", "H₃BO₃", "30 to 45", "g/L (pH buffer)"),
            _stat("ph", "pH", "3.5 to 4.5", ""),
            _stat("temperature", "Temperature", "32 to 60", "°C"),
            _stat("currentDensity", "Current density", "1 to 10", "A/dm²"),
            _stat("residualStress", "Deposit stress", "<70", "MPa (low)"),
        ],
        "tags": ["nickel plating", "electroforming", "Watts alternative", "low stress"],
        "body": "The premium nickel plating bath when low residual stress matters: electroforming, repair plating of worn or oversize bores, structural plating for aerospace. **Watts bath** (nickel sulfate, NiCl₂, boric acid) is cheaper but deposits with high tensile stress that limits thickness before cracking.\n\nAnodes are pure nickel rounds in titanium or polypropylene baskets; the bath maintains nickel concentration by anode dissolution. Brighteners and wetting agents are added per the supplier's spec for a specific surface finish.",
        "related": ["element:ni"],
        "sources": ["asm-v13"],
    },
    {
        "slug": "copper-sulfate-acid", "title": "Acid copper sulfate plating",
        "symbol": "Cu plate",
        "kind": "plating-bath",
        "subtitle": "Bright acid copper · PCB through-hole and decorative · ductile bright deposit",
        "stats": [
            _stat("copperSulfate", "CuSO₄·5H₂O", "180 to 240", "g/L"),
            _stat("sulfuricAcid", "H₂SO₄", "50 to 75", "g/L"),
            _stat("chloride", "Cl⁻", "50 to 100", "mg/L (critical)"),
            _stat("temperature", "Temperature", "20 to 30", "°C"),
            _stat("currentDensity", "Current density", "2 to 5", "A/dm² (DC), higher for pulse plating"),
            _stat("anode", "Anode", "phosphorized copper bars", ""),
        ],
        "tags": ["copper plating", "PCB", "through-hole", "decorative"],
        "body": "Most common copper plating bath. Dominates PCB through-hole and via plating, decorative copper underplates, and copper-on-aluminum bus heat sinks. **Chloride must be in the narrow 50 to 100 ppm window**: too little gives anode polarization and uneven deposits; too much gives roughness.\n\nProprietary brighteners (typically polyether levelers, sulfur-containing brighteners) determine deposit grain refinement and throwing power. PCB plating uses tightly specified brightener mixes that the bath supplier maintains and tests.",
        "related": ["element:cu"],
        "sources": ["asm-v13"],
    },
    {
        "slug": "hard-chrome", "title": "Hard chrome plating",
        "symbol": "HC chrome",
        "kind": "plating-bath",
        "subtitle": "Hexavalent chromic acid bath · hydraulic rods, mold cavities, journal repair",
        "stats": [
            _stat("chromicAcid", "CrO₃", "150 to 400", "g/L"),
            _stat("sulfate", "SO₄²⁻", "1.5 to 4", "g/L (CrO₃ : SO₄ = 100:1 typ)"),
            _stat("temperature", "Temperature", "45 to 65", "°C"),
            _stat("currentDensity", "Current density", "30 to 60", "A/dm²"),
            _stat("hardness", "Deposit hardness", "850 to 1050", "HV"),
            _stat("efficiency", "Cathode efficiency", "10 to 20", "%"),
        ],
        "tags": ["hard chrome", "hexavalent chromium", "wear surface", "hydraulic"],
        "body": "The standard wear-surface plating: 850 to 1050 HV (about 65 to 70 HRC equivalent), low coefficient of friction, excellent corrosion resistance, machinable by grinding. Used on hydraulic and pneumatic rods, mold cavities, printing rolls, and to repair worn bearing journals (then ground to size).\n\n**Hexavalent chromium (Cr(VI)) is highly carcinogenic.** The bath generates a chromic acid mist that requires push-pull ventilation and PPE. Workers in chrome shops have markedly elevated lung cancer risk. **Trivalent (Cr(III)) chrome processes** are replacing hex chrome for decorative service but trivalent does not yet match the wear and corrosion performance of hex chrome for the heavy industrial applications.",
        "hazards": ["hexavalent chromium", "carcinogen", "fume hood"],
        "related": ["element:cr"],
        "sources": ["asm-v13"],
    },

    # =================== ANODIZING ===================
    {
        "slug": "type-ii-anodize", "title": "Type II sulfuric anodize",
        "symbol": "Type II",
        "kind": "anodize-bath",
        "subtitle": "Standard sulfuric acid anodize · MIL-A-8625 Type II · architectural and decorative",
        "stats": [
            _stat("electrolyte", "Bath", "H₂SO₄ 15 to 20% by volume", ""),
            _stat("temperature", "Temperature", 21, "°C ±2"),
            _stat("voltage", "Voltage", "12 to 22", "V"),
            _stat("currentDensity", "Current density", "1.5", "A/dm² typ"),
            _stat("thickness", "Coating thickness", "5 to 25", "μm"),
            _stat("color", "Color", "clear or dyed", ""),
            _stat("dimensionalChange", "Dimensional change", "half coating thickness inward", ""),
        ],
        "tags": ["anodize", "Type II", "sulfuric", "aluminum", "MIL-A-8625"],
        "body": "The volume aluminum finishing process. Grows an Al₂O₃ porous oxide layer that is much harder than the base aluminum (about 200 to 400 HV), corrosion resistant, and can be dyed (the porous structure absorbs aniline dyes which are sealed in by a hot DI water or nickel acetate dip).\n\n**Dimensional change**: half the coating thickness grows outward, half inward. For a 10 μm coating, the part grows 5 μm per face. **Threaded features** lose pitch diameter equal to the full coating thickness times 1.5 (because the angle is 60°). Plan threads accordingly or mask them off.\n\nSurface preparation matters: alkaline degrease (NaOH 5 to 10%), de-smut (HNO₃ rinse), anodize, dye if needed, seal."
    },
    {
        "slug": "hard-anodize", "title": "Hard anodize (Type III)",
        "symbol": "Type III",
        "kind": "anodize-bath",
        "subtitle": "Thick sulfuric anodize · MIL-A-8625 Type III · 50 to 100 μm engineering coating",
        "stats": [
            _stat("electrolyte", "Bath", "H₂SO₄ 10 to 15% by volume", ""),
            _stat("temperature", "Temperature", "-5 to 5", "°C (refrigerated)"),
            _stat("voltage", "Voltage", "40 to 80", "V (ramped)"),
            _stat("currentDensity", "Current density", "2 to 5", "A/dm²"),
            _stat("thickness", "Coating thickness", "25 to 150", "μm"),
            _stat("hardness", "Coating hardness", "350 to 500", "HV (60 HRC equiv)"),
            _stat("color", "Color", "dark gray to black (intrinsic)", ""),
        ],
        "tags": ["anodize", "Type III", "hard anodize", "wear surface", "engineering"],
        "body": "The engineering anodize. Coating is much thicker than Type II, much harder, much darker (gray to nearly black without dye, from interstitial sulfate inclusions in the cold electrolyte). Used on aluminum that needs to wear: pistons, valves, hydraulic spools, gears, slide surfaces.\n\n**The cold bath is the key.** Standard anodize at room temperature dissolves the oxide almost as fast as it forms above about 25 μm thickness. Refrigerated electrolyte (around 0 °C) suppresses dissolution and lets the coating grow indefinitely.\n\n**Skip sealing for wear surfaces.** Sealed Type III is more corrosion resistant; unsealed Type III is more wear resistant because it holds lubricant better in the porous structure."
    },

    # =================== ELECTROLESS ===================
    {
        "slug": "electroless-nickel", "title": "Electroless nickel-phosphorus",
        "symbol": "EN Ni-P",
        "kind": "plating-bath",
        "subtitle": "Autocatalytic Ni-P · uniform deposit on complex geometry · no current needed",
        "stats": [
            _stat("composition", "Bath", "NiSO₄ + NaH₂PO₂ + complexant + stabilizer", ""),
            _stat("phosphorusLow", "Low-P deposit", "1 to 3", "% P, hardness 700 HV (as-plated)"),
            _stat("phosphorusMed", "Medium-P deposit", "5 to 9", "% P, common engineering"),
            _stat("phosphorusHigh", "High-P deposit", "10 to 13", "% P, max corrosion resistance"),
            _stat("temperature", "Temperature", "85 to 95", "°C"),
            _stat("rate", "Deposition rate", "10 to 25", "μm/hr"),
            _stat("hardness", "As-plated hardness", "550 to 700", "HV"),
            _stat("hardenedHardness", "After bake (400 °C, 1 h)", "950 to 1050", "HV"),
        ],
        "tags": ["electroless", "Ni-P", "uniform coating", "autocatalytic"],
        "body": "The chemistry deposits nickel-phosphorus alloy from solution by a redox reaction; no electric current is applied. The deposit has **perfectly uniform thickness regardless of geometry**: inside threads, blind holes, complex shapes all get the same coating thickness. This is unique among metal-finishing processes.\n\n**Phosphorus content controls properties**:\n- Low P (1 to 3%): hardest as-plated, magnetic, less corrosion resistant\n- Medium P (5 to 9%): most common engineering choice, slight magnetism\n- High P (10 to 13%): non-magnetic, best corrosion resistance, slightly softer as-plated\n\n**Post-bake** at 350 to 400 °C for 1 hour precipitates Ni₃P and roughly doubles hardness, equaling hard chrome (about 1000 HV) but with the EN uniformity advantage. Standard finish for oilfield service, food processing, magnetic-storage components, and aerospace structural fasteners."
    },
]


def build_entry(spec):
    return {
        "id": f"electro:{spec['slug']}",
        "module": "electro",
        "kind": spec.get("kind", "electro-reference"),
        "title": spec["title"],
        "symbol": spec.get("symbol", ""),
        "subtitle": spec.get("subtitle", ""),
        "tags": spec.get("tags", []),
        "stats": spec.get("stats", []),
        "body": spec.get("body", ""),
        "hazards": spec.get("hazards", []),
        "related": spec.get("related", []),
        "sources": spec.get("sources", ["asm-v13"]),
    }


def write_manifest_entries():
    manifest = json.loads(MANIFEST.read_text())
    slugs = [s["slug"] for s in ENTRIES]
    for m in manifest["modules"]:
        if m["slug"] == "electro":
            m["entries"] = slugs
            m["status"] = "active"
            m["customView"] = True
            break
    MANIFEST.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    print(f"Manifest updated: electro declares {len(slugs)} entries, customView=true.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    written = 0
    for spec in ENTRIES:
        entry = build_entry(spec)
        path = DATA_DIR / f"{spec['slug']}.json"
        text = json.dumps(entry, indent=2, ensure_ascii=False) + "\n"
        if args.dry_run:
            print(f"  {'~' if path.exists() else '+'} {path.relative_to(ROOT)}")
        else:
            path.write_text(text)
        written += 1
    print(f"\nSeeded {written} electro files.")
    if not args.dry_run:
        write_manifest_entries()
    return 0


if __name__ == "__main__":
    sys.exit(main())
