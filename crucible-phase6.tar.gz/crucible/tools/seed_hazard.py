#!/usr/bin/env python3
"""
CRUCIBLE hazard seeder.

Generates modules/hazard/data/<slug>.json: shop safety reference cards
covering NFPA 704 (the fire diamond), GHS pictograms, DOT placards,
chemical incompatibility, spill response, PPE selection, and emergency
shower/eyewash use.

These are quick-reference summaries. A full SDS (Safety Data Sheet) for
the specific material in hand is still the authority before any actual
emergency response.

Sources: NFPA 704, GHS Rev. 10, 49 CFR 172, OSHA 29 CFR 1910, ANSI Z358.1.
"""

import json
import sys
import argparse
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "modules" / "hazard" / "data"
MANIFEST = ROOT / "shared" / "data" / "manifest.json"


def _stat(key, label, value, unit, source="nfpa-704"):
    return {"key": key, "label": label, "value": value, "unit": unit, "source": source}


ENTRIES = [
    {
        "slug": "nfpa-704", "title": "NFPA 704 fire diamond",
        "symbol": "◆",
        "kind": "safety-reference",
        "subtitle": "Four-quadrant placard for emergency responders · health, fire, instability, special",
        "stats": [
            _stat("blue", "Blue (left): Health", "0 normal · 1 slight · 2 moderate · 3 serious · 4 deadly", ""),
            _stat("red", "Red (top): Fire", "0 won't burn · 1 above 200 °F · 2 above 100 °F · 3 below 100 °F · 4 below 73 °F", ""),
            _stat("yellow", "Yellow (right): Instability", "0 stable · 1 unstable if heated · 2 violent change · 3 detonation w/ initiator · 4 detonation alone", ""),
            _stat("white", "White (bottom): Special", "W water reactive · OX oxidizer · SA simple asphyxiant", ""),
            _stat("audience", "Audience", "fire and emergency responders", "(not workers handling daily)"),
            _stat("relatedStd", "Companion standard", "OSHA HazCom uses GHS labels for worker info", ""),
        ],
        "tags": ["NFPA 704", "fire diamond", "placard", "emergency response"],
        "body": "The diamond placard you see on tank trucks, building entrances to chemical storage, and the door of a chemistry stockroom. Designed for first responders making rapid risk decisions in seconds, not for routine handling.\n\n**The four quadrants** rotate clockwise from blue (left, health) → red (top, fire) → yellow (right, instability) → white (bottom, special).\n\n**Health (blue)**: 0 means no special hazard; 4 means a single exposure may be fatal. Most common lab chemicals are 1 to 3.\n\n**Fire (red)**: numbered by flash point. 0 won't burn, 4 burns readily at room temperature. Gasoline is 3; diesel is 2; ethanol is 3; water is 0.\n\n**Instability (yellow)**: 0 is normally stable; 4 detonates by itself. Almost all common reagents are 0 or 1. Picric acid (dry) is 4. Organic peroxides can be 3 to 4.\n\n**Special (white)**: optional symbols. **W** with a bar through it means water-reactive (do not use water to fight fire). **OX** means strong oxidizer (do not store with combustibles). **SA** is a simple asphyxiant (displaces oxygen; for inert gases in confined spaces).\n\n**Not GHS**. NFPA 704 is the US firefighter-facing system; **GHS pictograms** on the bottle itself are what workers see for daily handling. The two systems coexist; they look different and convey different information.",
        "related": ["hazard:ghs-pictograms"],
        "sources": ["nfpa-704"],
    },
    {
        "slug": "ghs-pictograms", "title": "GHS pictograms",
        "symbol": "◬",
        "kind": "safety-reference",
        "subtitle": "Nine red-bordered diamond pictograms on chemical container labels · UN GHS Rev. 10",
        "stats": [
            _stat("flame", "Flame", "flammables, self-reactives, organic peroxides, pyrophorics", ""),
            _stat("flameCircle", "Flame over circle", "oxidizers (solid, liquid, gas)", ""),
            _stat("bomb", "Exploding bomb", "explosives, self-reactives type A or B", ""),
            _stat("cylinder", "Gas cylinder", "compressed gases under pressure", ""),
            _stat("corrosion", "Corrosion", "skin corrosion, serious eye damage, metal corrosivity", ""),
            _stat("skull", "Skull and crossbones", "acute toxicity Cat 1 to 3 (fatal or toxic)", ""),
            _stat("exclamation", "Exclamation mark", "irritant, acute toxicity Cat 4, sensitizer (skin), narcotic", ""),
            _stat("healthHazard", "Health hazard", "carcinogen, mutagen, reproductive toxin, respiratory sensitizer", ""),
            _stat("environment", "Environment (dead fish/tree)", "aquatic toxicity (optional in US workplace)", ""),
        ],
        "tags": ["GHS", "pictograms", "labels", "workplace"],
        "body": "The nine standardized pictograms that appear on every reagent bottle under OSHA HazCom 2012 / GHS Rev. 10. **Red diamond border, black symbol on white.** Combined with signal words ('Danger' or 'Warning'), hazard statements ('H315 Causes skin irritation'), and precautionary statements ('P262 Do not get in eyes'), they replace the older 'workplace' labels.\n\n**The nine pictograms cover physical hazards** (flame, oxidizer, gas cylinder, exploding bomb), **health hazards** (corrosion, skull and crossbones, exclamation mark, health hazard with chest silhouette), and **environmental hazard** (dead fish/tree, mandatory in EU/UK, optional in US for workplace but required for transport).\n\n**Signal words**: only two are used. **Danger** for the most severe category; **Warning** for less severe. A single product gets only one signal word; if multiple hazards apply, the highest level applies.\n\n**Read the H and P numbers** on the actual SDS (Safety Data Sheet, formerly MSDS) for the specific reagent. The pictograms are a quick visual scan; the H and P codes are the precise hazard description.",
        "related": ["hazard:nfpa-704", "hazard:ppe-selection"],
        "sources": ["ghs-rev10", "osha-1910"],
    },
    {
        "slug": "dot-placards", "title": "DOT placards",
        "symbol": "▲",
        "kind": "safety-reference",
        "subtitle": "Transport diamond placards · 9 hazard classes · 49 CFR 172",
        "stats": [
            _stat("class1", "Class 1", "Explosives (1.1 mass explosion through 1.6 insensitive)", ""),
            _stat("class2", "Class 2", "Gases: 2.1 flammable, 2.2 non-flammable, 2.3 toxic", ""),
            _stat("class3", "Class 3", "Flammable liquids (flash point ≤ 60 °C)", ""),
            _stat("class4", "Class 4", "Flammable solids, spontaneously combustible, dangerous-when-wet", ""),
            _stat("class5", "Class 5", "Oxidizers (5.1) and organic peroxides (5.2)", ""),
            _stat("class6", "Class 6", "Toxic substances (6.1) and infectious substances (6.2)", ""),
            _stat("class7", "Class 7", "Radioactive materials (I, II, III categories)", ""),
            _stat("class8", "Class 8", "Corrosives", ""),
            _stat("class9", "Class 9", "Miscellaneous (lithium batteries, dry ice, ID 3077 etc.)", ""),
        ],
        "tags": ["DOT", "placards", "transport", "49 CFR 172"],
        "body": "Diamond placards displayed on vehicles transporting hazardous materials. Each placard is a 10.8-inch square set on point (the diamond orientation), with the hazard class number at the bottom, a symbol in the top, and a UN ID number for the specific material.\n\n**You will mostly see Class 3 (flammable liquids: gasoline, ethanol, acetone), Class 8 (corrosives: acids, caustic bases), and Class 2 (gases: propane, oxygen).** Class 1 (explosives) and Class 7 (radioactive) require special handling and are uncommon in routine shop or lab settings.\n\n**Ordering reagents**: above 1 L of most acids, bases, and flammables, you trigger DOT regulations for shipping. The supplier handles the placarding and paperwork, but the receiver is responsible for safe unloading. If a tank truck arrives with a Class 8 placard, the driver delivers; the receiver must have neutralizing agent and absorbent on hand before signing off.\n\nFor lab and shop quantities (typically under 5 gallons / 25 kg of any one material), DOT 'small quantity' or 'limited quantity' provisions usually apply, with reduced placarding requirements.",
        "related": [],
        "sources": ["dot-49cfr"],
    },
    {
        "slug": "incompatibility-matrix", "title": "Chemical incompatibility quick reference",
        "symbol": "⚠",
        "kind": "safety-reference",
        "subtitle": "Dangerous combinations to know · keep these pairs separated in storage and use",
        "stats": [
            _stat("acid_bleach", "Acid + bleach (NaOCl)", "→ chlorine gas Cl₂ · respiratory casualty", ""),
            _stat("acid_cyanide", "Acid + cyanide salt", "→ hydrogen cyanide HCN · acute lethal", ""),
            _stat("acid_sulfide", "Acid + sulfide salt", "→ hydrogen sulfide H₂S · acute lethal", ""),
            _stat("nitric_organic", "Concentrated HNO₃ + organics", "→ fire or violent oxidation", ""),
            _stat("perchloric_organic", "Perchloric acid + organics", "→ explosion (organic perchlorates)", ""),
            _stat("alkali_aluminum", "NaOH/KOH + aluminum or zinc", "→ hydrogen gas H₂ · explosion hazard in closed vessel", ""),
            _stat("oxidizer_organic", "Oxidizers + organics", "→ self-sustained fire (paper, oil, solvent)", ""),
            _stat("water_alkali_metal", "Water + Na, K, Li metal", "→ hydrogen + caustic exotherm · fire", ""),
            _stat("water_acidChloride", "Water + acid chloride (SOCl₂)", "→ HCl gas + acid", ""),
            _stat("ammonia_chlorine", "NH₃ + chlorine bleach", "→ chloramine gas · respiratory casualty", ""),
            _stat("acetone_h2o2", "Acetone + H₂O₂ + acid", "→ acetone peroxide TATP · friction-sensitive explosive", ""),
            _stat("picric_metals", "Picric acid + metals (Pb, Cu)", "→ metal picrates · friction-sensitive explosives", ""),
        ],
        "tags": ["incompatibility", "dangerous combinations", "storage", "spill"],
        "body": "**Memorize these.** These are the combinations that most often cause shop and lab injuries: not because the reagents are inherently exotic, but because they are mundane and the bad pairings are easy to make by accident.\n\n**The 'never combine' classics:**\n- **Bleach (NaOCl) plus anything acidic** (vinegar, toilet bowl cleaner, hydrochloric acid) generates chlorine gas. This is the most common household chemical injury.\n- **Bleach plus ammonia** generates chloramine gas, similarly toxic. Cleaning products containing 'oxygen bleach' (peroxide) mixed with ammonia cleaners are a common variant.\n- **Cyanide salts (KCN, NaCN) plus any acid** generates hydrogen cyanide gas. Used historically for silver electroplating; trace cyanide solutions can still be encountered in old shop chemistry inventory.\n\n**The storage-room rules:**\n- Acids and bases separated, on different shelves with secondary containment.\n- Oxidizers separated from anything combustible (paper, wood, organic solvents).\n- Flammables in a flammable-storage cabinet.\n- Picric acid, perchloric acid, and old ether bottles checked annually for crystallization; aged peroxide formers can become friction-sensitive explosives.\n\n**A full chemical compatibility chart** runs to thousands of pairs. The CRC Handbook and the supplier SDS are the authoritative references for any combination you're uncertain about. **When unsure, do not mix.**",
        "related": ["reagent:hcl-conc", "reagent:nh4oh-conc", "reagent:hno3-conc"],
        "sources": ["osha-1910"],
    },
    {
        "slug": "spill-response", "title": "Spill response protocol",
        "symbol": "♨",
        "kind": "safety-reference",
        "subtitle": "General sequence and material-specific procedures · 'protect-contain-clean'",
        "stats": [
            _stat("step1", "1. Protect people", "Evacuate, ventilate, call for help if large", ""),
            _stat("step2", "2. Contain spread", "Block from drains and floor seams · use absorbent berm", ""),
            _stat("step3", "3. Neutralize or absorb", "Per chemistry: see specific procedures", ""),
            _stat("step4", "4. Clean and dispose", "Bag absorbed waste · label · hazardous waste stream", ""),
            _stat("step5", "5. Document", "Incident log · SDS attached · root cause review", ""),
            _stat("acidNeutralizer", "Acid spill neutralizer", "sodium bicarbonate (NaHCO₃)", "(safer than sodium carbonate)"),
            _stat("baseNeutralizer", "Base spill neutralizer", "citric acid or dilute acetic acid", ""),
            _stat("mercurySpill", "Mercury spill", "powdered sulfur, then careful aspiration with vapor mask", ""),
            _stat("solventSpill", "Organic solvent spill", "vermiculite or sand · do not use water", ""),
        ],
        "tags": ["spill response", "cleanup", "neutralization", "protocol"],
        "body": "**Sequence**: protect people, contain spread, neutralize or absorb, clean up and dispose, document.\n\n**Protect people first.** Evacuate the area if the spill is large or unknown. Open windows or activate exhaust ventilation. If anyone is contaminated, get them to the eyewash or safety shower immediately (15 minutes minimum). If the spill is beyond shop-scale, call emergency services.\n\n**Contain spread.** Place absorbent socks or vermiculite berms to keep the spill out of drains, doorways, and floor seams. Once a corrosive enters a drain, you have a much larger problem and a probable regulatory reporting obligation.\n\n**Neutralize or absorb per chemistry:**\n- **Acid spills (HCl, H₂SO₄, HNO₃)**: dust with sodium bicarbonate until fizzing stops (use **bicarbonate, not carbonate**: bicarbonate fizzes more gently and overshoot to pH 9 is fine; carbonate can overshoot to pH 11+ which is its own hazard). Then mop with wet rags. Final pH should test neutral on litmus.\n- **Base spills (NaOH, KOH, NH₄OH)**: neutralize with dilute citric acid or dilute acetic acid. Do not use strong acids; the exotherm and splash is worse than the original base spill.\n- **Organic solvent spills (acetone, ethanol, hexane)**: absorb with vermiculite, perlite, or specific solvent absorbent (no water, which spreads the spill). Eliminate ignition sources first.\n- **Mercury spill**: dust with powdered sulfur (forms mercury sulfide), then use a vacuum aspirator (not a household vacuum, which atomizes mercury into the exhaust) to collect.\n\n**Dispose** as hazardous waste through your facility's licensed contractor. Document the incident in your safety log with the SDS attached.",
        "related": ["reagent:nahco3", "hazard:ppe-selection", "hazard:eyewash-shower"],
        "sources": ["osha-1910"],
    },
    {
        "slug": "ppe-selection", "title": "PPE selection",
        "symbol": "PPE",
        "kind": "safety-reference",
        "subtitle": "Gloves, eye protection, respiratory protection, body protection · hazard-driven",
        "stats": [
            _stat("nitrile", "Nitrile gloves (4 mil)", "general aqueous reagents, brief contact", ""),
            _stat("nitrileHeavy", "Heavy nitrile (8 to 15 mil)", "extended contact, mild solvents", ""),
            _stat("neoprene", "Neoprene gloves", "acids and bases, modest solvent protection", ""),
            _stat("butyl", "Butyl rubber", "ketones (acetone, MEK), strong acids", ""),
            _stat("viton", "Viton gloves", "chlorinated solvents, aromatic hydrocarbons", ""),
            _stat("safetyGlasses", "Safety glasses (ANSI Z87.1)", "minimum for any chemical work", ""),
            _stat("chemGoggles", "Chemical splash goggles", "indirect vent, required for splash hazards", ""),
            _stat("faceShield", "Face shield", "added when splash energy is high (acid dilution, etc.)", ""),
            _stat("n95", "N95 filtering respirator", "particulate only · not for vapor", ""),
            _stat("p100", "P100 cartridge respirator", "with organic vapor + acid gas cartridges", ""),
            _stat("scbA", "SCBA", "for IDLH atmospheres only · trained users", ""),
        ],
        "tags": ["PPE", "gloves", "eye protection", "respirators"],
        "body": "**Match the PPE to the hazard.** Wearing the wrong glove material can be worse than no glove (latex with acetone, for example, swells and channels solvent against the skin).\n\n**Gloves by chemistry:**\n- **Nitrile** is the everyday lab and shop glove. Good against aqueous chemicals, dilute acids and bases, brief solvent exposure. Not for prolonged organic solvent contact.\n- **Neoprene** beats nitrile for strong acids and bases. Slightly less dextrous.\n- **Butyl rubber** is the only common material that resists ketones (acetone, MEK).\n- **Viton (fluoroelastomer)** for chlorinated solvents and aromatics; expensive.\n- **Heat-resistant gloves** (Kevlar, aluminized): for handling hot work, foundry, kiln; useless against chemical exposure.\n\n**Latex gloves**: avoid for chemistry. Some workers develop latex allergies; many solvents permeate latex rapidly. Nitrile is a strict upgrade.\n\n**Eye protection** levels:\n- **Safety glasses** with side shields for any lab or shop activity. Minimum, always.\n- **Chemical splash goggles** for splash hazards (open beakers of acid, mixing operations, anything pressurized).\n- **Face shield over goggles** when energy is high: diluting concentrated H₂SO₄, opening pressurized vessels.\n\n**Respiratory protection** is rarely the right answer in a lab; **fume hood ventilation** is. When the hood is inadequate (sample collection in the field, emergency response), N95 filters particles only; **P100 with organic-vapor + acid-gas cartridges** is the practical 'chemistry' respirator. Both require fit testing and medical clearance under OSHA 1910.134.",
        "related": ["hazard:ghs-pictograms", "hazard:incompatibility-matrix"],
        "sources": ["osha-1910"],
    },
    {
        "slug": "eyewash-shower", "title": "Eyewash and emergency shower",
        "symbol": "⤵",
        "kind": "safety-reference",
        "subtitle": "ANSI Z358.1 emergency response · the only acceptable response is immediate use",
        "stats": [
            _stat("triggerTime", "Time to reach", "10 seconds maximum walking distance", "(unobstructed)"),
            _stat("eyewashDuration", "Eyewash flush duration", 15, "minutes minimum"),
            _stat("showerDuration", "Shower duration", 15, "minutes minimum"),
            _stat("waterTemp", "Tepid water", "16 to 38 °C (60 to 100 °F)", ""),
            _stat("flowEye", "Eyewash flow rate", "1.5 L/min minimum", "(both eyes simultaneously)"),
            _stat("flowShower", "Shower flow rate", "75 L/min minimum", "(20 gallons per min)"),
            _stat("weeklyTest", "Weekly inspection", "30 sec activation", "(verify flow and clean head)"),
        ],
        "tags": ["eyewash", "safety shower", "ANSI Z358.1", "emergency"],
        "body": "**The only acceptable response to a chemical splash to skin or eyes is immediate flushing for 15 minutes minimum.** This is true regardless of what the chemical is, regardless of how it feels, and regardless of whether you 'think' the exposure was significant. Most caustic and acid burns become visible only after the tissue has been damaged; the first symptom is often the eye starting to feel 'normal' again after the initial sting, which is the cornea desensitizing rather than recovering.\n\n**Eyewash for eye splashes**: hold both eyes open with the fingers, irrigate from inner corner outward so contaminant doesn't cross to the unaffected eye. **15 minutes minimum**, longer for strong bases. Have someone else call for medical help while you flush; do not leave the eyewash before the time is up.\n\n**Safety shower for body splashes**: remove contaminated clothing while under the water stream (do not delay shower to undress first). Continue 15 minutes minimum. Hypothermia is preferable to chemical exposure; the 'tepid water' temperature spec is to extend the realistic flushing duration, not to make the experience comfortable.\n\n**After flushing**: seek medical attention regardless. For HF (hydrofluoric acid) exposures, apply calcium gluconate gel after the rinse and proceed immediately to an emergency room; HF binds calcium in tissue and can be lethal at exposure areas as small as 25 cm² (4 sq in).\n\n**Weekly station testing** (ANSI Z358.1): run the station for 30 seconds each week. Verify clean flow, no rust or sediment from stagnant water, no obstructions to the flush head. Annual full-flow test against the flow-rate spec.",
        "hazards": [],
        "related": ["hazard:spill-response", "hazard:ppe-selection"],
        "sources": ["osha-1910"],
    },
]


def build_entry(spec):
    return {
        "id": f"hazard:{spec['slug']}",
        "module": "hazard",
        "kind": spec.get("kind", "safety-reference"),
        "title": spec["title"],
        "symbol": spec.get("symbol", ""),
        "subtitle": spec.get("subtitle", ""),
        "tags": spec.get("tags", []),
        "stats": spec.get("stats", []),
        "body": spec.get("body", ""),
        "hazards": spec.get("hazards", []),
        "related": spec.get("related", []),
        "sources": spec.get("sources", ["osha-1910"]),
    }


def write_manifest_entries():
    manifest = json.loads(MANIFEST.read_text())
    slugs = [s["slug"] for s in ENTRIES]
    for m in manifest["modules"]:
        if m["slug"] == "hazard":
            m["entries"] = slugs
            m["status"] = "active"
            break
    MANIFEST.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    print(f"Manifest updated: hazard declares {len(slugs)} entries.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    written = 0
    for spec in ENTRIES:
        entry = build_entry(spec)
        path = DATA_DIR / f"{spec['slug']}.json"
        text = json.dumps(entry, indent=2, ensure_ascii=False) + "\n"
        if args.dry_run:
            print(f"  {'~' if path.exists() else '+'} {path.relative_to(ROOT)}")
        else:
            path.write_text(text)
        written += 1
    print(f"\nSeeded {written} hazard files.")
    if not args.dry_run:
        write_manifest_entries()
    return 0


if __name__ == "__main__":
    sys.exit(main())
