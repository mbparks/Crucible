#!/usr/bin/env python3
"""
CRUCIBLE alloy seeder.

Generates modules/alloy/data/<slug>.json across the major engineering alloy
families. Data sourced primarily from ASM Handbook Vol. 1 (irons and steels),
Vol. 2 (nonferrous), and standard material data sheets from major mill suppliers
(values that are widely published and effectively facts of practice).

Usage:
    python3 tools/seed_alloys.py                  # write all
    python3 tools/seed_alloys.py --dry-run        # show what would change
    python3 tools/seed_alloys.py --keep aisi-1018 # preserve hand edits
"""

import json
import sys
import argparse
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "modules" / "alloy" / "data"
MANIFEST = ROOT / "shared" / "data" / "manifest.json"


FAMILY_TAGS = {
    "carbon-steel":      ["steel", "ferrous", "carbon steel"],
    "alloy-steel":       ["steel", "ferrous", "alloy steel"],
    "tool-steel":        ["steel", "ferrous", "tool steel"],
    "stainless":         ["steel", "ferrous", "stainless", "corrosion resistant"],
    "aluminum":          ["aluminum", "nonferrous", "lightweight"],
    "copper-alloy":      ["copper", "nonferrous"],
    "titanium":          ["titanium", "nonferrous", "lightweight", "corrosion resistant"],
    "nickel-superalloy": ["nickel", "nonferrous", "high temperature"],
    "cast-iron":         ["iron", "ferrous", "cast"],
}


def _stat(key, label, value, unit, source="asm-v1"):
    return {"key": key, "label": label, "value": value, "unit": unit, "source": source}


def stats_from(spec):
    """Build the stats array from a flat alloy spec dict."""
    out = []
    # Composition (a list of (element, percent_range_string) pairs)
    for elem, val in spec.get("comp", []):
        out.append({"key": f"comp_{elem.lower()}", "label": elem, "value": val, "unit": "%", "source": spec.get("comp_source", "asm-v1")})
    # Physical
    if "density" in spec:
        out.append(_stat("density", "Density", spec["density"], "g/cm³"))
    # Mechanical
    if "yield_mpa" in spec:
        out.append(_stat("yieldStrength", "Yield strength", spec["yield_mpa"], "MPa"))
    if "tensile_mpa" in spec:
        out.append(_stat("tensileStrength", "Tensile strength", spec["tensile_mpa"], "MPa"))
    if "elong" in spec:
        out.append(_stat("elongation", "Elongation", spec["elong"], "%"))
    if "hardness" in spec:
        out.append(_stat("hardness", "Hardness", spec["hardness"], ""))
    if "modulus" in spec:
        out.append(_stat("youngsModulus", "Young's modulus", spec["modulus"], "GPa"))
    if "machinability" in spec:
        out.append(_stat("machinability", "Machinability", spec["machinability"], "% of B1112"))
    if "thermal" in spec:
        out.append(_stat("thermalConductivity", "Thermal cond.", spec["thermal"], "W/m·K"))
    if "cte" in spec:
        out.append(_stat("cte", "CTE (20 to 100 °C)", spec["cte"], "×10⁻⁶/K"))
    if "melt_range" in spec:
        out.append(_stat("meltingRange", "Melting range", spec["melt_range"], "°C"))
    if "max_service" in spec:
        out.append(_stat("maxServiceTemp", "Max service temp", spec["max_service"], "°C"))
    return out


# -----------------------------------------------------------------------------
# Alloy data
# -----------------------------------------------------------------------------

ALLOYS = [
    # ============ CARBON STEELS ============
    {
        "slug": "aisi-1045", "title": "AISI 1045", "symbol": "1045",
        "family": "carbon-steel",
        "subtitle": "Medium-carbon steel · UNS G10450 · plain-carbon",
        "comp": [("C", "0.43-0.50"), ("Mn", "0.60-0.90")],
        "density": 7.85, "yield_mpa": 530, "tensile_mpa": 625, "elong": 12,
        "hardness": "179 HB (cold-drawn)", "modulus": 200, "machinability": 55,
        "tags": ["medium carbon", "shafting", "weldable with care", "induction hardenable"],
        "body": "Medium-carbon plain steel. The default shaft, axle, and bolt stock when 1018 is too soft and 4140 is overkill. Hardenable by water or oil quench to about 55 to 58 HRC at the surface, useful as a wear surface that doesn't need deep through-hardening.\n\n**Welding** requires preheat (150 to 260 °C) and post-weld stress relief; the carbon level is right at the boundary where weld cracking starts to matter. **Induction hardening** of journals and crank surfaces is the natural sweet spot for this grade.",
        "related": ["element:fe", "temper:1045-hardening"],
        "sources": ["asm-v1", "asm-v4"],
    },
    {
        "slug": "aisi-1095", "title": "AISI 1095", "symbol": "1095",
        "family": "carbon-steel",
        "subtitle": "High-carbon steel · UNS G10950 · spring and knife stock",
        "comp": [("C", "0.90-1.03"), ("Mn", "0.30-0.50")],
        "density": 7.85, "yield_mpa": 525, "tensile_mpa": 695, "elong": 10,
        "hardness": "192 HB (annealed), 64 HRC (full hard)", "modulus": 200, "machinability": 45,
        "tags": ["high carbon", "spring steel", "knife steel", "oil quench"],
        "body": "High-carbon plain steel, the workhorse blade and spring grade for hobbyist knife makers and bladesmiths. Takes a fine edge, holds it adequately, sharpens easily. Will rust if you look at it wrong.\n\n**Heat treat**: austenitize at 790 to 815 °C, oil quench to about 65 HRC, temper to 58 to 62 HRC for a knife (200 to 230 °C) or 45 to 50 HRC for a spring (320 to 425 °C). The wide tempering response is why one steel handles such different jobs.",
        "related": ["element:fe", "temper:1095-knife"],
        "sources": ["asm-v1", "asm-v4"],
    },
    {
        "slug": "aisi-12l14", "title": "AISI 12L14", "symbol": "12L14",
        "family": "carbon-steel",
        "subtitle": "Free-machining low-carbon steel · UNS G12144 · leaded resulfurized",
        "comp": [("C", "0.15 max"), ("Mn", "0.85-1.15"), ("S", "0.26-0.35"), ("Pb", "0.15-0.35"), ("P", "0.04-0.09")],
        "density": 7.87, "yield_mpa": 415, "tensile_mpa": 540, "elong": 10,
        "hardness": "163 HB", "modulus": 200, "machinability": 170,
        "tags": ["free-machining", "screw machine", "non-weldable", "leaded"],
        "body": "The king of screw-machine steels. The combination of high sulfur (forms MnS chip-breakers) and lead (lubricant smear at the cutting edge) gives 12L14 machinability around 170% of B1112, the historical free-machining reference.\n\n**Tradeoffs**: weldability is essentially zero (sulfur causes hot cracking, lead vaporizes hazardously), surface finish in the as-machined state is excellent, fatigue strength is poor. Use where you're cutting a lot of material on automatic machines and the parts will not see fatigue loading. Lead-free alternatives (1215, 1144) exist but machinability drops 30 to 50%.",
        "related": ["element:fe", "alloy:aisi-1144"],
        "sources": ["asm-v1"],
    },
    {
        "slug": "aisi-1144", "title": "AISI 1144", "symbol": "1144",
        "family": "carbon-steel",
        "subtitle": "Free-machining medium-carbon steel · UNS G11440 · Stressproof equivalent",
        "comp": [("C", "0.40-0.48"), ("Mn", "1.35-1.65"), ("S", "0.24-0.33")],
        "density": 7.85, "yield_mpa": 620, "tensile_mpa": 760, "elong": 10,
        "hardness": "212 HB (stress-relieved)", "modulus": 200, "machinability": 85,
        "tags": ["free-machining", "lead-free", "shafting", "Stressproof"],
        "body": "Trade-named 'Stressproof' or 'LaSalle 1144'. Combines machinability with the higher strength of medium-carbon steel and the absence of lead (compared to 12L14). The stress-relieved condition gives high yield with minimal residual stress, so it stays straight after machining heavy features."
    },

    # ============ ALLOY STEELS ============
    {
        "slug": "aisi-4140", "title": "AISI 4140", "symbol": "4140",
        "family": "alloy-steel",
        "subtitle": "Chromium-molybdenum alloy steel · UNS G41400 · chromoly",
        "comp": [("C", "0.38-0.43"), ("Mn", "0.75-1.00"), ("Cr", "0.80-1.10"), ("Mo", "0.15-0.25")],
        "density": 7.85, "yield_mpa": 655, "tensile_mpa": 850, "elong": 16,
        "hardness": "197 HB (annealed), 217 HB (PHT)", "modulus": 205, "machinability": 65,
        "tags": ["chromoly", "structural", "hardenable", "shafting", "PHT"],
        "body": "The default through-hardenable alloy steel. Sold predominantly in 'PHT' (pre-hardened and tempered) condition at about 28 to 32 HRC, ready to machine and use without further heat treatment. For higher strengths, re-quench and temper to target.\n\n**Heat treat ranges**: austenitize at 845 to 870 °C, oil quench to about 58 HRC max, temper at 200 to 700 °C for any condition from 55 HRC down to 22 HRC. **Hardenability** is deep enough for sections up to about 75 mm to through-harden in oil.\n\n**Welding** requires preheat (200 to 315 °C) and post-weld temper. **Common forms**: hex bar, round bar, plate, and as forging stock for crankshafts, axles, gears, and high-strength fasteners.",
        "related": ["element:fe", "element:cr", "element:mo", "temper:4140-ht"],
        "sources": ["asm-v1", "asm-v4"],
    },
    {
        "slug": "aisi-4340", "title": "AISI 4340", "symbol": "4340",
        "family": "alloy-steel",
        "subtitle": "Nickel-chromium-molybdenum alloy steel · UNS G43400 · aerospace structural",
        "comp": [("C", "0.38-0.43"), ("Mn", "0.60-0.80"), ("Cr", "0.70-0.90"), ("Ni", "1.65-2.00"), ("Mo", "0.20-0.30")],
        "density": 7.85, "yield_mpa": 855, "tensile_mpa": 1080, "elong": 13,
        "hardness": "248 HB (PHT) to 53 HRC (high-strength)", "modulus": 205, "machinability": 50,
        "tags": ["aerospace", "high-strength", "hardenable", "landing gear", "shafting"],
        "body": "Higher-strength, higher-toughness cousin of 4140. The nickel content gives better toughness at high hardness, which is why 4340 owns aerospace landing-gear forgings and high-strength shafts.\n\n**Deep hardenability**: through-hardens in sections up to about 100 mm in oil. **Heat treat**: austenitize at 815 to 845 °C, oil quench, temper at 205 to 650 °C. **300M** is the modified silicon-enhanced version used at very high strength (around 2000 MPa tensile).",
        "related": ["element:fe", "element:ni", "element:cr", "element:mo"],
        "sources": ["asm-v1", "asm-v4"],
    },
    {
        "slug": "aisi-8620", "title": "AISI 8620", "symbol": "8620",
        "family": "alloy-steel",
        "subtitle": "Low-alloy carburizing steel · UNS G86200 · case hardening",
        "comp": [("C", "0.18-0.23"), ("Mn", "0.70-0.90"), ("Cr", "0.40-0.60"), ("Ni", "0.40-0.70"), ("Mo", "0.15-0.25")],
        "density": 7.85, "yield_mpa": 360, "tensile_mpa": 535, "elong": 22,
        "hardness": "183 HB core / 58 to 62 HRC case", "modulus": 205, "machinability": 65,
        "tags": ["carburizing", "case hardened", "gears", "pinions", "wear"],
        "body": "The default carburizing grade. Tough low-carbon alloy core with a hard high-carbon case after gas carburizing.\n\n**Process**: gas carburize at 900 to 925 °C for 4 to 12 hours (case depth 0.5 to 1.5 mm), oil quench, temper at 150 to 175 °C. Result: 58 to 62 HRC case over a 32 to 38 HRC core. Used for transmission gears, pinions, wrist pins, fixture pins, anything that needs a hard wear surface over a tough fatigue-resistant body.",
        "related": ["element:fe", "temper:8620-carburize"],
        "sources": ["asm-v1", "asm-v4"],
    },

    # ============ TOOL STEELS ============
    {
        "slug": "tool-a2", "title": "A2 tool steel", "symbol": "A2",
        "family": "tool-steel",
        "subtitle": "Air-hardening cold-work tool steel · UNS T30102 · AISI A2",
        "comp": [("C", "0.95-1.05"), ("Mn", "1.00 max"), ("Cr", "4.75-5.50"), ("Mo", "0.90-1.40"), ("V", "0.15-0.50")],
        "density": 7.86, "modulus": 203, "hardness": "57-62 HRC", "machinability": 65,
        "tags": ["air hardening", "cold work", "blanking dies", "knife", "stable"],
        "body": "The forgiving cold-work die steel. Air-hardens (no quench-crack risk), holds size well through heat treat, and gives a respectable wear resistance for stamping and blanking dies.\n\n**Heat treat**: preheat to 760 °C, austenitize at 940 to 980 °C, air cool to room temperature (or salt bath quench for thin sections), temper at 175 to 540 °C. **Common temper**: two cycles at 200 °C for 58 to 60 HRC for blanking dies. The vanadium carbides give the edge retention.",
        "related": ["element:fe", "element:cr", "temper:a2-cycle"],
        "sources": ["asm-v1", "asm-v4"],
    },
    {
        "slug": "tool-d2", "title": "D2 tool steel", "symbol": "D2",
        "family": "tool-steel",
        "subtitle": "High-carbon high-chromium cold-work tool steel · UNS T30402 · AISI D2",
        "comp": [("C", "1.40-1.60"), ("Cr", "11.00-13.00"), ("Mo", "0.70-1.20"), ("V", "1.10 max")],
        "density": 7.70, "modulus": 207, "hardness": "60-62 HRC", "machinability": 27,
        "tags": ["high chromium", "wear resistant", "blanking", "shear blades", "knife"],
        "body": "The wear-king of the cold-work category. The 12% chromium gives a huge volume fraction of M₇C₃ carbides which dominate the wear performance. Edge retention in cutting tools and shear blades is excellent; toughness is mediocre, brittleness is the failure mode.\n\n**Heat treat**: austenitize at 1010 to 1040 °C, air or oil quench, double temper at 200 °C for cutting (60 to 62 HRC) or at 510 °C secondary hardening peak for dies (58 to 60 HRC with better toughness).\n\nNot a stainless even though it's high chromium; most of the chromium is locked in carbides rather than in solution.",
        "related": ["element:fe", "element:cr", "element:v", "temper:d2-cycle"],
        "sources": ["asm-v1", "asm-v4"],
    },
    {
        "slug": "tool-o1", "title": "O1 tool steel", "symbol": "O1",
        "family": "tool-steel",
        "subtitle": "Oil-hardening cold-work tool steel · UNS T31501 · AISI O1",
        "comp": [("C", "0.85-1.00"), ("Mn", "1.00-1.40"), ("Cr", "0.40-0.60"), ("W", "0.40-0.60")],
        "density": 7.85, "modulus": 207, "hardness": "60-64 HRC", "machinability": 90,
        "tags": ["oil hardening", "knife", "fixturing", "machinable annealed"],
        "body": "The most-used tool steel for hobbyist knife making and one-off tooling. Easy to machine in the annealed condition, predictable heat-treat response, oil-quenches with low risk of cracking on simple geometries.\n\n**Heat treat**: austenitize at 790 to 815 °C, oil quench to about 64 HRC, temper at 175 to 260 °C to 58 to 62 HRC. Distortion is more than A2 (so not ideal for thin precision parts) but the cost and machinability are why it stays popular.",
        "related": ["element:fe", "temper:o1-quench"],
        "sources": ["asm-v1", "asm-v4"],
    },
    {
        "slug": "tool-s7", "title": "S7 tool steel", "symbol": "S7",
        "family": "tool-steel",
        "subtitle": "Shock-resistant tool steel · UNS T41907 · AISI S7",
        "comp": [("C", "0.45-0.55"), ("Mn", "0.20-0.80"), ("Cr", "3.00-3.50"), ("Mo", "1.30-1.80")],
        "density": 7.76, "modulus": 207, "hardness": "54-58 HRC",
        "tags": ["shock resistant", "impact", "punches", "chisels"],
        "body": "The tool steel for impact tooling. Lower carbon than A2 or D2 trades wear resistance for toughness. Punches, chisels, sledge dies, jackhammer bits.\n\n**Heat treat**: austenitize 940 to 955 °C, air or oil quench, temper at 205 to 540 °C. At 54 to 56 HRC the impact strength is exceptional for tool steel.",
        "related": ["element:fe"],
        "sources": ["asm-v1", "asm-v4"],
    },
    {
        "slug": "tool-m2", "title": "M2 high-speed steel", "symbol": "M2",
        "family": "tool-steel",
        "subtitle": "Tungsten-molybdenum HSS · UNS T11302 · AISI M2",
        "comp": [("C", "0.78-0.88"), ("Cr", "3.75-4.50"), ("Mo", "4.75-6.50"), ("W", "5.50-6.75"), ("V", "1.75-2.20")],
        "density": 8.16, "modulus": 207, "hardness": "62-66 HRC", "max_service": 540,
        "tags": ["HSS", "drill bits", "milling cutters", "red hot hardness"],
        "body": "The standard high-speed steel for general-purpose drills, taps, end mills, broaches, and form tools. 'High-speed' refers to its ability to retain hardness at 500 °C plus (red-hot hardness), which is what lets HSS cutters run at industrial cutting speeds without dulling immediately.\n\n**Heat treat**: austenitize 1190 to 1230 °C (very high, needs salt bath or controlled atmosphere), oil quench, triple temper at 540 to 565 °C for secondary hardening. Most users buy M2 in the fully heat-treated and ground condition rather than HT in house.",
        "related": ["element:fe", "element:w", "element:mo", "element:v"],
        "sources": ["asm-v1", "asm-v4"],
    },

    # ============ STAINLESS STEELS ============
    {
        "slug": "ss-304", "title": "304 stainless", "symbol": "304",
        "family": "stainless",
        "subtitle": "Austenitic 18-8 stainless · UNS S30400 · AISI 304",
        "comp": [("Cr", "18.0-20.0"), ("Ni", "8.0-10.5"), ("C", "0.08 max"), ("Mn", "2.00 max")],
        "density": 7.93, "yield_mpa": 290, "tensile_mpa": 620, "elong": 55,
        "hardness": "≤201 HB (annealed)", "modulus": 193, "thermal": 16.2, "cte": 17.3,
        "tags": ["austenitic", "non-magnetic", "food grade", "weldable"],
        "body": "The workhorse stainless. About 50% of all stainless production by mass. Non-magnetic in the annealed condition (cold work induces some martensite and partial magnetism). Excellent in food and dairy processing, kitchen equipment, architectural trim, and chemical service short of chlorides.\n\n**Sensitization** above 425 °C precipitates chromium carbides at grain boundaries and depletes the matrix locally, allowing intergranular corrosion. For welded service or stress relief above this range, use **304L** (low carbon) or stabilized grades (321, 347).\n\nWork-hardens significantly. **Machining** is slower than carbon steel; use positive rake, sharp tools, copious coolant, never let the cut idle (work-hardens immediately).",
        "related": ["element:fe", "element:cr", "element:ni", "alloy:ss-316"],
        "sources": ["asm-v1"],
    },
    {
        "slug": "ss-316", "title": "316 stainless", "symbol": "316",
        "family": "stainless",
        "subtitle": "Molybdenum-bearing austenitic stainless · UNS S31600 · AISI 316",
        "comp": [("Cr", "16.0-18.0"), ("Ni", "10.0-14.0"), ("Mo", "2.0-3.0"), ("C", "0.08 max")],
        "density": 8.0, "yield_mpa": 290, "tensile_mpa": 580, "elong": 55,
        "hardness": "≤217 HB (annealed)", "modulus": 193, "thermal": 16.3, "cte": 15.9,
        "tags": ["austenitic", "marine", "chloride resistant", "implant grade"],
        "body": "304 with about 2 to 3% molybdenum added. The molybdenum dramatically improves pitting and crevice corrosion resistance in chloride environments (seawater, salt fog, brackish water, swimming pool chemistry), which is why 316 is the standard marine and chemical-service stainless.\n\n**316L** (low carbon, 0.03% max) is the welded-service variant that resists sensitization. Most architectural and marine 316 sold today is actually 316L.\n\n**Implant-grade** 316LVM (vacuum-melted, very low S and P) is one of the standard medical implant materials.",
        "related": ["element:fe", "element:cr", "element:ni", "element:mo", "alloy:ss-304"],
        "sources": ["asm-v1"],
    },
    {
        "slug": "ss-410", "title": "410 stainless", "symbol": "410",
        "family": "stainless",
        "subtitle": "Martensitic stainless · UNS S41000 · AISI 410",
        "comp": [("Cr", "11.5-13.5"), ("C", "0.15 max"), ("Mn", "1.00 max")],
        "density": 7.74, "yield_mpa": 415, "tensile_mpa": 585, "elong": 22,
        "hardness": "155 to 290 HB (annealed), up to 41 HRC (PHT)", "modulus": 200,
        "tags": ["martensitic", "magnetic", "hardenable stainless", "cutlery"],
        "body": "The hardenable stainless. Air or oil quench from 950 to 1010 °C gives up to 41 HRC. Less corrosion resistant than the austenitic grades (no nickel, no molybdenum, lower chromium), but it can hold an edge, which is why it shows up in cutlery, valve trim, pump shafts, and steam-turbine blading.\n\nMagnetic in all conditions (martensitic). For higher-strength stainless service, look to **17-4 PH** instead.",
        "related": ["element:fe", "element:cr", "alloy:ss-17-4"],
        "sources": ["asm-v1"],
    },
    {
        "slug": "ss-17-4", "title": "17-4 PH stainless", "symbol": "17-4 PH",
        "family": "stainless",
        "subtitle": "Precipitation-hardening stainless · UNS S17400 · ASTM A564",
        "comp": [("Cr", "15.0-17.5"), ("Ni", "3.0-5.0"), ("Cu", "3.0-5.0"), ("Nb", "0.15-0.45")],
        "density": 7.80, "yield_mpa": 1170, "tensile_mpa": 1310, "elong": 10,
        "hardness": "≤44 HRC (H900)", "modulus": 196, "thermal": 18.0,
        "tags": ["PH stainless", "high strength", "aerospace", "shafting"],
        "body": "The default high-strength stainless. Combines the corrosion resistance of stainless with strength approaching that of high-strength alloy steels. Solution-treated then age-hardened: the H900 condition (aged at 482 °C for 1 hour, air cool) gives the highest strength at about 1310 MPa tensile.\n\n**Aging conditions** trade strength against toughness: H900 (482 °C) maximum strength, H1025 (552 °C) balanced, H1150 (621 °C) over-aged for highest toughness at lower strength. Used in aerospace structural parts, valve stems, pump shafts, golf-club irons, and firearm components.",
        "related": ["element:fe", "element:cr", "element:ni", "element:cu", "temper:17-4-h900"],
        "sources": ["asm-v1"],
    },

    # ============ ALUMINUM ============
    {
        "slug": "al-1100", "title": "Aluminum 1100", "symbol": "1100",
        "family": "aluminum",
        "subtitle": "Commercially pure aluminum · UNS A91100",
        "comp": [("Al", "99.00 min"), ("Cu", "0.05-0.20")],
        "density": 2.71, "yield_mpa": 110, "tensile_mpa": 124, "elong": 12,
        "hardness": "32 HB (H14)", "modulus": 69, "thermal": 222, "cte": 23.6,
        "tags": ["pure", "electrical conductor", "deep drawing", "chemical equipment"],
        "body": "Essentially pure aluminum. Excellent thermal and electrical conductivity (around 59% IACS), excellent formability, mediocre strength. Used where pure-metal properties matter: heat exchanger fins, electrical busbar, chemical-process tanks, deep-drawn cookware."
    },
    {
        "slug": "al-3003", "title": "Aluminum 3003", "symbol": "3003",
        "family": "aluminum",
        "subtitle": "Manganese-alloyed aluminum · UNS A93003",
        "comp": [("Mn", "1.00-1.50"), ("Cu", "0.05-0.20"), ("Si", "0.60 max"), ("Fe", "0.70 max")],
        "density": 2.73, "yield_mpa": 145, "tensile_mpa": 150, "elong": 14,
        "hardness": "40 HB (H14)", "modulus": 69, "thermal": 162, "cte": 23.2,
        "tags": ["sheet", "general purpose", "non-heat-treatable", "weldable"],
        "body": "The default general-purpose aluminum sheet. About 20% stronger than 1100 with similar formability. Used for sheet-metal enclosures, gutters, ductwork, signage, cooking utensils. Not heat-treatable; tempered by cold-rolling (H tempers).",
        "related": ["element:al", "element:mn"],
        "sources": ["asm-v2"],
    },
    {
        "slug": "al-5052", "title": "Aluminum 5052", "symbol": "5052",
        "family": "aluminum",
        "subtitle": "Magnesium-alloyed aluminum · UNS A95052",
        "comp": [("Mg", "2.20-2.80"), ("Cr", "0.15-0.35")],
        "density": 2.68, "yield_mpa": 215, "tensile_mpa": 290, "elong": 12,
        "hardness": "67 HB (H32)", "modulus": 70, "thermal": 138, "cte": 23.8,
        "tags": ["marine", "sheet", "fatigue resistant", "weldable"],
        "body": "The standard marine and architectural aluminum sheet. Excellent saltwater corrosion resistance, good fatigue strength, excellent weldability with 5356 filler. Used for boat hulls, fuel tanks, electronics enclosures, signage, architectural panels. Not heat-treatable.",
        "related": ["element:al", "element:mg"],
        "sources": ["asm-v2"],
    },
    {
        "slug": "al-6061", "title": "Aluminum 6061-T6", "symbol": "6061-T6",
        "family": "aluminum",
        "subtitle": "Heat-treatable Al-Mg-Si alloy · UNS A96061 · T6 temper",
        "comp": [("Mg", "0.80-1.20"), ("Si", "0.40-0.80"), ("Cu", "0.15-0.40"), ("Cr", "0.04-0.35")],
        "density": 2.70, "yield_mpa": 276, "tensile_mpa": 310, "elong": 17,
        "hardness": "95 HB (T6)", "modulus": 69, "thermal": 167, "cte": 23.6, "machinability": 90,
        "tags": ["structural", "extrusion", "weldable", "T6", "framing"],
        "body": "The all-purpose structural aluminum. Available in nearly every mill form (plate, sheet, bar, tube, extrusion, casting). Excellent strength-to-weight, good corrosion resistance, weldable (use 4043 or 5356 filler), machinable, anodizes well.\n\n**T6 temper**: solution heat treat at 530 °C, water quench, age at 175 °C for 8 hours. After welding the heat-affected zone drops to T4 strength; re-aging restores T6 if needed. **Common forms**: structural framing, machined parts, bicycle frames, aircraft structure, marine fittings.",
        "related": ["element:al", "element:mg", "element:si", "alloy:al-7075"],
        "sources": ["asm-v2"],
    },
    {
        "slug": "al-7075", "title": "Aluminum 7075-T6", "symbol": "7075-T6",
        "family": "aluminum",
        "subtitle": "High-strength Al-Zn alloy · UNS A97075 · T6 temper",
        "comp": [("Zn", "5.10-6.10"), ("Mg", "2.10-2.90"), ("Cu", "1.20-2.00"), ("Cr", "0.18-0.28")],
        "density": 2.81, "yield_mpa": 503, "tensile_mpa": 572, "elong": 11,
        "hardness": "150 HB (T6)", "modulus": 71.7, "thermal": 130, "cte": 23.4, "machinability": 70,
        "tags": ["aerospace", "high strength", "non-weldable", "T6", "stress corrosion"],
        "body": "The high-strength aerospace aluminum. Tensile around 570 MPa rivals mild steel at one-third the density. Used in aircraft structure (wing skins, fuselage frames), high-end bicycle frames, sporting goods.\n\n**Weldability is poor** (stress corrosion cracking risk in the HAZ); joining is by riveting, bolting, or adhesive. **T651** (stress-relieved) is the plate temper of choice for machined parts to minimize residual-stress distortion. **T73** trades some strength for stress corrosion resistance.",
        "related": ["element:al", "element:zn", "alloy:al-6061"],
        "sources": ["asm-v2"],
    },
    {
        "slug": "al-2024", "title": "Aluminum 2024-T3", "symbol": "2024-T3",
        "family": "aluminum",
        "subtitle": "Copper-bearing aerospace aluminum · UNS A92024 · T3 sheet",
        "comp": [("Cu", "3.80-4.90"), ("Mg", "1.20-1.80"), ("Mn", "0.30-0.90")],
        "density": 2.78, "yield_mpa": 345, "tensile_mpa": 483, "elong": 18,
        "hardness": "120 HB (T3)", "modulus": 73.1, "thermal": 121, "cte": 22.9,
        "tags": ["aerospace skin", "fatigue resistant", "clad", "rivetable"],
        "body": "The classic aircraft-skin aluminum. Best fatigue performance in the high-strength aluminums, which is why it covers fuselages and wing skins. Often sold as 'Alclad' (a thin pure-aluminum cladding bonded to both faces) to combine the strength of 2024 with the corrosion resistance of pure aluminum, since the copper content of 2024 alone gives mediocre saltwater resistance.",
        "related": ["element:al", "element:cu"],
        "sources": ["asm-v2"],
    },

    # ============ COPPER ALLOYS ============
    {
        "slug": "cu-c110", "title": "C110 ETP copper", "symbol": "C11000",
        "family": "copper-alloy",
        "subtitle": "Electrolytic tough pitch copper · UNS C11000 · 99.90% Cu",
        "comp": [("Cu", "99.90 min"), ("O", "0.04 typ")],
        "density": 8.94, "yield_mpa": 69, "tensile_mpa": 220, "elong": 45,
        "hardness": "40 HRF (annealed)", "modulus": 117, "thermal": 391, "cte": 17.0,
        "tags": ["electrical", "high conductivity", "tough pitch", "busbar"],
        "body": "The volume-grade electrical and architectural copper. About 101% IACS conductivity. Contains around 0.04% oxygen as Cu₂O eutectic at grain boundaries; not suitable for hydrogen-bearing or high-temperature reducing atmospheres (where it suffers from hydrogen embrittlement, 'gassing').\n\nFor those environments, use **C10100 OFHC** (oxygen-free, 99.99% Cu, same conductivity, no oxide phase).",
        "related": ["element:cu"],
        "sources": ["asm-v2"],
    },
    {
        "slug": "cu-c260", "title": "C260 cartridge brass", "symbol": "C26000",
        "family": "copper-alloy",
        "subtitle": "70/30 brass · UNS C26000 · alpha brass",
        "comp": [("Cu", "68.5-71.5"), ("Zn", "balance")],
        "density": 8.53, "yield_mpa": 124, "tensile_mpa": 380, "elong": 66,
        "hardness": "65 HRF (annealed)", "modulus": 110, "thermal": 120, "cte": 19.9,
        "tags": ["brass", "deep drawing", "ammunition", "cartridge"],
        "body": "The brass for deep-drawing operations: ammunition cases, lamp components, drawn hardware. The highest cold-working ductility of any copper-zinc brass, which is what allows the multi-stage drawing of a flat disk into a long thin-walled case without intermediate annealing failures.",
        "related": ["element:cu", "element:zn"],
        "sources": ["asm-v2"],
    },
    {
        "slug": "cu-c360", "title": "C360 free-machining brass", "symbol": "C36000",
        "family": "copper-alloy",
        "subtitle": "Leaded brass · UNS C36000 · screw machine stock",
        "comp": [("Cu", "60.0-63.0"), ("Pb", "2.5-3.7"), ("Zn", "balance")],
        "density": 8.50, "yield_mpa": 124, "tensile_mpa": 338, "elong": 53,
        "hardness": "78 HRB (H02)", "modulus": 97, "thermal": 115, "cte": 20.5, "machinability": 100,
        "tags": ["brass", "free-machining", "screw machine", "leaded"],
        "body": "The machinability reference standard. 100% machinability (by definition; B1112 free-machining steel is 100% on the steel scale, C360 is 100% on the brass scale). Used for fittings, valves, screw machine parts, instrument hardware.\n\n**Lead-free alternatives** (C69300, C87850, EnviroBrass) are mandated for potable water service by the US Reduction of Lead in Drinking Water Act (2014). Machinability drops 20 to 40% but otherwise behaves similarly.",
        "related": ["element:cu", "element:zn", "element:pb"],
        "sources": ["asm-v2"],
    },
    {
        "slug": "cu-c932", "title": "C932 bearing bronze", "symbol": "C93200",
        "family": "copper-alloy",
        "subtitle": "SAE 660 leaded tin bronze · UNS C93200 · sleeve bearings",
        "comp": [("Cu", "81.0-85.0"), ("Sn", "6.3-7.5"), ("Pb", "6.0-8.0"), ("Zn", "1.0-4.0")],
        "density": 8.93, "yield_mpa": 125, "tensile_mpa": 240, "elong": 20,
        "hardness": "65 HB", "modulus": 100, "thermal": 59, "cte": 18.5,
        "tags": ["bearing", "bushing", "leaded bronze", "cast"],
        "body": "The volume-grade sleeve-bearing material. Sold as continuous cast or centrifugal cast hollow bar, ready to bore and use. The lead provides a soft anti-galling phase that smears at the bearing surface and resists scoring; the tin gives strength and corrosion resistance.\n\n**Limitations**: lead content makes it unsuitable for potable water service and increasingly restricted for general use. Look at **C93700** (higher tin/lead) for higher loads, or **C95500/C95800** (aluminum bronze) for high-stress, low-speed bearings.",
        "related": ["element:cu", "element:sn", "element:pb"],
        "sources": ["asm-v2"],
    },

    # ============ TITANIUM ============
    {
        "slug": "ti-grade-2", "title": "Titanium Grade 2", "symbol": "Ti Gr 2",
        "family": "titanium",
        "subtitle": "Commercially pure titanium · UNS R50400 · ASTM B265",
        "comp": [("Ti", "99 min"), ("O", "0.25 max"), ("Fe", "0.30 max")],
        "density": 4.51, "yield_mpa": 275, "tensile_mpa": 345, "elong": 20,
        "hardness": "200 HV", "modulus": 105, "thermal": 16.4, "cte": 8.6,
        "tags": ["CP titanium", "corrosion resistant", "chemical equipment", "biomedical"],
        "body": "The workhorse commercially-pure titanium. About 50% the density of steel, with excellent corrosion resistance to seawater, chloride brines, oxidizing acids, and bodily fluids. Used in chemical-process piping and heat exchangers, marine hardware, medical implants where biocompatibility matters more than strength, and architectural cladding (the Guggenheim Bilbao is wrapped in this).\n\nCompared to **Grade 5 (Ti-6Al-4V)**: lower strength, much better formability and weldability."
    },
    {
        "slug": "ti-grade-5", "title": "Ti-6Al-4V (Grade 5)", "symbol": "Ti-6Al-4V",
        "family": "titanium",
        "subtitle": "Alpha-beta titanium alloy · UNS R56400 · ASTM B265 Grade 5",
        "comp": [("Al", "5.5-6.75"), ("V", "3.5-4.5"), ("Ti", "balance")],
        "density": 4.43, "yield_mpa": 880, "tensile_mpa": 950, "elong": 14,
        "hardness": "334 HV", "modulus": 114, "thermal": 6.7, "cte": 8.6, "machinability": 22,
        "tags": ["aerospace", "biomedical", "high strength", "alpha-beta"],
        "body": "The dominant titanium alloy: about 50% of all titanium production. Strength comparable to medium-carbon alloy steel at less than 60% of the density.\n\n**Heat treat**: solution treat above the beta transus (about 995 °C), water quench, age at 480 to 595 °C for 4 to 8 hours. **Grade 23 (Ti-6Al-4V ELI)** is the extra-low-interstitial implant variant with slightly better fracture toughness for medical service.\n\n**Machining** is hard: titanium work-hardens, has low thermal conductivity (so heat concentrates at the cutting edge), and reacts chemically with the tool above about 500 °C. Sharp tools, slow speed (15 to 30 m/min), heavy feed, copious flood coolant, no spring passes.",
        "related": ["element:ti", "element:al", "element:v", "alloy:ti-grade-2"],
        "sources": ["asm-v2"],
    },

    # ============ NICKEL SUPERALLOYS ============
    {
        "slug": "ni-monel-400", "title": "Monel 400", "symbol": "Monel 400",
        "family": "nickel-superalloy",
        "subtitle": "Nickel-copper alloy · UNS N04400 · 67Ni-30Cu",
        "comp": [("Ni", "63 min"), ("Cu", "28-34"), ("Fe", "2.5 max"), ("Mn", "2.0 max")],
        "density": 8.83, "yield_mpa": 240, "tensile_mpa": 550, "elong": 35,
        "hardness": "110 to 149 HB", "modulus": 179, "thermal": 21.8, "cte": 13.9, "max_service": 540,
        "tags": ["marine", "acid resistant", "seawater", "non-magnetic"],
        "body": "The default seawater alloy. Where 316 stainless gets pitted by chloride attack, Monel survives indefinitely. Used in seawater pump shafts, propeller shafts, heat exchanger tubing, marine valve bodies, sour-gas service.\n\nHandles reducing acids that destroy stainless (HCl, HF, sulfuric below about 80 °C), but is attacked by oxidizing acids (HNO₃). **Monel K-500** is the age-hardenable variant for high-strength service.",
        "related": ["element:ni", "element:cu"],
        "sources": ["asm-v2"],
    },
    {
        "slug": "ni-inconel-625", "title": "Inconel 625", "symbol": "Inconel 625",
        "family": "nickel-superalloy",
        "subtitle": "Nickel-chromium-molybdenum superalloy · UNS N06625",
        "comp": [("Ni", "58 min"), ("Cr", "20-23"), ("Mo", "8-10"), ("Nb", "3.15-4.15"), ("Fe", "5 max")],
        "density": 8.44, "yield_mpa": 415, "tensile_mpa": 830, "elong": 30,
        "hardness": "≤220 HB (annealed)", "modulus": 207, "thermal": 9.8, "cte": 12.8, "max_service": 980,
        "tags": ["superalloy", "corrosion resistant", "high temperature", "weld overlay"],
        "body": "One of the most corrosion-resistant alloys in regular industrial use. The Mo and Nb additions provide outstanding resistance to chloride pitting, crevice corrosion, and a wide range of acids. Also retains useful mechanical properties to about 980 °C.\n\nCommonly used as a corrosion-resistant overlay welded onto less-expensive carbon-steel pressure vessels, in flue gas desulfurization (FGD) hardware, in oilfield sour-gas service, and in jet-engine combustor and exhaust sections.",
        "related": ["element:ni", "element:cr", "element:mo", "element:nb"],
        "sources": ["asm-v2"],
    },
    {
        "slug": "ni-inconel-718", "title": "Inconel 718", "symbol": "Inconel 718",
        "family": "nickel-superalloy",
        "subtitle": "Age-hardenable Ni-Cr-Fe superalloy · UNS N07718 · gas turbine",
        "comp": [("Ni", "50-55"), ("Cr", "17-21"), ("Fe", "balance"), ("Nb", "4.75-5.50"), ("Mo", "2.80-3.30"), ("Ti", "0.65-1.15"), ("Al", "0.20-0.80")],
        "density": 8.19, "yield_mpa": 1170, "tensile_mpa": 1380, "elong": 21,
        "hardness": "≤45 HRC (aged)", "modulus": 200, "thermal": 11.4, "cte": 13.0, "max_service": 700,
        "tags": ["superalloy", "gas turbine", "aerospace", "age hardenable", "additive"],
        "body": "The most-used age-hardenable nickel superalloy by volume, holding about a third of jet-engine alloy production. Stable at 700 °C for thousands of hours, machinable in the solution-treated condition before aging.\n\n**Heat treat**: solution at 980 °C, age at 720 °C for 8 hours, furnace cool to 620 °C, hold 8 hours, air cool. The Nb-rich γ″ (Ni₃Nb) phase is the primary strengthener, supplemented by γ′ (Ni₃Al,Ti).\n\nA major workhorse for additive manufacturing of high-temperature parts (laser powder bed fusion, electron beam melting).",
        "related": ["element:ni", "element:cr", "element:nb"],
        "sources": ["asm-v2"],
    },

    # ============ CAST IRONS ============
    {
        "slug": "ci-gray-30", "title": "Gray cast iron Class 30", "symbol": "GG-30 / G3000",
        "family": "cast-iron",
        "subtitle": "Flake graphite cast iron · ASTM A48 Class 30 · 30 ksi tensile",
        "comp": [("C", "2.5-4.0"), ("Si", "1.0-3.0"), ("Mn", "0.4-1.0")],
        "density": 7.15, "tensile_mpa": 210, "elong": 0.5,
        "hardness": "180 to 220 HB", "modulus": 100, "thermal": 50, "cte": 11.4,
        "tags": ["cast iron", "engine block", "machinability", "vibration damping"],
        "body": "The graphite-flake form of cast iron. The flakes give excellent vibration damping (machine tool bases), good thermal conductivity (engine blocks, brake rotors), self-lubricating slide surfaces (machine ways), and exceptional machinability. Tensile strength is mediocre (the flakes are crack-initiation sites) and elongation is essentially zero, so it cannot be used in shock-loading or tension service.\n\nFor better mechanical properties, see **ductile iron** which has the same matrix but with spheroidal rather than flake graphite.",
        "related": ["element:fe", "element:c"],
        "sources": ["asm-v1"],
    },
    {
        "slug": "ci-ductile-65", "title": "Ductile iron 65-45-12", "symbol": "65-45-12",
        "family": "cast-iron",
        "subtitle": "Spheroidal graphite cast iron · ASTM A536 65-45-12",
        "comp": [("C", "3.5-3.9"), ("Si", "2.2-2.8"), ("Mg", "0.03-0.06")],
        "density": 7.15, "yield_mpa": 310, "tensile_mpa": 450, "elong": 12,
        "hardness": "143 to 217 HB", "modulus": 169, "thermal": 31, "cte": 12.5,
        "tags": ["ductile iron", "structural cast", "gears", "pipe"],
        "body": "Cast iron with the graphite forced into spheres (nodules) by magnesium treatment of the melt just before casting. The nodular form removes the crack-initiation problem of flake graphite, so ductile iron behaves more like a low-carbon steel in tension and shock loading.\n\nThe designation 65-45-12 means 65 ksi tensile (450 MPa) / 45 ksi yield (310 MPa) / 12% elongation. Used for gears, automotive crankshafts, large pipe, water-utility valves, machine castings that need real mechanical performance.",
        "related": ["element:fe", "element:c", "element:mg", "alloy:ci-gray-30"],
        "sources": ["asm-v1"],
    },
]


def build_entry(spec):
    family = spec["family"]
    fam_tags = FAMILY_TAGS.get(family, [])
    all_tags = list(dict.fromkeys(fam_tags + list(spec.get("tags", []))))
    return {
        "id": f"alloy:{spec['slug']}",
        "module": "alloy",
        "kind": "alloy",
        "title": spec["title"],
        "symbol": spec.get("symbol", ""),
        "subtitle": spec.get("subtitle", ""),
        "family": family,
        "tags": all_tags,
        "stats": stats_from(spec),
        "body": spec.get("body", ""),
        "hazards": spec.get("hazards", []),
        "related": spec.get("related", []),
        "sources": spec.get("sources", ["asm-v1"]),
    }


def write_manifest_entries():
    """Update manifest assay entries list and mark active."""
    manifest = json.loads(MANIFEST.read_text())
    slugs = sorted([a["slug"] for a in ALLOYS] + ["aisi-1018"])  # aisi-1018 is hand-written
    for m in manifest["modules"]:
        if m["slug"] == "alloy":
            m["entries"] = slugs
            m["status"] = "active"
            break
    MANIFEST.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    print(f"Manifest updated: alloy declares {len(slugs)} entries.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--keep", action="append", default=[])
    args = ap.parse_args()
    keep = {s.lower() for s in args.keep}

    written, skipped = 0, 0
    for spec in ALLOYS:
        slug = spec["slug"]
        if slug.lower() in keep:
            print(f"  · skip {slug}")
            skipped += 1
            continue
        entry = build_entry(spec)
        path = DATA_DIR / f"{slug}.json"
        text = json.dumps(entry, indent=2, ensure_ascii=False) + "\n"
        if args.dry_run:
            print(f"  {'~' if path.exists() else '+'} {path.relative_to(ROOT)}")
        else:
            path.write_text(text)
        written += 1
    print(f"\nSeeded {written} alloy files. Skipped {skipped}.")

    if not args.dry_run:
        write_manifest_entries()
    return 0


if __name__ == "__main__":
    sys.exit(main())
