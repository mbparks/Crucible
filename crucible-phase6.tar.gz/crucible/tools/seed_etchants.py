#!/usr/bin/env python3
"""
CRUCIBLE etchant seeder.

Generates modules/etch/data/<slug>.json: metallographic etchants, PCB etchants,
patina solutions, and the caustic black-oxide bath.

Sources: ASTM E407 (Microetching Metals and Alloys), ASM Handbook Vol. 9
(Metallography and Microstructures), and standard patina recipes.
"""

import json
import sys
import argparse
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "modules" / "etch" / "data"
MANIFEST = ROOT / "shared" / "data" / "manifest.json"


def _stat(key, label, value, unit, source="astm-e407"):
    return {"key": key, "label": label, "value": value, "unit": unit, "source": source}


ETCHANTS = [
    # ========== Metallographic, ferrous ==========
    {
        "slug": "nital", "title": "Nital",
        "symbol": "Nital",
        "subtitle": "Nitric acid in ethanol · ASTM E407 No. 74 · carbon and low-alloy steel",
        "stats": [
            _stat("recipeAcid", "Recipe", "1 to 5 mL HNO₃ + 95 to 99 mL ethanol", ""),
            _stat("strength", "Common strength", "2% (general use)", ""),
            _stat("application", "Application", "swab or immerse 5 to 60 s", ""),
            _stat("target", "Reveals", "ferrite, pearlite, martensite", ""),
            _stat("usefulFor", "Useful for", "AISI 10xx, 41xx, 43xx, tool steels", ""),
        ],
        "tags": ["metallography", "carbon steel", "alloy steel", "ferritic", "general purpose"],
        "body": "The default etchant for carbon and low-alloy steels. The 2% strength is the workhorse; 4 to 5% gives faster action on hardened steels, 1% for delicate work on annealed or partially decarburized surfaces.\n\n**Reveals:** grain boundaries in ferrite, pearlite (the alternating ferrite-cementite lamellae), tempered martensite (dark), retained austenite (light), prior austenite grain boundaries with a longer etch.\n\n**Procedure**: prepare a clean polished surface (down to 1 micron diamond or 0.05 micron alumina), rinse with ethanol, swab the etchant on with a cotton-tipped applicator for 5 to 30 seconds depending on the alloy, rinse with ethanol, dry with warm air. Re-etch if too light, re-polish if over-etched.\n\n**Storage**: small batches only. Mix fresh, keep stoppered, discard within a few weeks.",
        "hazards": ["corrosive", "flammable solvent"],
        "related": ["reagent:hno3-conc", "alloy:aisi-4140", "alloy:aisi-1045"],
        "sources": ["astm-e407", "asm-v9"],
    },
    {
        "slug": "picral", "title": "Picral",
        "symbol": "Picral",
        "subtitle": "Picric acid in ethanol · ASTM E407 No. 76 · fine pearlite, spheroidized",
        "stats": [
            _stat("recipe", "Recipe", "4 g picric acid + 100 mL ethanol", ""),
            _stat("application", "Application", "immerse 30 s to 5 min", ""),
            _stat("target", "Reveals", "carbide colonies, fine pearlite", ""),
            _stat("usefulFor", "Useful for", "carbide ID, spheroidized steel, ferrite-only", ""),
        ],
        "tags": ["metallography", "carbon steel", "carbide", "spheroidized"],
        "body": "Picral attacks cementite preferentially while leaving ferrite untouched, which is the opposite of nital. Used to distinguish carbide morphology (lamellar pearlite, spheroidized cementite, bainitic carbide) that nital cannot resolve.\n\n**Safety**: picric acid (2,4,6-trinitrophenol) is **friction-and-shock-sensitive when dry** and is a Class 1 explosive in pure crystalline form. Buy and store wet, never let the bottle dry to a fine powder. Discard old bottles through a licensed hazardous waste hauler, never by drying out.\n\n**Mixed picral solution is stable** as long as it stays wet with ethanol. Many labs no longer keep picral on hand and use sodium metabisulfite + nital alternatives.",
        "hazards": ["explosive (dry picric acid)", "friction sensitive", "flammable"],
        "related": ["reagent:hno3-conc"],
        "sources": ["astm-e407", "asm-v9"],
    },

    # ========== Metallographic, aluminum ==========
    {
        "slug": "kellers", "title": "Keller's reagent",
        "symbol": "Keller's",
        "subtitle": "Aluminum metallographic etch · ASTM E407 No. 3",
        "stats": [
            _stat("recipe", "Recipe", "190 mL water + 5 mL HNO₃ + 3 mL HCl + 2 mL HF", ""),
            _stat("application", "Application", "swab 10 to 20 s", ""),
            _stat("target", "Reveals", "grain structure, intermetallic phases", ""),
            _stat("usefulFor", "Useful for", "wrought 2xxx, 6xxx, 7xxx aluminum", ""),
        ],
        "tags": ["metallography", "aluminum", "wrought alloys", "HF"],
        "body": "**The hydrofluoric acid is the dangerous part.** HF causes deep, painful, slow-healing burns and binds calcium in tissue, which can be lethal at exposed surface areas greater than ~25 cm². Always wear heavy nitrile (not latex), have calcium gluconate gel in arm's reach, and work over a sink with a generous water rinse stream.\n\nThe etch reveals grain structure in wrought heat-treatable aluminum alloys (2024, 6061, 7075). Cast alloys (356, 357) etch better with Tucker's or 0.5% HF instead.",
        "hazards": ["HF", "extreme tissue penetration", "fume hood mandatory"],
        "related": ["element:al", "alloy:al-2024", "alloy:al-7075"],
        "sources": ["astm-e407", "asm-v9"],
    },

    # ========== Metallographic, tool/stainless ==========
    {
        "slug": "klein", "title": "Klein's reagent",
        "symbol": "Klein's",
        "subtitle": "Tool steel etch · grain and carbide structure",
        "stats": [
            _stat("recipe", "Recipe", "saturated CrO₃ in HCl (50%)", ""),
            _stat("application", "Application", "swab 5 to 20 s", ""),
            _stat("target", "Reveals", "carbides, grain structure", ""),
            _stat("usefulFor", "Useful for", "high-carbon tool steels (A2, D2, M-series)", ""),
        ],
        "tags": ["metallography", "tool steel", "carbide", "chromium acid"],
        "body": "Strong etchant for high-carbon tool steels where nital is too slow. Chromium trioxide (CrO₃) hexavalent chromium is a known carcinogen; current best practice substitutes hot Murakami or Vilella's reagent where possible.",
        "hazards": ["hexavalent chromium", "carcinogen", "corrosive"],
        "related": ["alloy:tool-d2", "alloy:tool-a2"],
        "sources": ["astm-e407", "asm-v9"],
    },
    {
        "slug": "marble", "title": "Marble's reagent",
        "symbol": "Marble's",
        "subtitle": "Stainless steel general etch · ASTM E407 No. 13",
        "stats": [
            _stat("recipe", "Recipe", "10 g CuSO₄ + 50 mL HCl + 50 mL water", ""),
            _stat("application", "Application", "swab 5 to 30 s", ""),
            _stat("target", "Reveals", "grain structure, weld HAZ, sensitization", ""),
            _stat("usefulFor", "Useful for", "304, 316, 17-4 PH, most stainless grades", ""),
        ],
        "tags": ["metallography", "stainless", "weld HAZ", "copper sulfate"],
        "body": "The general-purpose stainless etch. Copper deposits on grain boundaries where the matrix has been depleted of chromium (the basis of the Strauss intergranular-attack test). Quick and reliable for most austenitic, martensitic, and PH grades.",
        "related": ["alloy:ss-304", "alloy:ss-316", "alloy:ss-17-4"],
        "sources": ["astm-e407", "asm-v9"],
    },
    {
        "slug": "glyceregia", "title": "Glyceregia",
        "symbol": "Glyceregia",
        "subtitle": "Stainless and Ni-superalloy etch · ASTM E407 No. 87",
        "stats": [
            _stat("recipe", "Recipe", "10 mL HNO₃ + 20 to 50 mL HCl + 30 mL glycerin", ""),
            _stat("application", "Application", "swab fresh, 15 to 60 s", ""),
            _stat("target", "Reveals", "weld microstructure, intermetallics", ""),
            _stat("usefulFor", "Useful for", "stainless welds, Inconel, Hastelloy", ""),
        ],
        "tags": ["metallography", "stainless", "weld", "nickel superalloy"],
        "body": "**Mix fresh, use within hours, and never store sealed.** The glycerin slowly reduces the nitric acid, generating gas that pressurizes a sealed container. The glycerin moderates the nitric+HCl mix (essentially a diluted aqua regia) to a controllable etch for highly corrosion-resistant nickel and stainless alloys.\n\nReveals weld pool dendritic structure, sigma phase precipitation, and chi-phase intermetallics in service-aged stainless and superalloy parts.",
        "hazards": ["corrosive", "decomposes in storage"],
        "related": ["alloy:ss-316", "alloy:ni-inconel-625", "alloy:ni-inconel-718"],
        "sources": ["astm-e407", "asm-v9"],
    },
    {
        "slug": "murakami", "title": "Murakami's reagent",
        "symbol": "Murakami's",
        "subtitle": "Carbide ID and chromium attack · ASTM E407 No. 30",
        "stats": [
            _stat("recipe", "Recipe", "10 g KOH + 10 g K₃Fe(CN)₆ + 100 mL water", ""),
            _stat("application", "Application", "swab or immerse, 30 s to 5 min", ""),
            _stat("target", "Reveals", "WC dark, M₆C colored, Cr-rich phases", ""),
            _stat("usefulFor", "Useful for", "tungsten carbide, tool steels, sensitization", ""),
        ],
        "tags": ["metallography", "tungsten carbide", "carbide identification", "potassium ferricyanide"],
        "body": "Alkaline ferricyanide etch. Identifies and differentiates carbide types: tungsten carbide (WC) stains dark gray, M₆C complex carbides take on faint colors, chromium-depleted regions stain. The standard etch for examining tungsten carbide cutting tools and sensitized stainless.\n\nMix fresh each session. Iron-cyanide complexes can decompose to free cyanide under acidic conditions; never combine residues with acid waste.",
        "hazards": ["cyanide complex", "keep alkaline", "no acid mixing"],
        "related": ["element:w", "alloy:tool-m2"],
        "sources": ["astm-e407", "asm-v9"],
    },

    # ========== Functional etchants ==========
    {
        "slug": "fecl3-pcb", "title": "Ferric chloride (PCB strength)",
        "symbol": "FeCl₃ 38°",
        "subtitle": "PCB copper etchant · 38 to 42° Baumé · ~38% FeCl₃ aqueous",
        "stats": [
            _stat("concentration", "Concentration", "38 to 42° Baumé", "(~38% FeCl₃ w/w)"),
            _stat("application", "Application", "immerse, agitate, 5 to 20 min", ""),
            _stat("temperature", "Best temperature", "40 to 50", "°C"),
            _stat("etchRate", "Etch rate (35 μm Cu)", "~5 min at 45 °C", ""),
            _stat("disposalNote", "Disposal", "Spent etchant + Cu → hazardous waste", ""),
        ],
        "tags": ["PCB", "copper etch", "hobbyist", "ferric"],
        "body": "Ferric chloride is the most popular hobby PCB etchant: cheap, no toxic fumes (versus ammonium persulfate which is fine, or cupric chloride which is regenerable but harsher), good shelf life, available at electronics suppliers.\n\n**Disposal**: spent etchant contains dissolved copper. Do not pour down the drain. Precipitate copper with sodium carbonate, filter, and dispose of the copper carbonate sludge as hazardous waste. The filtered, copper-free solution can be neutralized with more carbonate and disposed of as alkaline brine in many jurisdictions, but check local regulations.",
        "hazards": ["staining", "metal corrosion", "Cu-laden waste disposal"],
        "related": ["element:cu", "element:fe", "element:cl"],
        "sources": ["asm-v9"],
    },
    {
        "slug": "aqua-regia", "title": "Aqua regia",
        "symbol": "HNO₃ + 3HCl",
        "subtitle": "Royal water · 1:3 HNO₃:HCl · dissolves gold and platinum",
        "stats": [
            _stat("recipe", "Recipe", "1 part conc HNO₃ + 3 parts conc HCl by volume", ""),
            _stat("application", "Application", "freshly mixed, 30 s to several min", ""),
            _stat("activeComponents", "Active species", "nitrosyl chloride NOCl + free Cl₂", ""),
            _stat("dissolves", "Dissolves", "Au, Pt, Pd, most base metals", ""),
            _stat("doesNotDissolve", "Resists attack", "Ir, Os, Rh, Ru, Ta (passivates)", ""),
        ],
        "tags": ["mineral acid", "noble metals", "dissolution", "royal water"],
        "body": "Latin for 'royal water', because it dissolves the royal metals (gold and platinum). Mix only what you need, when you need it; the active oxidizing species (nitrosyl chloride and chlorine gas) form on mixing and the mixture quickly loses potency.\n\n**Never store mixed aqua regia in a closed container.** The gas pressure from NOCl and Cl₂ can rupture the vessel. Always vent or mix at point of use in a fume hood.\n\n**Use cases**: assaying gold-bearing ore, dissolving spent platinum-group catalyst, removing the last traces of organic contamination from glassware (where chromic acid was historically used but has been displaced by aqua regia or piranha solution).",
        "hazards": ["corrosive", "oxidizer", "toxic gas (NOCl, Cl₂)", "fume hood mandatory"],
        "related": ["element:au", "element:pt", "reagent:hno3-conc", "reagent:hcl-conc"],
        "sources": ["merck-index", "crc-104"],
    },

    # ========== Patinas ==========
    {
        "slug": "liver-of-sulfur", "title": "Liver of sulfur",
        "symbol": "K₂S₂ / K₂Sₓ",
        "subtitle": "Potassium polysulfide patina · copper, brass, silver",
        "stats": [
            _stat("composition", "Composition", "potassium polysulfide mix (K₂S, K₂S₂, K₂S₃, K₂S₄)", ""),
            _stat("workingSolution", "Working solution", "small piece (pea-sized) in 250 mL warm water", ""),
            _stat("temperature", "Temperature", "warm, 40 to 60 °C", ""),
            _stat("colors", "Color sequence on copper", "gold → red → blue → purple → gray-black", ""),
            _stat("colorsAg", "Color sequence on silver", "yellow → tan → blue → gray-black", ""),
        ],
        "tags": ["patina", "copper", "brass", "silver", "blackening"],
        "body": "Sulfide ions react with copper and silver surfaces to form a sulfide film. The film thickness controls the color through optical interference: very thin films give golds and reds, thicker films give blues and purples, and a fully developed film is matte black. Pulled out of the bath and rinsed at any point captures that color.\n\n**Procedure**: clean the piece (alkaline degrease, pickle to remove oxide, rinse to neutral pH, do not touch the surface), suspend in or paint onto the warm sulfide solution, watch the color develop in seconds, rinse with cold water and pat dry. Seal with wax or lacquer to preserve.\n\n**Smells terrible.** Hydrogen sulfide outgas. Work in a ventilated area. Solid 'liver of sulfur' sticks lose potency with air exposure; gel forms (XL) are more stable.",
        "hazards": ["H₂S outgas", "smell", "skin irritant"],
        "related": ["element:cu", "element:ag", "element:s"],
        "sources": ["merck-index"],
    },
    {
        "slug": "ammonia-patina", "title": "Ammonia and vinegar patina",
        "symbol": "Cu green",
        "subtitle": "Brass and copper green patina · vapor or paint-on",
        "stats": [
            _stat("recipe", "Recipe", "household ammonia (5%) + white vinegar (5%) + sea salt", ""),
            _stat("ratio", "Working ratio", "200 mL ammonia + 100 mL vinegar + 20 g salt", ""),
            _stat("application", "Application", "spray, immerse, or vapor expose", ""),
            _stat("time", "Time to color", "hours to days", ""),
            _stat("color", "Color", "blue-green verdigris (basic copper carbonate)", ""),
        ],
        "tags": ["patina", "brass", "copper", "verdigris", "natural"],
        "body": "Approximates the verdigris that forms naturally on weathered bronze and brass over years, in minutes to days. Salt accelerates by forming soluble copper chlorides as intermediates; vinegar provides the acid that initiates pitting; ammonia complexes with the copper to form blue intermediates that decompose to the basic copper carbonate (the green outer layer).\n\n**Vapor patination** (the controlled version): seal the piece and a dish of the solution in a chamber, leave for 12 to 72 hours, the patina develops uniformly without dripping marks.\n\n**Variants**: increasing salt gives more aggressive blue-green; adding cupric nitrate gives a deeper sage green; substituting acetic acid for vinegar gives more uniform brown intermediate stages."
    },
    {
        "slug": "caustic-black-oxide", "title": "Caustic black oxide",
        "symbol": "Fe₃O₄",
        "subtitle": "Hot alkaline black-oxide finish for steel · also called bluing",
        "stats": [
            _stat("baseSolution", "Bath", "NaOH + NaNO₃ + NaNO₂ in water", ""),
            _stat("recipeShop", "Hobby recipe", "1 lb NaOH + 6 oz NaNO₃ per quart water", ""),
            _stat("temperature", "Temperature", "138 to 145", "°C (boiling point of the hot solution)"),
            _stat("time", "Immersion time", "10 to 30", "min"),
            _stat("postTreat", "Post-treat", "rinse, neutralize, oil/wax seal", ""),
        ],
        "tags": ["black oxide", "bluing", "steel finish", "firearms", "corrosion"],
        "body": "The traditional industrial blackening process for steel parts. Forms Fe₃O₄ (magnetite) on the surface, the same iron oxide that gives natural mill scale its color. The black layer is about 1 micron thick, provides modest corrosion resistance (dramatically improved by sealing with oil or wax), and adds essentially zero dimensional change.\n\n**The boiling caustic is the hazard.** At 145 °C, splashes cause severe burns immediately. Always wear a face shield, gauntlet gloves, and a chemical apron. Work in a vented area; the nitrate/nitrite generates trace NO₂.\n\n**Cold black oxide** kits (selenious acid based) give a similar appearance at room temperature but with much shallower corrosion resistance. Hot caustic is the durable finish.",
        "hazards": ["hot caustic", "thermal burn", "NO₂ outgas"],
        "related": ["element:fe", "reagent:naoh-pellets"],
        "sources": ["asm-v13"],
    },
]


def build_entry(spec):
    return {
        "id": f"etch:{spec['slug']}",
        "module": "etch",
        "kind": "etchant",
        "title": spec["title"],
        "symbol": spec.get("symbol", ""),
        "subtitle": spec.get("subtitle", ""),
        "tags": spec.get("tags", []),
        "stats": spec.get("stats", []),
        "body": spec.get("body", ""),
        "hazards": spec.get("hazards", []),
        "related": spec.get("related", []),
        "sources": spec.get("sources", ["astm-e407", "asm-v9"]),
    }


def write_manifest_entries():
    manifest = json.loads(MANIFEST.read_text())
    slugs = [s["slug"] for s in ETCHANTS]
    for m in manifest["modules"]:
        if m["slug"] == "etch":
            m["entries"] = slugs
            m["status"] = "active"
            break
    MANIFEST.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    print(f"Manifest updated: etch declares {len(slugs)} entries.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    written = 0
    for spec in ETCHANTS:
        entry = build_entry(spec)
        path = DATA_DIR / f"{spec['slug']}.json"
        text = json.dumps(entry, indent=2, ensure_ascii=False) + "\n"
        if args.dry_run:
            print(f"  {'~' if path.exists() else '+'} {path.relative_to(ROOT)}")
        else:
            path.write_text(text)
        written += 1
    print(f"\nSeeded {written} etchant files.")
    if not args.dry_run:
        write_manifest_entries()
    return 0


if __name__ == "__main__":
    sys.exit(main())
